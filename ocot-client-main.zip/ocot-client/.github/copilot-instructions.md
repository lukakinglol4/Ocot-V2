# Copilot Instructions for Ocot Client

## Project Overview

Ocot Client is a web-based application that provides various functionalities including proxy operations, privacy tools, developer utilities, and productivity features. The application is built with vanilla JavaScript and uses a modular view-based architecture.

## Key Features

- **Proxy View**: Access and manage proxy operations
- **Privacy & Security Tools**: Tab cloaking, history manipulation, CORS proxying
- **Developer Tools**: JavaScript console, calculator, notes, bookmarklets
- **Games Collection**: Access to blocked/unblocked games
- **Pocket Browser**: Embedded browser with privacy features
- **Scripts**: Collection of useful JavaScript utilities

## Key Application Characteristics

### Single-Page Application (SPA)

- Uses `ProxyClientApp` class as main application controller
- Views are dynamically created and switched via sidebar navigation
- No external routing library - custom view management system

### Modular View System

- Each view is a self-contained module returning DOM elements
- Views handle their own styling via CSS injection
- Event listeners are attached within view creation functions
- State management through local storage and DOM manipulation

### Launch Methods

- **File mode**: Direct HTML file opening (`index.html`)
- **Bookmarklet injection**: Can be injected into any webpage
- **CDN distribution**: Available via jsDelivr for remote loading

## Architecture & Code Style

### Project Structure

```
src/
├── main.ts              # Application entry point with ProxyClientApp class
├── sidebar.ts           # ProxySidebar class for navigation
├── css.ts               # Shared CSS injection utilities
├── data/                # Data layer with JSON and TS fallbacks
│   ├── javascript/      # TypeScript fallback data for bookmarklet compatibility
│   │   ├── games.ts     # Games data fallback
│   │   └── scripts.ts   # Scripts data fallback
│   └── json/            # JSON data files for hosted environments
│       ├── games.json   # Games metadata
│       └── scripts.json # Scripts metadata
├── handlers/            # Individual script handler modules
│   ├── aboutblankinjector.ts  # About:blank page script injection
│   ├── antiforcereload.ts     # Page reload prevention (stateful)
│   ├── autohide.ts            # Auto-hide proxy client (stateful)
│   ├── autoremove.ts          # Auto-remove proxy client (stateful)
│   ├── blooketcheats.ts       # Blooket cheats injection
│   ├── emergencyswitcher.ts   # Emergency tab switching
│   ├── fakecrash.ts           # Fake browser crash simulation
│   ├── forceselect.ts         # Force text selection enabler
│   ├── mathtools.ts           # Advanced math calculator
│   ├── pageeditor.ts          # Page editing mode toggle
│   ├── quickscroll.ts         # Quick scroll to bottom
│   ├── storagemanager.ts      # Browser storage management
│   └── tabcloak.ts            # URL cloaking in new tab
├── styles/              # CSS stylesheets
│   └── app.css          # Global application styles
├── types/               # TypeScript type definitions
│   └── global.d.ts      # Global type definitions
├── utils/               # Utility modules
│   ├── helpers.ts       # Shared utility functions (loadJson, etc.)
│   └── modalHelpers.ts  # Themed modal system utilities
└── views/               # Individual view modules
    ├── welcome.ts       # Landing page view
    ├── settings.ts      # Settings and help view
    ├── console.ts       # JavaScript console tool
    ├── calculator.ts    # Calculator utility
    ├── notes.ts         # Note-taking tool
    ├── scripts.ts       # Scripts management view
    ├── proxy.ts         # Proxy functionality
    ├── games.ts         # Games collection
    ├── bookmarklets.ts  # Bookmarklets collection
    ├── cloaking.ts      # Tab cloaking features
    ├── historyFlood.ts  # History manipulation
    ├── corsProxy.ts     # CORS proxy utilities
    └── pocketBrowser.ts # Embedded browser
```

### Documentation Structure

```
docs/
├── FILE_STRUCTURE.md           # Complete project structure documentation
└── MODAL_IMPLEMENTATION.md     # Modal system implementation guide
```

### Coding Standards

1. **TypeScript**: Use TypeScript for type safety and better development experience
2. **ES6 Modules**: Use ES6 import/export syntax
3. **Vanilla JavaScript**: No external frameworks, keep dependencies minimal
4. **Function Exports**: Each view exports a default function that returns DOM elements
5. **Handler Pattern**: Script handlers export objects with `onActivate()` method and optional state management
6. **CSS-in-JS**: Use template literals for inline styles, consistent with existing patterns
7. **Event Handling**: Attach event listeners within view creation functions
8. **Local Storage**: Use for persistent data (themes, notes, settings)
9. **Dynamic Imports**: Use dynamic imports for loading handlers on-demand
10. **Type Definitions**: Use proper TypeScript types and interfaces for better code quality

### View Pattern

```typescript
// Standard view module pattern
export default function createViewName(): HTMLElement {
  // CSS injection if needed
  if (!document.getElementById("view-style")) {
    const style = document.createElement("style");
    style.id = "view-style";
    style.textContent = `/* CSS styles */`;
    document.head.appendChild(style);
  }

  // Create and return DOM element
  const viewElement = document.createElement("div");
  viewElement.innerHTML = `/* HTML template */`;

  // Add event listeners
  // Return element
  return viewElement;
}
```

### Handler Pattern

```typescript
// Standard handler module pattern
interface Handler {
  id: string;
  title: string;
  description: string;
  category: "utility" | "privacy" | "gaming" | "protection";
  stateful?: boolean;
  isEnabled?(): boolean;
  onEnable?(): Promise<void>;
  onDisable?(): Promise<void>;
  onActivate(): Promise<void>;
}

export default {
  id: "handlername",
  title: "Handler Display Name",
  description: "What this handler does",
  category: "utility",

  // Optional: for stateful handlers
  stateful: true,

  isEnabled() {
    return (window as any).handlerEnabled || false;
  },

  async onEnable() {
    // Enable functionality
    (window as any).handlerEnabled = true;
  },

  async onDisable() {
    // Disable functionality
    (window as any).handlerEnabled = false;
  },

  async onActivate() {
    // Main handler logic
    // For stateful: toggle between enable/disable
    // For non-stateful: execute action
  },
} as Handler;
```

## Development Environment

### Setup

```bash
npm install          # Install dependencies
npm run build        # Build with esbuild
npm start           # Start local server on port 8080
```

### Build System

- **TypeScript**: TypeScript compiler for type checking and compilation
- **Bundler**: esbuild (fast, minimal configuration)
- **Output**: Single bundle file at `dist/bundle.js`
- **Format**: IIFE (Immediately Invoked Function Expression)
- **Entry**: `src/main.ts` (compiled to `build/main.js` then bundled)

### Testing

- **Framework**: Jest (configured but tests may be minimal)
- **Command**: `npm test`
- **Focus**: Functionality over extensive testing due to UI-heavy nature

## UI/UX Guidelines

### Design System

- **Theme**: Dark theme with blue (#00bfff) accents
- **Colors**:
  - Background: #23272f, #292d36
  - Text: #fff, #d4d4d4, #aaa
  - Accent: #00bfff
  - Success: Green tones
  - Error: Red tones
- **Typography**: System fonts, monospace for code
- **Layout**: CSS Grid and Flexbox for responsive design

### Component Patterns

- Card-based layouts for feature groupings
- Consistent padding and spacing (12px, 16px, 24px)
- Hover effects with subtle animations
- Keyboard shortcuts support (backslash key to toggle)

## Browser Compatibility

- **Target**: Modern browsers with ES6 support
- **Deployment**: Can run as standalone HTML file or via CDN
- **Bookmarklet**: Supports injection via bookmarklet for any website

## Security Considerations

- **Content Security**: Be mindful of XSS when handling user input
- **Proxy Features**: Understand CORS implications
- **Local Storage**: Sensitive data should be handled carefully
- **Script Execution**: Console and scripts features execute arbitrary JavaScript

## Common Tasks

### Adding a New View

1. Create new file in `src/views/newview.ts`
2. Follow the standard view pattern with TypeScript types
3. Export default function that returns DOM element
4. Import the view in `src/main.ts`
5. Add view creation in `ProxyClientApp.setupViews()`
6. Add navigation button in `ProxySidebar.addNavigationButtons()`
7. Add view switching logic in button event handlers

### Adding a New Script Handler

1. Create new file in `src/handlers/newhandler.ts`
2. Follow the standard handler pattern with TypeScript interface
3. Export default object with `onActivate()` method and proper typing
4. Add entry to `src/data/json/scripts.json`
5. Add entry to `src/data/javascript/scripts.ts` (fallback)
6. Handler will be automatically loaded by scripts view

### Styling Guidelines

- Use inline styles for component-specific styling
- Inject global styles via CSS-in-JS pattern
- Maintain consistency with existing color scheme
- Ensure responsive design with CSS Grid/Flexbox

### Local Storage Usage

- Theme preferences: `ocot-theme`
- Notes content: Auto-saved keys
- Settings: Prefix with `ocot-` for namespace

## Contributing Guidelines

- **Minimal Dependencies**: Avoid adding new dependencies unless absolutely necessary
- **Backward Compatibility**: Maintain compatibility with existing bookmarklet users
- **Performance**: Keep bundle size reasonable for web distribution
- **Cross-Platform**: Ensure features work across different browsers and contexts

## Deployment

The application supports multiple deployment methods:

1. **File-based**: Open `index.html` directly
2. **CDN**: Via jsDelivr from GitHub releases
3. **Bookmarklet**: Injected into any webpage
4. **Local Server**: Using npm start for development

## Special Considerations

- **Context Awareness**: Application may run in various contexts (standalone, injected)
- **No External APIs**: Designed to work without external service dependencies
- **Privacy Focus**: Many features are designed for privacy and security
- **Educational Purpose**: Some features demonstrate web development concepts
