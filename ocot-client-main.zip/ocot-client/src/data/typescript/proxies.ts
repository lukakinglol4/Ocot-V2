// TypeScript interface for proxy data
export interface ProxyData {
  id: string;
  name: string;
  url: string;
  description: string;
}

// Fallback proxy data for bookmarklet mode or when JSON loading fails
export const proxiesList: ProxyData[] = [
  {
    id: "work-bartlett",
    name: "Work Bartlett (default)",
    url: "https://work.benjaminbartlett.net/",
    description: "Work proxy service",
  },
  {
    id: "api-bartlett",
    name: "API Bartlett",
    url: "https://api.benjaminbartlett.net/",
    description: "API proxy service",
  },
  {
    id: "help-bartlett",
    name: "Help Bartlett",
    url: "https://help.benjaminbartlett.net/",
    description: "Help proxy service",
  },
  {
    id: "space",
    name: "space proxy",
    url: "https://schoolisgood.info.gf/",
    description: "space proxy"
  },
  {
    id: "utopia-link-1",
    name: "utopia",
    url: "https://core.lab.infosv.ro/",
    description: "utopia link"
  }
];
