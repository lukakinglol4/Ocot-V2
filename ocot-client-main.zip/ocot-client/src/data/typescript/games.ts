let gamesList = [
  {
    url: "https://crazygames.com/",
    title: "Crazygames",
    type: "blocked",
  },
  {
    url: "https://itch.io/",
    title: "Itch.io",
    type: "blocked",
  },
  {
    url: "https://example.com/game3",
    title: "Game Three",
    type: "cors-optimized",
  },
  {
    url: "https://cocajola.com/wp-content/uploads/2024/09/Math_Slideshow-1.html",
    title: "eaglecraft",
    type: "unblocked",
  },
];
export { gamesList };
