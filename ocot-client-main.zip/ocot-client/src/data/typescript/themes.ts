// TypeScript interface for theme colors
export interface ThemeColors {
  bgPrimary: string;
  bgSecondary: string;
  accentColor: string;
  accentHover: string;
  accentColorRgb: string;
}

// TypeScript interface for theme data
export interface Theme {
  id: string;
  name: string;
  description: string;
  colors: ThemeColors;
  preview: string[];
  icon: string;
}

// Themes list with all available themes
export const themesList: Theme[] = [
  {
    id: "default",
    name: "Default Dark",
    description: "Classic dark theme",
    colors: {
      bgPrimary: "#23272f",
      bgSecondary: "#292d36",
      accentColor: "#007acc",
      accentHover: "#005a9e",
      accentColorRgb: "0, 122, 204",
    },
    preview: ["#23272f", "#007acc", "#292d36"],
    icon: "🎨",
  },
  {
    id: "blue",
    name: "Ocean Blue",
    description: "Cool blue tones",
    colors: {
      bgPrimary: "#1a1f2e",
      bgSecondary: "#2a3040",
      accentColor: "#0066cc",
      accentHover: "#0052a3",
      accentColorRgb: "0, 102, 204",
    },
    preview: ["#1a1f2e", "#0066cc", "#2a3040"],
    icon: "🌊",
  },
  {
    id: "purple",
    name: "Purple Haze",
    description: "Rich purple theme",
    colors: {
      bgPrimary: "#2a1f3d",
      bgSecondary: "#3d2a54",
      accentColor: "#8b5cf6",
      accentHover: "#7c3aed",
      accentColorRgb: "139, 92, 246",
    },
    preview: ["#2a1f3d", "#8b5cf6", "#3d2a54"],
    icon: "💜",
  },
  {
    id: "green",
    name: "Matrix Green",
    description: "Terminal inspired",
    colors: {
      bgPrimary: "#1f2f1f",
      bgSecondary: "#2d3f2d",
      accentColor: "#10b981",
      accentHover: "#059669",
      accentColorRgb: "16, 185, 129",
    },
    preview: ["#1f2f1f", "#10b981", "#2d3f2d"],
    icon: "💚",
  },
  {
    id: "red",
    name: "Crimson Red",
    description: "Bold and striking",
    colors: {
      bgPrimary: "#3d1f1f",
      bgSecondary: "#4a2929",
      accentColor: "#dc2626",
      accentHover: "#b91c1c",
      accentColorRgb: "220, 38, 38",
    },
    preview: ["#3d1f1f", "#dc2626", "#4a2929"],
    icon: "❤️",
  },
  {
    id: "custom",
    name: "Custom Theme",
    description: "Create your own colors",
    colors: {
      bgPrimary: "#292d36",
      bgSecondary: "#23272f",
      accentColor: "#00bfff",
      accentHover: "#009fdf",
      accentColorRgb: "0, 191, 255",
    },
    preview: ["#292d36", "#00bfff", "#23272f"],
    icon: "✨",
  },
];
