/**
 * Modal Helper Functions for Ocot Client
 * Replaces native alert() and prompt() with custom modals that don't trigger focus loss
 */

import type { ModalType, ModalElements } from "../types/global.d.ts";

// Global modal container
let modalContainer: HTMLElement | null = null;

/**
 * Initialize modal container if it doesn't exist
 */
function initModalContainer(): HTMLElement {
  if (!modalContainer) {
    modalContainer = document.createElement("div");
    modalContainer.id = "ocot-modal-container";
    modalContainer.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1000000;
      pointer-events: none;
    `;
    document.body.appendChild(modalContainer);
  }
  return modalContainer;
}

/**
 * Create base modal structure
 */
export function createBaseModal(title: string = "", type: ModalType = "info"): ModalElements {
  const container = initModalContainer();

  const modal = document.createElement("div");
  modal.className = "ocot-modal-overlay";
  modal.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000001;
    pointer-events: all;
    opacity: 0;
    transition: opacity 0.2s ease-out;
  `;

  const modalContent = document.createElement("div");
  modalContent.className = "ocot-modal-content";
  modalContent.style.cssText = `
    background: var(--bg-primary, #23272f);
    border-radius: 12px;
    padding: 24px;
    min-width: 300px;
    max-width: 90%;
    max-height: 90%;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
    border: 1px solid var(--border-color, #404040);
    transform: translateY(-20px) scale(0.95);
    transition: transform 0.2s ease-out;
    overflow-y: auto;
  `;

  // Get icon and color based on type
  const typeConfig: Record<ModalType, { icon: string; color: string }> = {
    info: { icon: "ℹ️", color: "#00bfff" },
    success: { icon: "✅", color: "#28a745" },
    warning: { icon: "⚠️", color: "#ffc107" },
    error: { icon: "❌", color: "#dc3545" },
    question: { icon: "❓", color: "#6f42c1" },
    input: { icon: "📝", color: "#007bff" },
  };

  const config = typeConfig[type] || typeConfig.info;

  // Create header if title provided
  if (title) {
    const header = document.createElement("div");
    header.style.cssText = `
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
      border-bottom: 1px solid var(--border-color, #404040);
      padding-bottom: 12px;
    `;

    const titleElement = document.createElement("h3");
    titleElement.style.cssText = `
      margin: 0;
      color: ${config.color};
      font-size: 1.2rem;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 8px;
    `;
    titleElement.innerHTML = `${config.icon} ${title}`;

    const closeButton = document.createElement("button");
    closeButton.innerHTML = "&times;";
    closeButton.style.cssText = `
      background: none;
      border: none;
      color: #aaa;
      font-size: 24px;
      cursor: pointer;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 4px;
      transition: background-color 0.2s;
    `;

    closeButton.addEventListener("mouseenter", () => {
      closeButton.style.backgroundColor = "var(--border-color, #404040)";
      closeButton.style.color = "var(--text-primary, #fff)";
    });

    closeButton.addEventListener("mouseleave", () => {
      closeButton.style.backgroundColor = "transparent";
      closeButton.style.color = "var(--text-secondary, #aaa)";
    });

    header.appendChild(titleElement);
    header.appendChild(closeButton);
    modalContent.appendChild(header);

    // Return close button for external reference
    (modalContent as any)._closeButton = closeButton;
  }

  modal.appendChild(modalContent);
  container.appendChild(modal);

  // Animate in
  requestAnimationFrame(() => {
    modal.style.opacity = "1";
    modalContent.style.transform = "translateY(0) scale(1)";
  });

  return { modal, modalContent, container };
}

/**
 * Remove modal with animation
 */
export function removeModal(modal: HTMLElement): void {
  if (!modal || !modal.parentNode) return;

  modal.style.opacity = "0";
  const content = modal.querySelector(".ocot-modal-content") as HTMLElement | null;
  if (content) {
    content.style.transform = "translateY(-20px) scale(0.95)";
  }

  setTimeout(() => {
    if (modal.parentNode) {
      modal.parentNode.removeChild(modal);
    }

    // Clean up container if empty
    if (modalContainer && modalContainer.children.length === 0) {
      if (modalContainer.parentNode) {
        modalContainer.parentNode.removeChild(modalContainer);
      }
      modalContainer = null;
    }
  }, 200);
}

/**
 * Show custom alert modal (replacement for native alert)
 * @param message - Message to display
 * @param title - Modal title (optional)
 * @param type - Modal type (info, success, warning, error)
 * @returns Promise that resolves when modal is closed
 */
export function showModal(message: string, title: string = "", type: ModalType = "info"): Promise<void> {
  return new Promise((resolve) => {
    const { modal, modalContent } = createBaseModal(title, type);

    // Create message content
    const messageDiv = document.createElement("div");
    messageDiv.style.cssText = `
      color: var(--text-secondary, #d4d4d4);
      line-height: 1.5;
      margin-bottom: 20px;
      font-size: 0.95rem;
    `;
    messageDiv.innerHTML = message.replace(/\n/g, "<br>");
    modalContent.appendChild(messageDiv);

    // Create OK button
    const buttonContainer = document.createElement("div");
    buttonContainer.style.cssText = `
      display: flex;
      justify-content: flex-end;
      gap: 12px;
    `;

    const okButton = document.createElement("button");
    okButton.textContent = "OK";
    okButton.style.cssText = `
      padding: 10px 24px;
      background: var(--accent-color, #007bff);
      border: none;
      border-radius: 6px;
      color: var(--text-primary, white);
      cursor: pointer;
      font-size: 0.9rem;
      font-weight: 500;
      transition: background-color 0.2s;
    `;

    okButton.addEventListener("mouseenter", () => {
      okButton.style.backgroundColor = "var(--accent-hover, #0056b3)";
    });

    okButton.addEventListener("mouseleave", () => {
      okButton.style.backgroundColor = "var(--accent-color, #007bff)";
    });

    buttonContainer.appendChild(okButton);
    modalContent.appendChild(buttonContainer);

    // Event handlers
    const closeModal = () => {
      removeModal(modal);
      resolve();
    };

    okButton.addEventListener("click", closeModal);

    if ((modalContent as any)._closeButton) {
      (modalContent as any)._closeButton.addEventListener("click", closeModal);
    }

    // Close on Escape key
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        document.removeEventListener("keydown", handleKeyDown);
        closeModal();
      }
    };
    document.addEventListener("keydown", handleKeyDown);

    // Close on overlay click
    modal.addEventListener("click", (e: MouseEvent) => {
      if (e.target === modal) {
        closeModal();
      }
    });

    // Focus the OK button
    setTimeout(() => okButton.focus(), 100);
  });
}

/**
 * Show custom prompt modal (replacement for native prompt)
 * @param message - Message to display
 * @param defaultValue - Default input value
 * @param title - Modal title (optional)
 * @param inputType - Input type (text, password, url, etc.)
 * @returns Promise that resolves with input value or null if cancelled
 */
export function showInputModal(
  message: string,
  defaultValue: string = "",
  title: string = "",
  inputType: string = "text"
): Promise<string | null> {
  return new Promise((resolve) => {
    const { modal, modalContent } = createBaseModal(
      title || "Input Required",
      "input"
    );

    // Create message content
    const messageDiv = document.createElement("div");
    messageDiv.style.cssText = `
      color: var(--text-secondary, #d4d4d4);
      line-height: 1.5;
      margin-bottom: 16px;
      font-size: 0.95rem;
    `;
    messageDiv.innerHTML = message.replace(/\n/g, "<br>");
    modalContent.appendChild(messageDiv);

    // Create input field
    const inputField = document.createElement("input");
    inputField.type = inputType;
    inputField.value = defaultValue;
    inputField.style.cssText = `
      width: 100%;
      padding: 12px;
      background: var(--bg-secondary, #1e2126);
      border: 1px solid var(--border-color, #404040);
      border-radius: 6px;
      color: var(--text-secondary, #d4d4d4);
      font-size: 0.9rem;
      margin-bottom: 20px;
      outline: none;
      transition: border-color 0.2s;
    `;

    inputField.addEventListener("focus", () => {
      inputField.style.borderColor = "var(--accent-color, #007bff)";
      inputField.style.boxShadow =
        "0 0 0 2px rgba(var(--accent-color-rgb, 0, 123, 255), 0.25)";
    });

    inputField.addEventListener("blur", () => {
      inputField.style.borderColor = "var(--border-color, #404040)";
      inputField.style.boxShadow = "none";
    });

    modalContent.appendChild(inputField);

    // Create buttons
    const buttonContainer = document.createElement("div");
    buttonContainer.style.cssText = `
      display: flex;
      justify-content: flex-end;
      gap: 12px;
    `;

    const cancelButton = document.createElement("button");
    cancelButton.textContent = "Cancel";
    cancelButton.style.cssText = `
      padding: 10px 20px;
      background: #6c757d;
      border: none;
      border-radius: 6px;
      color: var(--text-primary, white);
      cursor: pointer;
      font-size: 0.9rem;
      font-weight: 500;
      transition: background-color 0.2s;
    `;

    const okButton = document.createElement("button");
    okButton.textContent = "OK";
    okButton.style.cssText = `
      padding: 10px 24px;
      background: var(--accent-color, #007bff);
      border: none;
      border-radius: 6px;
      color: var(--text-primary, white);
      cursor: pointer;
      font-size: 0.9rem;
      font-weight: 500;
      transition: background-color 0.2s;
    `;

    // Button hover effects
    cancelButton.addEventListener("mouseenter", () => {
      cancelButton.style.backgroundColor = "#545b62";
    });

    cancelButton.addEventListener("mouseleave", () => {
      cancelButton.style.backgroundColor = "#6c757d";
    });

    okButton.addEventListener("mouseenter", () => {
      okButton.style.backgroundColor = "var(--accent-hover, #0056b3)";
    });

    okButton.addEventListener("mouseleave", () => {
      okButton.style.backgroundColor = "var(--accent-color, #007bff)";
    });

    buttonContainer.appendChild(cancelButton);
    buttonContainer.appendChild(okButton);
    modalContent.appendChild(buttonContainer);

    // Event handlers
    const closeModal = (value: string | null = null) => {
      removeModal(modal);
      resolve(value);
    };

    okButton.addEventListener("click", () => {
      closeModal(inputField.value);
    });

    cancelButton.addEventListener("click", () => {
      closeModal(null);
    });

    if ((modalContent as any)._closeButton) {
      (modalContent as any)._closeButton.addEventListener("click", () => {
        closeModal(null);
      });
    }

    // Handle Enter and Escape keys
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        document.removeEventListener("keydown", handleKeyDown);
        closeModal(inputField.value);
      } else if (e.key === "Escape") {
        document.removeEventListener("keydown", handleKeyDown);
        closeModal(null);
      }
    };
    document.addEventListener("keydown", handleKeyDown);

    // Close on overlay click
    modal.addEventListener("click", (e: MouseEvent) => {
      if (e.target === modal) {
        closeModal(null);
      }
    });

    // Focus and select the input field
    setTimeout(() => {
      inputField.focus();
      inputField.select();
    }, 100);
  });
}

/**
 * Show custom confirmation modal (replacement for native confirm)
 * @param message - Message to display
 * @param title - Modal title (optional)
 * @param confirmText - Confirm button text (default: "Yes")
 * @param cancelText - Cancel button text (default: "No")
 * @returns Promise that resolves with true if confirmed, false if cancelled
 */
export function showConfirmModal(
  message: string,
  title: string = "",
  confirmText: string = "Yes",
  cancelText: string = "No"
): Promise<boolean> {
  return new Promise((resolve) => {
    const { modal, modalContent } = createBaseModal(
      title || "Confirm Action",
      "question"
    );

    // Create message content
    const messageDiv = document.createElement("div");
    messageDiv.style.cssText = `
      color: var(--text-secondary, #d4d4d4);
      line-height: 1.5;
      margin-bottom: 20px;
      font-size: 0.95rem;
    `;
    messageDiv.innerHTML = message.replace(/\n/g, "<br>");
    modalContent.appendChild(messageDiv);

    // Create buttons
    const buttonContainer = document.createElement("div");
    buttonContainer.style.cssText = `
      display: flex;
      justify-content: flex-end;
      gap: 12px;
    `;

    const cancelButton = document.createElement("button");
    cancelButton.textContent = cancelText;
    cancelButton.style.cssText = `
      padding: 10px 20px;
      background: #6c757d;
      border: none;
      border-radius: 6px;
      color: var(--text-primary, white);
      cursor: pointer;
      font-size: 0.9rem;
      font-weight: 500;
      transition: background-color 0.2s;
    `;

    const confirmButton = document.createElement("button");
    confirmButton.textContent = confirmText;
    confirmButton.style.cssText = `
      padding: 10px 24px;
      background: #dc3545;
      border: none;
      border-radius: 6px;
      color: var(--text-primary, white);
      cursor: pointer;
      font-size: 0.9rem;
      font-weight: 500;
      transition: background-color 0.2s;
    `;

    // Button hover effects
    cancelButton.addEventListener("mouseenter", () => {
      cancelButton.style.backgroundColor = "#545b62";
    });

    cancelButton.addEventListener("mouseleave", () => {
      cancelButton.style.backgroundColor = "#6c757d";
    });

    confirmButton.addEventListener("mouseenter", () => {
      confirmButton.style.backgroundColor = "#c82333";
    });

    confirmButton.addEventListener("mouseleave", () => {
      confirmButton.style.backgroundColor = "#dc3545";
    });

    buttonContainer.appendChild(cancelButton);
    buttonContainer.appendChild(confirmButton);
    modalContent.appendChild(buttonContainer);

    // Event handlers
    const closeModal = (confirmed: boolean = false) => {
      removeModal(modal);
      resolve(confirmed);
    };

    confirmButton.addEventListener("click", () => {
      closeModal(true);
    });

    cancelButton.addEventListener("click", () => {
      closeModal(false);
    });

    if ((modalContent as any)._closeButton) {
      (modalContent as any)._closeButton.addEventListener("click", () => {
        closeModal(false);
      });
    }

    // Handle Enter and Escape keys
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Enter") {
        document.removeEventListener("keydown", handleKeyDown);
        closeModal(true);
      } else if (e.key === "Escape") {
        document.removeEventListener("keydown", handleKeyDown);
        closeModal(false);
      }
    };
    document.addEventListener("keydown", handleKeyDown);

    // Close on overlay click
    modal.addEventListener("click", (e: MouseEvent) => {
      if (e.target === modal) {
        closeModal(false);
      }
    });

    // Focus the cancel button by default (safer)
    setTimeout(() => cancelButton.focus(), 100);
  });
}
