/**
 * This file contains utility functions that can be used throughout the application.
 */
import { APP_VERSION } from '../constants/version.js';
import { getCurrentEnvConfig } from '../constants/env.js';

/**
 * Loads a JSON file and returns its contents as an object.
 * @param file - The path to the JSON file (relative to public root or absolute).
 * @returns The parsed JSON object, or null on error.
 */
export async function loadJson<T = any>(file: string): Promise<T | null> {
  try {
    const response = await fetch(file);
    if (!response.ok)
      throw new Error(`Failed to load ${file}: ${response.statusText}`);
    return await response.json();
  } catch (err) {
    console.error(err);
    return null;
  }
}

/**
 * Gets the current version from embedded constant or package.json fallback
 * @returns The current version string
 */
export async function getCurrentVersion(): Promise<string> {
  // Primary source: embedded version constant (works in all environments)
  if (APP_VERSION) {
    return APP_VERSION;
  }

  // Fallback: try to fetch from package.json (only works when hosted normally)
  try {
    const packageResponse = await fetch('/package.json');
    if (packageResponse.ok) {
      const packageData = await packageResponse.json();
      return packageData.version || "2.4.7";
    }
  } catch (error) {
    console.warn('Could not fetch package.json, using embedded version');
  }

  return "2.4.7"; // Final fallback
}

/**
 * Gets the latest version from jsDelivr CDN
 * @returns Object containing current and latest version info, or null on error
 */
export async function getLatestVersionInfo(): Promise<{
  currentVersion: string;
  latestVersion: string | null;
  isUpToDate: boolean;
  cleanLatestVersion: string | null;
  cleanCurrentVersion: string;
} | null> {
  try {
    const currentVersion = await getCurrentVersion();

    // Fetch latest version from jsDelivr API
    const response = await fetch('https://data.jsdelivr.com/v1/package/gh/asc2563/proxy-client2.0Rewrite', {
      headers: {
        'Accept': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const data = await response.json();
    const latestVersion = data.tags?.[0]?.name || data.versions?.[0] || null;

    if (!latestVersion) {
      return {
        currentVersion,
        latestVersion: null,
        isUpToDate: true,
        cleanLatestVersion: null,
        cleanCurrentVersion: currentVersion.replace(/^v/, '')
      };
    }

    // Clean version strings (remove 'v' prefix if present)
    const cleanLatestVersion = latestVersion.replace(/^v/, '');
    const cleanCurrentVersion = currentVersion.replace(/^v/, '');

    // Compare versions
    const isUpToDate = compareVersions(cleanCurrentVersion, cleanLatestVersion) >= 0;

    return {
      currentVersion,
      latestVersion,
      isUpToDate,
      cleanLatestVersion,
      cleanCurrentVersion
    };

  } catch (error) {
    console.warn('Latest version check failed:', error);
    const currentVersion = await getCurrentVersion();
    return {
      currentVersion,
      latestVersion: null,
      isUpToDate: true,
      cleanLatestVersion: null,
      cleanCurrentVersion: currentVersion.replace(/^v/, '')
    };
  }
}

/**
 * Simple version comparison function
 * @param version1 - First version to compare
 * @param version2 - Second version to compare
 * @returns 1 if version1 > version2, -1 if version1 < version2, 0 if equal
 */
export function compareVersions(version1: string, version2: string): number {
  const v1parts = version1.split('.').map(Number);
  const v2parts = version2.split('.').map(Number);

  const maxLength = Math.max(v1parts.length, v2parts.length);

  for (let i = 0; i < maxLength; i++) {
    const v1part = v1parts[i] || 0;
    const v2part = v2parts[i] || 0;

    if (v1part > v2part) return 1;
    if (v1part < v2part) return -1;
  }

  return 0; // versions are equal
}

/**
 * Universal data loader that adapts strategy based on environment configuration
 * @param dataName - The name of the data file (e.g., 'games', 'scripts', 'bookmarklets')
 * @param exportName - The export name from the TypeScript fallback (defaults to `${dataName}List`)
 * @returns The loaded data array, or empty array on error
 */
export async function loadData<T = any>(dataName: string, exportName?: string): Promise<T[]> {
  const fallbackExportName = exportName || `${dataName}List`;
  const config = getCurrentEnvConfig();

  if (config.debugLogging) {
    console.log(`🔄 loadData called for: ${dataName} (${config.name} mode), export: ${fallbackExportName}`);
  }

  // Try CDN first if enabled (production mode)
  if (config.useCDN) {
    try {
      const currentVersion = await getCurrentVersion();
      const cdnUrl = `https://cdn.jsdelivr.net/gh/asc2563/ocot-client@${currentVersion}/src/data/json/${dataName}.json`;

      if (config.debugLogging) {
        console.log(`🌐 Trying CDN URL: ${cdnUrl}`);
      }

      const response = await fetch(cdnUrl);
      if (response.ok) {
        const cdnData = await response.json();
        if (cdnData && Array.isArray(cdnData)) {
          if (config.debugLogging) {
            console.log(`✅ Loaded ${dataName} from CDN (${cdnData.length} items)`);
          }
          return cdnData;
        } else {
          if (config.debugLogging) {
            console.log(`🌐 CDN data invalid or empty for ${dataName}:`, cdnData);
          }
        }
      } else {
        if (config.debugLogging) {
          console.warn(`🌐 CDN fetch failed with status ${response.status}: ${response.statusText}`);
        }
      }
    } catch (error) {
      if (config.debugLogging) {
        console.warn(`🌐 Failed to load ${dataName} from CDN:`, error instanceof Error ? error.message : String(error));
      }
    }
  }

  // Try local JSON if enabled
  if (config.useLocalJSON) {
    try {
      const jsonPath = `/src/data/json/${dataName}.json`;

      if (config.debugLogging) {
        console.log(`📂 Trying local JSON path: ${jsonPath}`);
      }

      const jsonData = await loadJson<T[]>(jsonPath);
      if (jsonData && Array.isArray(jsonData)) {
        if (config.debugLogging) {
          console.log(`✅ Loaded ${dataName} from local JSON (${jsonData.length} items)`);
        }
        return jsonData;
      } else {
        if (config.debugLogging) {
          console.log(`📂 Local JSON data invalid or empty for ${dataName}:`, jsonData);
        }
      }
    } catch (error) {
      if (config.debugLogging) {
        console.warn(`📂 Failed to load ${dataName} from local JSON:`, error instanceof Error ? error.message : String(error));
      }
    }
  }

  // Fallback to TypeScript module if enabled (bundled environments)
  if (config.useTypeScriptFallback) {
    // Try multiple potential paths for different environments
    const tsPaths = [
      `../data/typescript/${dataName}.js`,  // Development/relative path
      `build/data/typescript/${dataName}.js`,  // Bundled absolute path
      `./build/data/typescript/${dataName}.js`,  // Bundled with ./
      `/build/data/typescript/${dataName}.js`   // Bundled with leading /
    ];

    for (const tsPath of tsPaths) {
      try {
        if (config.debugLogging) {
          console.log(`📦 Trying TypeScript import: ${tsPath}`);
        }

        const module = await import(tsPath);

        if (config.debugLogging) {
          console.log(`📦 Module imported successfully from ${tsPath}, exports:`, Object.keys(module));
        }

        const fallbackData = module[fallbackExportName];

        if (fallbackData && Array.isArray(fallbackData)) {
          if (config.debugLogging) {
            console.log(`✅ Loaded ${dataName} from TypeScript fallback (${fallbackData.length} items)`);
          }
          return fallbackData;
        } else {
          if (config.debugLogging) {
            console.error(`📦 TypeScript fallback for ${dataName} does not export ${fallbackExportName} or it's not an array. Available exports:`, Object.keys(module), 'Data:', fallbackData);
          }
        }
      } catch (error) {
        if (config.debugLogging) {
          console.warn(`📦 Failed to load ${dataName} from ${tsPath}:`, error instanceof Error ? error.message : String(error));
        }
        continue; // Try the next path
      }
    }
  }

  const enabledMethods = [
    config.useCDN && 'CDN',
    config.useLocalJSON && 'local JSON',
    config.useTypeScriptFallback && 'TypeScript sources'
  ].filter(Boolean).join(', ');

  console.error(`❌ Failed to load ${dataName} from all enabled methods: ${enabledMethods}`);
  return [];
}
