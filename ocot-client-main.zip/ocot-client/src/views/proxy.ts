// @ts-nocheck
import { getProxySettings } from "./settings.js";

// Exported function to create the Proxy view
// @ts-nocheck
export default function createProxyView() {
  const proxyView = document.createElement("div");
  proxyView.style.width = "100%";
  proxyView.style.height = "100%";
  proxyView.style.display = "flex";
  proxyView.style.flexDirection = "column";

  // Create toolbar
  const toolbar = document.createElement("div");
  toolbar.style.cssText = `
    display: flex;
    justify-content: flex-end;
    align-items: center;
    padding: 8px 12px;
    background: #292d36;
    border-bottom: 1px solid #404040;
    min-height: 40px;
  `;

  // Create about:blank button
  const aboutBlankBtn = document.createElement("button");
  aboutBlankBtn.innerHTML = "⧉"; // Square with arrow icon
  aboutBlankBtn.title = "Open in about:blank";
  aboutBlankBtn.style.cssText = `
    background: #2d323e;
    border: 1px solid #404040;
    border-radius: 4px;
    color: #fff;
    padding: 6px 10px;
    cursor: pointer;
    font-size: 14px;
    transition: all 0.2s ease;
    outline: none;
    margin-right: 8px;
  `;

  // Add hover effect for about:blank button
  aboutBlankBtn.addEventListener("mouseenter", () => {
    aboutBlankBtn.style.background = "var(--accent-color, #007acc)";
    aboutBlankBtn.style.borderColor = "var(--accent-color, #007acc)";
  });

  aboutBlankBtn.addEventListener("mouseleave", () => {
    aboutBlankBtn.style.background = "#2d323e";
    aboutBlankBtn.style.borderColor = "#404040";
  });

  // Create fullscreen button
  const fullscreenBtn = document.createElement("button");
  fullscreenBtn.innerHTML = "⛶"; // Square icon for fullscreen
  fullscreenBtn.title = "Enter Fullscreen";
  fullscreenBtn.style.cssText = `
    background: #2d323e;
    border: 1px solid #404040;
    border-radius: 4px;
    color: #fff;
    padding: 6px 10px;
    cursor: pointer;
    font-size: 14px;
    transition: all 0.2s ease;
    outline: none;
  `;

  // Add hover effect for fullscreen button
  fullscreenBtn.addEventListener("mouseenter", () => {
    fullscreenBtn.style.background = "var(--accent-color, #007acc)";
    fullscreenBtn.style.borderColor = "var(--accent-color, #007acc)";
  });

  fullscreenBtn.addEventListener("mouseleave", () => {
    fullscreenBtn.style.background = "#2d323e";
    fullscreenBtn.style.borderColor = "#404040";
  });

  const iframe = document.createElement("iframe");

  // Add unique ID for auto-hide detection
  iframe.id = "ocot-proxy-iframe";

  // Get proxy URL from settings
  const proxySettings = getProxySettings();
  iframe.src = proxySettings.url || "https://work.benjaminbartlett.net/";

  iframe.style.width = "100%";
  iframe.style.height = "100%";
  iframe.style.border = "none";
  iframe.style.flex = "1";

  // Function to reload the proxy iframe with current settings
  function reloadProxyIframe() {
    const currentSettings = getProxySettings();
    const newUrl = currentSettings.url || "https://work.benjaminbartlett.net/";

    // Only reload if the URL has actually changed
    if (iframe.src !== newUrl) {
      console.log("Proxy: Reloading iframe due to settings change", {
        oldUrl: iframe.src,
        newUrl: newUrl,
      });
      iframe.src = newUrl;
    }
  }

  // Listen for storage events (cross-tab proxy settings changes)
  window.addEventListener("storage", (e) => {
    if (e.key === "proxyClientProxySettings") {
      console.log("Proxy: Storage event detected for proxy settings");
      reloadProxyIframe();
    }
  });

  // Listen for immediate settings changes within the same page
  window.addEventListener("proxySettingsChanged", (e) => {
    console.log("Proxy: Settings changed event received", e.detail);
    reloadProxyIframe();
  });

  // About:blank functionality
  aboutBlankBtn.addEventListener("click", () => {
    openInAboutBlank();
  });

  function openInAboutBlank() {
    const proxySettings = getProxySettings();
    const proxyUrl = proxySettings.url || "https://work.benjaminbartlett.net/";

    const win = window.open();
    if (!win) {
      console.warn("Popup blocked - unable to open about:blank window");
      return;
    }

    const iframe = win.document.createElement("iframe");
    iframe.style.cssText =
      "position:fixed;width:100vw;height:100vh;top:0px;left:0px;right:0px;bottom:0px;z-index:2147483647;background-color:white;border:none;";
    iframe.src = proxyUrl;
    win.document.body.appendChild(iframe);
  }

  // Fullscreen functionality
  fullscreenBtn.addEventListener("click", () => {
    enterFullscreen();
  });

  function enterFullscreen() {
    try {
      if (iframe.requestFullscreen) {
        iframe.requestFullscreen();
      } else if (iframe.webkitRequestFullscreen) {
        iframe.webkitRequestFullscreen();
      } else if (iframe.msRequestFullscreen) {
        iframe.msRequestFullscreen();
      } else if (iframe.mozRequestFullScreen) {
        iframe.mozRequestFullScreen();
      }
    } catch (error) {
      console.warn("Fullscreen not supported or blocked:", error);
    }
  }

  // Listen for fullscreen changes to update button state
  function handleFullscreenChange() {
    const isFullscreen =
      document.fullscreenElement === iframe ||
      document.webkitFullscreenElement === iframe ||
      document.msFullscreenElement === iframe ||
      document.mozFullScreenElement === iframe;

    if (isFullscreen) {
      fullscreenBtn.innerHTML = "⛶";
      fullscreenBtn.title = "Exit Fullscreen (Press Esc)";
    } else {
      fullscreenBtn.innerHTML = "⛶";
      fullscreenBtn.title = "Enter Fullscreen";
    }
  }

  // Add fullscreen event listeners
  document.addEventListener("fullscreenchange", handleFullscreenChange);
  document.addEventListener("webkitfullscreenchange", handleFullscreenChange);
  document.addEventListener("msfullscreenchange", handleFullscreenChange);
  document.addEventListener("mozfullscreenchange", handleFullscreenChange);

  // Assemble components
  toolbar.appendChild(aboutBlankBtn);
  toolbar.appendChild(fullscreenBtn);
  proxyView.appendChild(toolbar);
  proxyView.appendChild(iframe);
  return proxyView;
}
