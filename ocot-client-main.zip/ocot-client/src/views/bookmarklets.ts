// Exported function to create the Bookmarklets view
import { injectAppCSS } from "../css.js";
import { loadData } from "../utils/helpers.js";

interface BookmarkletData {
  id: string;
  name: string;
  description: string;
  category: string;
  bookmarkletCode: string;
}

export default function createBookmarkletsView() {
  injectAppCSS();

  const bookmarkletsView = document.createElement("div");
  bookmarkletsView.className = "games-view";

  // Create loading indicator
  const loadingDiv = document.createElement("div");
  loadingDiv.style.cssText = `
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 200px;
    color: var(--text-secondary, #d4d4d4);
    font-size: 1.1rem;
  `;
  loadingDiv.textContent = "Loading bookmarklets...";
  bookmarkletsView.appendChild(loadingDiv);

  // Load bookmarklets data
  loadBookmarklets(bookmarkletsView, loadingDiv);

  return bookmarkletsView;
}

async function loadBookmarklets(container: HTMLElement, loadingDiv: HTMLElement) {
  // Use the new universal data loader
  const bookmarklets = await loadData<BookmarkletData>('bookmarklets');

  if (bookmarklets.length === 0) {
    showErrorMessage(container, loadingDiv);
    return;
  }

  // Remove loading indicator
  container.removeChild(loadingDiv);

  // Create category groups
  const categories = groupByCategory(bookmarklets);
  createBookmarkletSections(container, categories);

}

function groupByCategory(bookmarklets: BookmarkletData[]): Record<string, BookmarkletData[]> {
  return bookmarklets.reduce((groups, bookmarklet) => {
    const category = bookmarklet.category || 'other';
    if (!groups[category]) {
      groups[category] = [];
    }
    groups[category].push(bookmarklet);
    return groups;
  }, {} as Record<string, BookmarkletData[]>);
}

function createBookmarkletSections(container: HTMLElement, categories: Record<string, BookmarkletData[]>) {
  const categoryNames: Record<string, string> = {
    utility: '🔧 Utility',
    gaming: '🎮 Gaming',
    privacy: '🔒 Privacy',
    other: '📄 Other'
  };

  Object.entries(categories).forEach(([category, bookmarklets]) => {
    const section = document.createElement("div");
    section.style.cssText = `
      margin-bottom: 32px;
    `;

    // Category header
    const header = document.createElement("h2");
    header.textContent = categoryNames[category] || `📄 ${category.charAt(0).toUpperCase() + category.slice(1)}`;
    header.style.cssText = `
      color: var(--text-primary, #fff);
      font-size: 1.4rem;
      margin-bottom: 16px;
      font-weight: 600;
      border-bottom: 2px solid var(--accent-color, #00bfff);
      padding-bottom: 8px;
    `;
    section.appendChild(header);

    // Create the grid list for this category
    const list = document.createElement("div");
    list.className = "games-list";

    bookmarklets.forEach((bookmarklet) => {
      const item = document.createElement("div");
      item.className = "game-item";
      item.tabIndex = 0;

      // Create anchor element properly
      const anchor = document.createElement("a");
      anchor.href = bookmarklet.bookmarkletCode;
      anchor.draggable = true;
      anchor.textContent = bookmarklet.name;

      // Add description as title attribute
      anchor.title = bookmarklet.description;

      const gameType = document.createElement("div");
      gameType.className = "game-type";
      gameType.textContent = "Bookmarklet";

      const description = document.createElement("div");
      description.style.cssText = `
        color: var(--text-secondary, #d4d4d4);
        font-size: 0.85rem;
        margin-top: 4px;
        line-height: 1.2;
      `;
      description.textContent = bookmarklet.description;

      item.appendChild(anchor);
      item.appendChild(gameType);
      item.appendChild(description);

      // Prevent normal navigation but allow dragging
      anchor.addEventListener("click", (e) => {
        e.preventDefault();
        // Copy to clipboard when clicked
        navigator.clipboard.writeText(bookmarklet.bookmarkletCode).then(() => {
          const originalText = gameType.textContent;
          gameType.textContent = "Copied!";
          gameType.style.color = "#28a745";
          setTimeout(() => {
            gameType.textContent = originalText;
            gameType.style.color = "";
          }, 1500);
        }).catch(() => {
          // Fallback for browsers without clipboard API
          const textarea = document.createElement("textarea");
          textarea.value = bookmarklet.bookmarkletCode;
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand('copy');
          document.body.removeChild(textarea);

          const originalText = gameType.textContent;
          gameType.textContent = "Copied!";
          gameType.style.color = "#28a745";
          setTimeout(() => {
            gameType.textContent = originalText;
            gameType.style.color = "";
          }, 1500);
        });
      });

      // Set up drag data for proper bookmarking
      anchor.addEventListener("dragstart", (e) => {
        if (e.dataTransfer) {
          e.dataTransfer.setData("text/uri-list", bookmarklet.bookmarkletCode);
          e.dataTransfer.setData("text/plain", bookmarklet.bookmarkletCode);
          e.dataTransfer.setData(
            "text/html",
            `<a href="${bookmarklet.bookmarkletCode}">${bookmarklet.name}</a>`
          );
        }
      });

      list.appendChild(item);
    });

    section.appendChild(list);
    container.appendChild(section);
  });
}

function showErrorMessage(container: HTMLElement, loadingDiv: HTMLElement) {
  container.removeChild(loadingDiv);

  const errorDiv = document.createElement("div");
  errorDiv.style.cssText = `
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    min-height: 200px;
    color: var(--text-secondary, #d4d4d4);
    text-align: center;
    padding: 24px;
  `;

  errorDiv.innerHTML = `
    <div style="font-size: 3rem; margin-bottom: 16px;">⚠️</div>
    <div style="font-size: 1.2rem; font-weight: 600; margin-bottom: 8px;">
      Failed to Load Bookmarklets
    </div>
    <div style="font-size: 1rem; line-height: 1.5;">
      Could not load bookmarklet data. Please check your network connection<br>
      and try refreshing the page.
    </div>
  `;

  container.appendChild(errorDiv);
}
