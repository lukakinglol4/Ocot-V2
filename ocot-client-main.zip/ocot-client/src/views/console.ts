// @ts-nocheck
import { injectAppCSS } from "../css.js";

// Exported function to create the Console view
export default function createConsoleView() {
  // Inject shared CSS
  injectAppCSS();

  const consoleView = document.createElement("div");
  consoleView.className = "card-grid-view";

  consoleView.innerHTML = `
    <div class="console-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
      <h2 style="color: #00bfff; margin: 0; font-size: 1.5rem;">JavaScript Console</h2>
      <div style="display: flex; gap: 10px;">
        <button id="dev-tools-btn" class="games-tab" style="border-radius: 6px; background: #6f42c1;">🔧 Developer Tools</button>
        <button id="run-btn" class="games-tab" style="border-radius: 6px; background: #28a745;">▶ Run</button>
        <button id="clear-btn" class="games-tab" style="border-radius: 6px; background: #dc3545;">Clear</button>
      </div>
    </div>
    
    <div style="display: grid; grid-template-rows: 1fr auto 200px; gap: 16px; height: 500px;">
      <div class="code-editor-container">
        <div style="background: #292d36; border-radius: 8px 8px 0 0; padding: 8px 16px; border-bottom: 1px solid #404040;">
          <span style="color: #00bfff; font-size: 0.9rem; font-weight: 600;">Code Editor</span>
        </div>
        <textarea id="code-input" 
                  placeholder="// Write your JavaScript code here...
console.log('Hello World!');
Math.sqrt(16);
[1,2,3].map(x => x * 2);"
                  style="width: 100%; height: calc(100% - 40px); background: #1e1e1e; color: #d4d4d4; 
                         border: none; border-radius: 0 0 8px 8px; padding: 16px; font-family: 'Consolas', 'Courier New', monospace; 
                         font-size: 14px; resize: none; outline: none; line-height: 1.5;"></textarea>
      </div>
      
      <div class="output-container">
        <div style="background: #292d36; border-radius: 8px 8px 0 0; padding: 8px 16px; border-bottom: 1px solid #404040;">
          <span style="color: #00bfff; font-size: 0.9rem; font-weight: 600;">Output</span>
        </div>
        <div id="output" 
             style="width: 100%; height: calc(100% - 40px); background: #1a1a1a; color: #d4d4d4; 
                    border: none; border-radius: 0 0 8px 8px; padding: 16px; font-family: 'Consolas', 'Courier New', monospace; 
                    font-size: 14px; overflow-y: auto; white-space: pre-wrap;"></div>
      </div>
    </div>
  `;

  // Add console-specific CSS
  const style = document.createElement("style");
  style.textContent = `
    .code-editor-container, .output-container {
      background: #292d36;
      border-radius: 8px;
      border: 1px solid #404040;
      overflow: hidden;
    }
    
    #code-input:focus {
      box-shadow: 0 0 0 2px rgba(0, 191, 255, 0.3);
    }
    
    .console-output-line {
      margin: 4px 0;
      padding: 2px 0;
    }
    
    .console-error {
      color: #f85149;
    }
    
    .console-warning {
      color: #d29922;
    }
    
    .console-success {
      color: #56d364;
    }
    
    .console-info {
      color: #79c0ff;
    }
    
    .console-timestamp {
      color: #7d8590;
      font-size: 12px;
    }
  `;
  document.head.appendChild(style);

  const codeInput = consoleView.querySelector("#code-input");
  const output = consoleView.querySelector("#output");
  const runBtn = consoleView.querySelector("#run-btn");
  const clearBtn = consoleView.querySelector("#clear-btn");
  const devToolsBtn = consoleView.querySelector("#dev-tools-btn");

  // Console log override to capture output
  let originalConsole = {};
  let consoleOutput = [];

  function initializeConsole() {
    // Store original console methods
    originalConsole.log = console.log;
    originalConsole.error = console.error;
    originalConsole.warn = console.warn;
    originalConsole.info = console.info;

    // Override console methods
    console.log = (...args) => {
      originalConsole.log(...args);
      addToOutput(args.map((arg) => formatValue(arg)).join(" "), "info");
    };

    console.error = (...args) => {
      originalConsole.error(...args);
      addToOutput(args.map((arg) => formatValue(arg)).join(" "), "error");
    };

    console.warn = (...args) => {
      originalConsole.warn(...args);
      addToOutput(args.map((arg) => formatValue(arg)).join(" "), "warning");
    };

    console.info = (...args) => {
      originalConsole.info(...args);
      addToOutput(args.map((arg) => formatValue(arg)).join(" "), "info");
    };
  }

  function restoreConsole() {
    console.log = originalConsole.log;
    console.error = originalConsole.error;
    console.warn = originalConsole.warn;
    console.info = originalConsole.info;
  }

  function formatValue(value) {
    if (typeof value === "string") return `"${value}"`;
    if (typeof value === "object") {
      try {
        return JSON.stringify(value, null, 2);
      } catch {
        return String(value);
      }
    }
    return String(value);
  }

  function addToOutput(message, type = "info") {
    const timestamp = new Date().toLocaleTimeString();
    const line = document.createElement("div");
    line.className = `console-output-line console-${type}`;
    line.innerHTML = `<span class="console-timestamp">[${timestamp}]</span> ${message}`;
    output.appendChild(line);
    output.scrollTop = output.scrollHeight;
  }

  function executeCode() {
    const code = codeInput.value.trim();
    if (!code) {
      addToOutput("No code to execute.", "warning");
      return;
    }

    // Add the code being executed to output
    addToOutput(`> ${code}`, "info");

    try {
      // Basic input validation - reject potentially dangerous patterns
      const dangerousPatterns = [
        /document\.write/i,
        /window\.location/i,
        /eval\s*\(/i,
        /setTimeout\s*\(/i,
        /setInterval\s*\(/i,
        /alert\s*\(/i,
        /confirm\s*\(/i,
      ];

      const isDangerous = dangerousPatterns.some((pattern) =>
        pattern.test(code)
      );
      if (isDangerous) {
        addToOutput(
          "Error: Potentially unsafe code detected. Please use safer alternatives.",
          "error"
        );
        return;
      }

      initializeConsole();

      // Execute the code
      let result;
      try {
        // First try as an expression (for simple expressions like 2+2, Math.sqrt(16))
        result = Function('"use strict"; return (' + code + ")")();
      } catch (expressionError) {
        // If that fails, try as statements (for console.log, variable declarations, etc.)
        try {
          result = Function('"use strict"; ' + code)();
        } catch (statementError) {
          // If both fail, throw the original expression error (more helpful)
          throw expressionError;
        }
      }

      // Show result if it's not undefined
      if (result !== undefined) {
        addToOutput(`← ${formatValue(result)}`, "success");
      }
    } catch (error) {
      addToOutput(`Error: ${error.name}: ${error.message}`, "error");
    } finally {
      restoreConsole();
    }
  }

  function clearOutput() {
    output.innerHTML = "";
    addToOutput("Console cleared.", "info");
  }

  // Developer Tools Window
  function createDeveloperToolsWindow() {
    // Check if developer tools window already exists
    const existingWindow = document.getElementById("dev-tools-window");
    if (existingWindow) {
      existingWindow.style.display = "flex";
      return;
    }

    const devWindow = document.createElement("div");
    devWindow.id = "dev-tools-window";
    devWindow.style.cssText = `
      position: fixed;
      top: 10%;
      left: 10%;
      width: 80%;
      height: 70%;
      background: #23272f;
      border: 1px solid #404040;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
      z-index: 100001;
      display: flex;
      flex-direction: column;
      color: #fff;
      font-family: system-ui, -apple-system, sans-serif;
    `;

    // Create top bar
    const topBar = document.createElement("div");
    topBar.style.cssText = `
      height: 40px;
      background: linear-gradient(135deg, #23272f, #2a2e37);
      border-bottom: 1px solid #404040;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 16px;
      border-radius: 12px 12px 0 0;
      cursor: move;
      user-select: none;
    `;

    const title = document.createElement("div");
    title.innerHTML = `<span style="font-size: 1.1rem;">🔧</span> <span style="color: #00bfff; font-weight: 600;">Developer Tools</span>`;

    const closeBtn = document.createElement("button");
    closeBtn.innerHTML = "×";
    closeBtn.style.cssText = `
      background: #ef4444;
      border: none;
      border-radius: 4px;
      color: white;
      width: 24px;
      height: 24px;
      cursor: pointer;
      font-size: 16px;
      font-weight: bold;
    `;
    closeBtn.addEventListener("click", () => devWindow.remove());

    topBar.appendChild(title);
    topBar.appendChild(closeBtn);

    // Create tab navigation
    const tabNav = document.createElement("div");
    tabNav.style.cssText = `
      display: flex;
      background: #292d36;
      border-bottom: 1px solid #404040;
      padding: 0 16px;
    `;

    const tabs = [
      { id: "json", label: "JSON Formatter", icon: "📄" },
      { id: "css", label: "CSS Editor", icon: "🎨" },
      { id: "inspector", label: "HTML Inspector", icon: "🔍" }
    ];

    let activeTab = "json";
    const tabButtons = {};
    const tabContents = {};

    tabs.forEach(tab => {
      const tabBtn = document.createElement("button");
      tabBtn.innerHTML = `${tab.icon} ${tab.label}`;
      tabBtn.style.cssText = `
        background: none;
        border: none;
        color: #aaa;
        padding: 12px 16px;
        cursor: pointer;
        border-bottom: 2px solid transparent;
        transition: all 0.2s;
      `;

      if (tab.id === activeTab) {
        tabBtn.style.color = "#00bfff";
        tabBtn.style.borderBottomColor = "#00bfff";
      }

      tabBtn.addEventListener("click", () => switchTab(tab.id));
      tabButtons[tab.id] = tabBtn;
      tabNav.appendChild(tabBtn);
    });

    // Create content area
    const contentArea = document.createElement("div");
    contentArea.style.cssText = `
      flex: 1;
      padding: 20px;
      overflow-y: auto;
    `;

    // JSON Formatter Tab
    const jsonContent = document.createElement("div");
    jsonContent.style.display = "block";
    jsonContent.innerHTML = `
      <div style="margin-bottom: 16px;">
        <h3 style="color: #00bfff; margin: 0 0 12px 0;">JSON Formatter & Validator</h3>
        <div style="display: flex; gap: 12px; margin-bottom: 12px;">
          <button id="format-json" style="background: #28a745; border: none; color: white; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Format</button>
          <button id="minify-json" style="background: #ffc107; border: none; color: black; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Minify</button>
          <button id="validate-json" style="background: #17a2b8; border: none; color: white; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Validate</button>
        </div>
      </div>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; height: calc(100% - 80px);">
        <div>
          <label style="display: block; margin-bottom: 8px; color: #00bfff;">Input JSON:</label>
          <textarea id="json-input" placeholder='{"name": "John", "age": 30}' style="width: 100%; height: 300px; background: #1e1e1e; color: #d4d4d4; border: 1px solid #404040; border-radius: 4px; padding: 12px; font-family: monospace; resize: none;"></textarea>
        </div>
        <div>
          <label style="display: block; margin-bottom: 8px; color: #00bfff;">Output:</label>
          <div id="json-output" style="width: 100%; height: 300px; background: #1a1a1a; border: 1px solid #404040; border-radius: 4px; padding: 12px; font-family: monospace; overflow-y: auto; white-space: pre-wrap; color: #d4d4d4;"></div>
        </div>
      </div>
    `;

    // CSS Editor Tab
    const cssContent = document.createElement("div");
    cssContent.style.display = "none";
    cssContent.innerHTML = `
      <div style="margin-bottom: 16px;">
        <h3 style="color: #00bfff; margin: 0 0 12px 0;">Live CSS Editor</h3>
        <div style="display: flex; gap: 12px; margin-bottom: 12px;">
          <button id="apply-css" style="background: #28a745; border: none; color: white; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Apply CSS</button>
          <button id="reset-css" style="background: #dc3545; border: none; color: white; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Reset</button>
        </div>
      </div>
      <div>
        <label style="display: block; margin-bottom: 8px; color: #00bfff;">CSS Rules (will be applied to current page):</label>
        <textarea id="css-editor" placeholder="/* Add your CSS here */
body {
  background-color: #000;
  color: #fff;
}

.example {
  border: 1px solid #00bfff;
}" style="width: 100%; height: 350px; background: #1e1e1e; color: #d4d4d4; border: 1px solid #404040; border-radius: 4px; padding: 12px; font-family: monospace; resize: none;"></textarea>
      </div>
    `;

    // HTML Inspector Tab
    const inspectorContent = document.createElement("div");
    inspectorContent.style.display = "none";
    inspectorContent.innerHTML = `
      <div style="margin-bottom: 16px;">
        <h3 style="color: #00bfff; margin: 0 0 12px 0;">HTML Element Inspector</h3>
        <div style="display: flex; gap: 12px; margin-bottom: 12px;">
          <button id="start-inspect" style="background: #17a2b8; border: none; color: white; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Start Inspecting</button>
          <button id="stop-inspect" style="background: #6c757d; border: none; color: white; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Stop Inspecting</button>
          <button id="apply-changes" style="background: #28a745; border: none; color: white; padding: 8px 16px; border-radius: 4px; cursor: pointer;">Apply Changes</button>
        </div>
      </div>
      <div style="display: grid; grid-template-rows: auto 1fr; gap: 16px; height: calc(100% - 80px);">
        <div id="selected-element" style="background: #292d36; padding: 12px; border-radius: 4px; border: 1px solid #404040;">
          <strong style="color: #00bfff;">Selected Element:</strong> <span id="element-path">None selected</span>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
          <div>
            <label style="display: block; margin-bottom: 8px; color: #00bfff;">Element HTML:</label>
            <textarea id="element-html" style="width: 100%; height: 250px; background: #1e1e1e; color: #d4d4d4; border: 1px solid #404040; border-radius: 4px; padding: 12px; font-family: monospace; resize: none;"></textarea>
          </div>
          <div>
            <label style="display: block; margin-bottom: 8px; color: #00bfff;">Element Styles:</label>
            <textarea id="element-styles" placeholder="color: red;
background: blue;
font-size: 16px;" style="width: 100%; height: 250px; background: #1e1e1e; color: #d4d4d4; border: 1px solid #404040; border-radius: 4px; padding: 12px; font-family: monospace; resize: none;"></textarea>
          </div>
        </div>
      </div>
    `;

    tabContents.json = jsonContent;
    tabContents.css = cssContent;
    tabContents.inspector = inspectorContent;

    contentArea.appendChild(jsonContent);
    contentArea.appendChild(cssContent);
    contentArea.appendChild(inspectorContent);

    function switchTab(tabId) {
      activeTab = tabId;

      // Update tab buttons
      Object.keys(tabButtons).forEach(id => {
        const btn = tabButtons[id];
        if (id === tabId) {
          btn.style.color = "#00bfff";
          btn.style.borderBottomColor = "#00bfff";
        } else {
          btn.style.color = "#aaa";
          btn.style.borderBottomColor = "transparent";
        }
      });

      // Update content visibility
      Object.keys(tabContents).forEach(id => {
        tabContents[id].style.display = id === tabId ? "block" : "none";
      });
    }

    // Assemble window
    devWindow.appendChild(topBar);
    devWindow.appendChild(tabNav);
    devWindow.appendChild(contentArea);
    document.body.appendChild(devWindow);

    // Make draggable
    let isDragging = false;
    let dragOffset = { x: 0, y: 0 };

    topBar.addEventListener("mousedown", (e) => {
      isDragging = true;
      const rect = devWindow.getBoundingClientRect();
      dragOffset.x = e.clientX - rect.left;
      dragOffset.y = e.clientY - rect.top;
      topBar.style.cursor = "grabbing";
    });

    document.addEventListener("mousemove", (e) => {
      if (!isDragging) return;

      let newX = e.clientX - dragOffset.x;
      let newY = e.clientY - dragOffset.y;

      // Keep within viewport
      newX = Math.max(0, Math.min(newX, window.innerWidth - devWindow.offsetWidth));
      newY = Math.max(0, Math.min(newY, window.innerHeight - devWindow.offsetHeight));

      devWindow.style.left = newX + "px";
      devWindow.style.top = newY + "px";
    });

    document.addEventListener("mouseup", () => {
      isDragging = false;
      topBar.style.cursor = "move";
    });

    // Add functionality to tools
    setupJSONFormatter();
    setupCSSEditor();
    setupHTMLInspector();
  }

  function setupJSONFormatter() {
    const formatBtn = document.getElementById("format-json");
    const minifyBtn = document.getElementById("minify-json");
    const validateBtn = document.getElementById("validate-json");
    const jsonInput = document.getElementById("json-input");
    const jsonOutput = document.getElementById("json-output");

    formatBtn.addEventListener("click", () => {
      try {
        const parsed = JSON.parse(jsonInput.value);
        jsonOutput.textContent = JSON.stringify(parsed, null, 2);
        jsonOutput.style.color = "#56d364";
      } catch (error) {
        jsonOutput.textContent = `Error: ${error.message}`;
        jsonOutput.style.color = "#f85149";
      }
    });

    minifyBtn.addEventListener("click", () => {
      try {
        const parsed = JSON.parse(jsonInput.value);
        jsonOutput.textContent = JSON.stringify(parsed);
        jsonOutput.style.color = "#56d364";
      } catch (error) {
        jsonOutput.textContent = `Error: ${error.message}`;
        jsonOutput.style.color = "#f85149";
      }
    });

    validateBtn.addEventListener("click", () => {
      try {
        JSON.parse(jsonInput.value);
        jsonOutput.textContent = "✓ Valid JSON";
        jsonOutput.style.color = "#56d364";
      } catch (error) {
        jsonOutput.textContent = `✗ Invalid JSON: ${error.message}`;
        jsonOutput.style.color = "#f85149";
      }
    });
  }

  function setupCSSEditor() {
    const applyBtn = document.getElementById("apply-css");
    const resetBtn = document.getElementById("reset-css");
    const cssEditor = document.getElementById("css-editor");
    let appliedStyleElement = null;

    applyBtn.addEventListener("click", () => {
      // Remove existing applied styles
      if (appliedStyleElement) {
        appliedStyleElement.remove();
      }

      // Create new style element
      appliedStyleElement = document.createElement("style");
      appliedStyleElement.id = "dev-tools-applied-css";
      appliedStyleElement.textContent = cssEditor.value;
      document.head.appendChild(appliedStyleElement);
    });

    resetBtn.addEventListener("click", () => {
      if (appliedStyleElement) {
        appliedStyleElement.remove();
        appliedStyleElement = null;
      }
    });
  }

  function setupHTMLInspector() {
    const startBtn = document.getElementById("start-inspect");
    const stopBtn = document.getElementById("stop-inspect");
    const applyBtn = document.getElementById("apply-changes");
    const elementPath = document.getElementById("element-path");
    const elementHTML = document.getElementById("element-html");
    const elementStyles = document.getElementById("element-styles");

    let inspecting = false;
    let selectedElement = null;
    let inspectHandler = null;
    const devToolsWindow = document.getElementById("dev-tools-window");

    startBtn.addEventListener("click", () => {
      inspecting = true;
      startBtn.style.background = "#dc3545";
      startBtn.textContent = "Inspecting... (Click element)";
      document.body.style.cursor = "crosshair";

      // Hide the dev tools window during inspection
      if (devToolsWindow) {
        devToolsWindow.style.display = "none";
      }

      inspectHandler = (e) => {
        e.preventDefault();
        e.stopPropagation();

        selectedElement = e.target;
        const tagName = selectedElement.tagName.toLowerCase();
        const className = selectedElement.className ? `.${selectedElement.className.split(' ').join('.')}` : '';
        const id = selectedElement.id ? `#${selectedElement.id}` : '';

        elementPath.textContent = `${tagName}${id}${className}`;
        elementHTML.value = selectedElement.outerHTML;

        // Get computed styles
        const styles = window.getComputedStyle(selectedElement);
        const importantStyles = [
          'color', 'background-color', 'font-size', 'font-weight',
          'margin', 'padding', 'border', 'width', 'height', 'display'
        ];

        let styleText = '';
        importantStyles.forEach(prop => {
          const value = styles.getPropertyValue(prop);
          if (value && value !== 'none' && value !== 'auto') {
            styleText += `${prop}: ${value};\n`;
          }
        });
        elementStyles.value = styleText;

        // Stop inspecting and show dev tools window again
        stopInspecting();
      };

      document.addEventListener("click", inspectHandler, true);
    });

    function stopInspecting() {
      inspecting = false;
      startBtn.style.background = "#17a2b8";
      startBtn.textContent = "Start Inspecting";
      document.body.style.cursor = "";

      // Show the dev tools window again
      if (devToolsWindow) {
        devToolsWindow.style.display = "flex";
      }

      if (inspectHandler) {
        document.removeEventListener("click", inspectHandler, true);
      }
    }

    stopBtn.addEventListener("click", stopInspecting);

    applyBtn.addEventListener("click", () => {
      if (!selectedElement) return;

      // Apply HTML changes
      try {
        const newHTML = elementHTML.value;
        selectedElement.outerHTML = newHTML;
      } catch (error) {
        console.error("Failed to apply HTML changes:", error);
      }

      // Apply style changes
      if (selectedElement && elementStyles.value) {
        const styles = elementStyles.value.split('\n').filter(line => line.trim());
        styles.forEach(style => {
          const [prop, value] = style.split(':').map(s => s.trim());
          if (prop && value) {
            selectedElement.style.setProperty(prop, value.replace(';', ''));
          }
        });
      }
    });
  }

  // Event listeners
  runBtn.addEventListener("click", executeCode);
  clearBtn.addEventListener("click", clearOutput);
  devToolsBtn.addEventListener("click", createDeveloperToolsWindow);

  // Keyboard shortcuts
  codeInput.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
      e.preventDefault();
      executeCode();
    }

    if (e.key === "Tab") {
      e.preventDefault();
      const start = codeInput.selectionStart;
      const end = codeInput.selectionEnd;
      codeInput.value =
        codeInput.value.substring(0, start) +
        "  " +
        codeInput.value.substring(end);
      codeInput.selectionStart = codeInput.selectionEnd = start + 2;
    }
  });

  // Initialize with welcome message
  addToOutput(
    "JavaScript Console ready. Type your code above and click 'Run' or press Ctrl+Enter.",
    "info"
  );

  return consoleView;
}
