// @ts-nocheck
import { loadData } from "../utils/helpers.js";

// Inject games view CSS if not already present
function injectGamesCSS() {
  if (document.getElementById("games-view-style")) return;
  const style = document.createElement("style");
  style.id = "games-view-style";
  style.textContent = `
    .games-view {
      padding: 20px;
      background: #23272f;
      border-radius: 10px;
      min-height: 400px;
      box-shadow: 0 2px 12px 0 rgba(0,0,0,0.15);
    }
    .games-tabs {
      display: flex;
      gap: 10px;
      margin-bottom: 20px;
      flex-wrap: wrap;
    }
    .games-tab {
      padding: 10px 24px;
      background: #2d323e;
      border: none;
      border-radius: 6px 6px 0 0;
      color: #fff;
      font-size: 1rem;
      cursor: pointer;
      transition: background 0.2s, color 0.2s;
      outline: none;
    }
    .games-tab.active, .games-tab:hover {
      background: var(--accent-color, #007acc);
      color: #fff;
    }
    .games-list {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 18px;
      margin-top: 10px;
    }
    .game-item {
      background: #292d36;
      border-radius: 8px;
      padding: 18px 14px 14px 14px;
      box-shadow: 0 1px 4px 0 rgba(0,0,0,0.10);
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      transition: box-shadow 0.2s, transform 0.2s;
      position: relative;
    }
    .game-item:hover {
      box-shadow: 0 4px 16px 0 rgba(0,122,204,0.15);
      transform: translateY(-2px) scale(1.03);
    }
    .game-item a {
      font-size: 1.1rem;
      font-weight: 600;
      color: #00bfff;
      margin-bottom: 4px;
      text-decoration: none;
    }
    .game-item a:hover {
      color: #fff;
    }
    .game-item .game-type {
      font-size: 0.85rem;
      color: #aaa;
      margin-top: 2px;
      text-transform: capitalize;
    }
    .game-item .delete-btn {
      position: absolute;
      top: 8px;
      right: 8px;
      background: #ff4444;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 4px 8px;
      font-size: 0.75rem;
      cursor: pointer;
      opacity: 0;
      transition: opacity 0.2s;
    }
    .game-item:hover .delete-btn {
      opacity: 1;
    }
    .game-item .delete-btn:hover {
      background: #cc0000;
    }
    .game-item .copy-btn {
      width: 100%;
      margin-top: 10px;
      background: #007acc;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 8px 12px;
      font-size: 0.9rem;
      cursor: pointer;
      transition: background 0.2s;
    }
    .game-item .copy-btn:hover {
      background: #005a9e;
    }
    .game-item .copy-btn.copied {
      background: #28a745;
    }
    .games-loading, .games-empty {
      grid-column: 1/-1;
      text-align: center;
      color: #aaa;
      padding: 40px 20px;
    }
    .add-game-btn {
      padding: 10px 24px;
      background: #28a745;
      border: none;
      border-radius: 6px;
      color: #fff;
      font-size: 1rem;
      cursor: pointer;
      transition: background 0.2s;
      margin-left: auto;
    }
    .add-game-btn:hover {
      background: #218838;
    }
    .add-game-form {
      background: #2d323e;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 20px;
    }
    .add-game-form input {
      width: 100%;
      padding: 10px;
      margin-bottom: 10px;
      background: #23272f;
      border: 1px solid #444;
      border-radius: 4px;
      color: #fff;
      font-size: 1rem;
    }
    .add-game-form input::placeholder {
      color: #888;
    }
    .add-game-form button {
      padding: 10px 20px;
      margin-right: 10px;
      border: none;
      border-radius: 4px;
      font-size: 1rem;
      cursor: pointer;
      transition: background 0.2s;
    }
    .add-game-form .submit-btn {
      background: #28a745;
      color: white;
    }
    .add-game-form .submit-btn:hover {
      background: #218838;
    }
    .add-game-form .cancel-btn {
      background: #6c757d;
      color: white;
    }
    .add-game-form .cancel-btn:hover {
      background: #5a6268;
    }
  `;
  document.head.appendChild(style);
}

const TABS = [
  { key: "blocked", label: "Blocked" },
  { key: "unblocked", label: "Unblocked" },
  { key: "cors-optimized", label: "CORS Proxy Optimized" },
  { key: "custom", label: "Custom" },
];

const CUSTOM_GAMES_KEY = 'custom_games';

let gamesData = [];
let activeTab = "unblocked";
let isEventListenerAttached = false;
let showAddForm = false;

// LocalStorage helpers for custom games
function getCustomGames() {
  try {
    const stored = localStorage.getItem(CUSTOM_GAMES_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Failed to load custom games from localStorage:', error);
    return [];
  }
}

function saveCustomGames(games) {
  try {
    localStorage.setItem(CUSTOM_GAMES_KEY, JSON.stringify(games));
  } catch (error) {
    console.error('Failed to save custom games to localStorage:', error);
  }
}

function addCustomGame(title, url) {
  const customGames = getCustomGames();
  const newGame = {
    title,
    url,
    type: 'custom',
    id: Date.now() // Simple unique ID
  };
  customGames.push(newGame);
  saveCustomGames(customGames);
  return newGame;
}

function deleteCustomGame(gameId) {
  const customGames = getCustomGames();
  const filtered = customGames.filter(game => game.id !== gameId);
  saveCustomGames(filtered);
}

async function loadGames() {
  try {
    gamesData = await loadData('games');
    renderGames();
  } catch (error) {
    console.error('Failed to load games:', error);
    renderError();
  }
}

function setTab(tabKey) {
  if (activeTab === tabKey) return;
  activeTab = tabKey;
  showAddForm = false; // Reset form when switching tabs
  renderGames();
}

function toggleAddForm() {
  showAddForm = !showAddForm;
  renderGames();
}

function renderTabs() {
  return `
    <div class="games-tabs">
      ${TABS.map(
    (tab) => `
        <button 
          class="games-tab${activeTab === tab.key ? " active" : ""}" 
          data-tab-key="${tab.key}"
          aria-pressed="${activeTab === tab.key}"
        >
          ${tab.label}
        </button>
      `
  ).join("")}
      ${activeTab === 'custom' ? `
        <button class="add-game-btn" data-action="toggle-form">
          ${showAddForm ? 'Cancel' : '+ Add Game'}
        </button>
      ` : ''}
    </div>
  `;
}

function renderAddForm() {
  if (!showAddForm || activeTab !== 'custom') return '';

  return `
    <div class="add-game-form">
      <input type="text" id="game-title-input" placeholder="Game Title" />
      <input type="url" id="game-url-input" placeholder="Game URL (https://...)" />
      <button class="submit-btn" data-action="add-game">Add Game</button>
      <button class="cancel-btn" data-action="cancel-form">Cancel</button>
    </div>
  `;
}

function formatGameType(type) {
  return type === "cors-optimized" ? "CORS Optimized" : type;
}

function renderGamesList(games) {
  if (games.length === 0) {
    return `<p class="games-empty">No games found for "${activeTab}" category.</p>`;
  }

  return games.map(game => `
    <div class="game-item" data-game-id="${game.id || ''}">
      ${activeTab === 'custom' ? `
        <button class="delete-btn" data-action="delete-game" data-game-id="${game.id}">Delete</button>
      ` : ''}
      <a href="${game.url}" target="_blank" rel="noopener noreferrer">${game.title}</a>
      <div class="game-type">${formatGameType(game.type)}</div>
      <button class="copy-btn" data-action="copy-link" data-url="${game.url}">Copy Link</button>
    </div>
  `).join("");
}

function renderGames() {
  const container = document.getElementById("games-view");
  if (!container) {
    console.warn("Games container not found, retrying in 100ms...");
    setTimeout(renderGames, 100);
    return;
  }

  let filtered = [];

  if (activeTab === 'custom') {
    // Get custom games from localStorage
    filtered = getCustomGames();
  } else {
    // Get games from loaded data
    if (!gamesData || gamesData.length === 0) {
      container.innerHTML = `
        ${renderTabs()}
        <div class="games-list">
          <p class="games-empty">No games data available.</p>
        </div>
      `;
      setupEventListeners();
      return;
    }
    filtered = gamesData.filter(game => game.type === activeTab);
  }

  container.innerHTML = `
    ${renderTabs()}
    ${renderAddForm()}
    <div class="games-list">
      ${renderGamesList(filtered)}
    </div>
  `;

  setupEventListeners();
}

function renderError() {
  const container = document.getElementById("games-view");
  if (!container) return;

  container.innerHTML = `
    ${renderTabs()}
    <div class="games-list">
      <p class="games-empty">Failed to load games. Please try again later.</p>
    </div>
  `;

  setupEventListeners();
}

function setupEventListeners() {
  if (isEventListenerAttached) return;

  const container = document.getElementById("games-view");
  if (!container) return;

  container.addEventListener("click", handleClick);
  isEventListenerAttached = true;
}

function handleClick(event) {
  const target = event.target;

  // Handle tab clicks
  if (target.classList.contains("games-tab")) {
    const tabKey = target.getAttribute("data-tab-key");
    if (tabKey) {
      event.preventDefault();
      setTab(tabKey);
    }
    return;
  }

  // Handle action buttons
  const action = target.getAttribute("data-action");
  if (!action) return;

  event.preventDefault();

  switch (action) {
    case "toggle-form":
    case "cancel-form":
      toggleAddForm();
      break;

    case "add-game":
      const titleInput = document.getElementById("game-title-input");
      const urlInput = document.getElementById("game-url-input");

      if (titleInput && urlInput) {
        const title = titleInput.value.trim();
        const url = urlInput.value.trim();

        if (title && url) {
          try {
            new URL(url); // Validate URL
            addCustomGame(title, url);
            showAddForm = false;
            renderGames();
          } catch (error) {
            alert('Please enter a valid URL (must start with http:// or https://)');
          }
        } else {
          alert('Please fill in both title and URL');
        }
      }
      break;

    case "delete-game":
      const gameId = parseInt(target.getAttribute("data-game-id"));
      if (gameId && confirm('Are you sure you want to delete this game?')) {
        deleteCustomGame(gameId);
        renderGames();
      }
      break;

    case "copy-link":
      const url = target.getAttribute("data-url");
      if (url) {
        navigator.clipboard.writeText(url).then(() => {
          // Visual feedback
          const originalText = target.textContent;
          target.textContent = 'Copied!';
          target.classList.add('copied');

          setTimeout(() => {
            target.textContent = originalText;
            target.classList.remove('copied');
          }, 2000);
        }).catch(err => {
          console.error('Failed to copy:', err);
          alert('Failed to copy link to clipboard');
        });
      }
      break;
  }
}

export default function showGamesView() {
  injectGamesCSS();
  loadGames();

  return `
    <div id="games-view" class="games-view">
      <div class="games-loading">Loading games...</div>
    </div>
  `;
}