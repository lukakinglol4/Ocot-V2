// @ts-nocheck
import { loadData } from "../utils/helpers.js";
import {
  showModal,
  showInputModal,
  showConfirmModal,
  createBaseModal,
  removeModal,
} from "../utils/modalHelpers.js";
import { getGeneralSettings } from "./settings.js";

export default function createscriptsView() {
  // Inject scripts view CSS if not already present
  if (!document.getElementById("scripts-view-style")) {
    const style = document.createElement("style");
    style.id = "scripts-view-style";
    style.textContent = `
      .scripts-view {
        padding: 20px;
        background: #23272f;
        border-radius: 10px;
        min-height: 400px;
        box-shadow: 0 2px 12px 0 rgba(0,0,0,0.15);
        height: 100%;
        max-height: 100%;
        overflow-y: auto;
        overflow-x: hidden;
        box-sizing: border-box;
      }

      .scripts-list {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 18px;
        margin-top: 10px;
        padding-bottom: 20px;
      }

      .script-item {
        background: #292d36;
        border-radius: 8px;
        padding: 18px 14px;
        box-shadow: 0 1px 4px 0 rgba(0,0,0,0.10);
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        transition: box-shadow 0.2s, transform 0.2s;
        cursor: pointer;
        user-select: none;
        position: relative;
      }

      .script-item:hover {
        box-shadow: 0 4px 16px 0 rgba(0,122,204,0.15);
        transform: translateY(-2px) scale(1.03);
        background: #2d323e;
      }

      .script-item .script-title {
        font-size: 1.1rem;
        font-weight: 600;
        color: #00bfff;
        margin-bottom: 4px;
      }

      .script-item .script-desc {
        font-size: 0.95rem;
        color: #aaa;
        margin-bottom: 2px;
      }

      .script-item .script-category {
        font-size: 0.8rem;
        color: #666;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-top: 8px;
        padding: 2px 6px;
        background: rgba(0, 191, 255, 0.1);
        border-radius: 3px;
        border: 1px solid rgba(0, 191, 255, 0.3);
      }

      .script-item.stateful-enabled {
        background: linear-gradient(135deg, #1a4f3a, #2d5a42);
        border: 2px solid #28a745;
        box-shadow: 0 4px 16px 0 rgba(40, 167, 69, 0.3);
      }

      .script-item.stateful-enabled:hover {
        background: linear-gradient(135deg, #1e5d47, #326349);
        box-shadow: 0 6px 20px 0 rgba(40, 167, 69, 0.4);
        transform: translateY(-2px) scale(1.03);
      }

      .script-item.stateful-enabled .script-title::before {
        content: "🔒 ";
        color: #28a745;
      }

      .script-item.stateful-disabled {
        background: #292d36;
        border: 2px solid transparent;
      }

      .script-item.stateful-disabled .script-title::before {
        content: "🔓 ";
        color: #6c757d;
      }

      .script-item .status-indicator {
        display: inline-block;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        margin-left: 8px;
        animation: pulse 2s infinite;
      }

      .script-item.stateful-enabled .status-indicator {
        background: #28a745;
        box-shadow: 0 0 6px rgba(40, 167, 69, 0.6);
      }

      .script-item.stateful-disabled .status-indicator {
        background: #6c757d;
        animation: none;
      }

      @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.5; }
        100% { opacity: 1; }
      }

      .loading-placeholder {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 200px;
        color: #aaa;
        font-size: 1rem;
      }

      .error-message {
        background: #dc3545;
        color: white;
        padding: 16px;
        border-radius: 8px;
        margin: 16px 0;
        text-align: center;
      }
    `;
    document.head.appendChild(style);
  }

  const scriptsView = document.createElement("div");
  scriptsView.className = "scripts-view";

  let scriptsData = [];
  let loadedHandlers = new Map();

  // Load scripts data using universal loader
  async function loadScripts() {
    scriptsData = await loadData('scripts');
  }

  // Dynamically import a handler
  async function loadHandler(handlerName) {
    if (loadedHandlers.has(handlerName)) {
      return loadedHandlers.get(handlerName);
    }

    try {
      const module = await import(`../handlers/${handlerName}.js`);
      const handler = module.default;
      loadedHandlers.set(handlerName, handler);
      return handler;
    } catch (error) {
      console.error(`Failed to load handler: ${handlerName}`, error);
      return null;
    }
  }

  // Update stateful script visual state
  function updateStatefulVisualState(itemElement, script, isEnabled) {
    if (!itemElement || !script.stateful) return;

    const titleElement = itemElement.querySelector(".script-title");
    const descElement = itemElement.querySelector(".script-desc");
    const statusIndicator =
      itemElement.querySelector(".status-indicator") ||
      document.createElement("span");

    if (isEnabled) {
      itemElement.className = "script-item stateful-enabled";
      titleElement.textContent = `${script.title} (ON)`;
      descElement.textContent = `${script.description} (Currently active)`;
      statusIndicator.className = "status-indicator";
      statusIndicator.title = `${script.title} is currently enabled`;
    } else {
      itemElement.className = "script-item stateful-disabled";
      titleElement.textContent = `${script.title} (OFF)`;
      descElement.textContent = script.description;
      statusIndicator.className = "status-indicator";
      statusIndicator.title = `${script.title} is currently disabled`;
    }

    // Add status indicator if not already present
    if (!titleElement.querySelector(".status-indicator")) {
      titleElement.appendChild(statusIndicator);
    }
  }

  // Handle script activation
  async function activateScript(script) {
    try {
      const handler = await loadHandler(script.handler);
      if (!handler) {
        await showModal(
          `Failed to load handler for ${script.title}. This may be due to a missing or corrupted script file.`,
          "Handler Error",
          "error"
        );
        return;
      }

      if (handler.onActivate) {
        await handler.onActivate();

        // Update visual state for stateful scripts
        if (script.stateful && handler.isEnabled) {
          const scriptItem = document.querySelector(
            `[data-script-id="${script.id}"]`
          );
          updateStatefulVisualState(scriptItem, script, handler.isEnabled());
        }
      }
    } catch (error) {
      console.error(`Error activating script ${script.title}:`, error);
      await showModal(
        `Error activating ${script.title}: ${error.message}`,
        "Script Error",
        "error"
      );
    }
  }

  // Render scripts
  async function renderScripts() {
    const list = document.createElement("div");
    list.className = "scripts-list";

    for (const script of scriptsData) {
      const item = document.createElement("div");
      item.className = "script-item";
      item.tabIndex = 0;
      item.setAttribute("data-script-id", script.id);

      // Check if this is a stateful script and get its current state
      let isEnabled = false;
      if (script.stateful) {
        try {
          const handler = await loadHandler(script.handler);
          if (handler && handler.isEnabled) {
            isEnabled = handler.isEnabled();
          }
        } catch (error) {
          console.warn(`Could not check state for ${script.id}:`, error);
        }
      }

      // Set up script content
      item.innerHTML = `
        <div class="script-title">${script.title}${script.stateful ? (isEnabled ? " (ON)" : " (OFF)") : ""
        }</div>
        <div class="script-desc">${script.description}${script.stateful && isEnabled ? " (Currently active)" : ""
        }</div>
        <div class="script-category">${script.category}</div>
      `;

      // Apply visual state for stateful scripts
      if (script.stateful) {
        updateStatefulVisualState(item, script, isEnabled);
      }

      // Add click handler
      const clickHandler = () => activateScript(script);
      item.addEventListener("click", clickHandler);
      item.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          clickHandler();
        }
      });

      list.appendChild(item);
    }

    scriptsView.appendChild(list);

    // Add informational note at the bottom
    const infoNote = document.createElement("div");
    infoNote.style.cssText = `
      margin-top: 24px;
      padding: 16px;
      background: #292d36;
      border: 1px solid #404040;
      border-radius: 8px;
      border-left: 4px solid #ffc107;
      font-size: 0.9rem;
      color: #d4d4d4;
      line-height: 1.5;
    `;

    infoNote.innerHTML = `
      <div style="display: flex; align-items: flex-start; gap: 8px;">
        <span style="color: #ffc107; font-size: 1.1rem;">ℹ️</span>
        <div>
          <strong style="color: #ffc107;">Note:</strong> Scripts with toggle states (Auto-Hide, Auto-Remove, Anti Force Reload) can be clicked again to disable them.
        </div>
      </div>
    `;

    scriptsView.appendChild(infoNote);
  }

  // Initialize the view
  async function initialize() {
    // Show loading state
    scriptsView.innerHTML = `
      <div class="loading-placeholder">
        <div>Loading scripts...</div>
      </div>
    `;

    try {
      await loadScripts();
      scriptsView.innerHTML = ""; // Clear loading state
      await renderScripts();
    } catch (error) {
      console.error("Failed to initialize scripts view:", error);
      scriptsView.innerHTML = `
        <div class="error-message">
          Failed to load scripts: ${error.message}
        </div>
      `;
    }
  }

  // Start initialization
  initialize();

  return scriptsView;
}
