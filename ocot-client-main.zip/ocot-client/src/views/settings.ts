// @ts-nocheck
import { injectAppCSS } from "../css.js";
import { loadData } from "../utils/helpers.js";
import { proxiesList, ProxyData } from "../data/typescript/proxies.js";
import { themesList as themesListFallback, Theme } from "../data/typescript/themes.js";

// Variable to hold themes data (will be loaded from JSON or fallback to TypeScript)
let themesData: Theme[] = themesListFallback;

// Helper function to generate theme options HTML
function generateThemeOptionsHTML(): string {
  return themesData
    .map((theme) => {
      // Special handling for custom theme
      if (theme.id === "custom") {
        return `
          <div class="theme-option custom-theme-option" data-theme="custom" style="background: #292d36; border: 2px solid #404040; border-radius: 8px; padding: 16px; cursor: pointer; transition: all 0.2s;">
            <div class="theme-preview" style="display: flex; gap: 8px; margin-bottom: 8px;">
              <div id="custom-preview-1" style="width: 20px; height: 20px; background: var(--custom-bg, #292d36); border-radius: 4px;"></div>
              <div id="custom-preview-2" style="width: 20px; height: 20px; background: var(--custom-accent, #00bfff); border-radius: 4px;"></div>
              <div id="custom-preview-3" style="width: 20px; height: 20px; background: var(--custom-secondary, #23272f); border-radius: 4px;"></div>
            </div>
            <div style="color: #fff; font-weight: 600;">${theme.icon} ${theme.name}</div>
            <div style="color: #aaa; font-size: 0.85rem;">${theme.description}</div>
          </div>
        `;
      }

      // Standard theme option
      return `
        <div class="theme-option" data-theme="${theme.id}" style="background: #292d36; border: 2px solid #404040; border-radius: 8px; padding: 16px; cursor: pointer; transition: all 0.2s;">
          <div class="theme-preview" style="display: flex; gap: 8px; margin-bottom: 8px;">
            ${theme.preview.map((color) => `<div style="width: 20px; height: 20px; background: ${color}; border-radius: 4px;"></div>`).join("")}
          </div>
          <div style="color: #fff; font-weight: 600;">${theme.icon} ${theme.name}</div>
          <div style="color: #aaa; font-size: 0.85rem;">${theme.description}</div>
        </div>
      `;
    })
    .join("");
}

// Async function to load themes from JSON with TypeScript fallback
async function loadThemes() {
  // Use universal data loader (themes exports as 'themesList')
  const loadedThemes = await loadData<Theme>('themes', 'themesList');
  if (loadedThemes.length > 0) {
    themesData = loadedThemes;
  } else {
    // Keep TypeScript fallback if loader fails
    themesData = themesListFallback;
  }
}

// Exported function to create the Settings view
export default function createSettingsView() {
  // Load themes from JSON (with TypeScript fallback) asynchronously
  loadThemes();

  // Inject shared CSS
  injectAppCSS();

  // Inject tab order CSS
  injectTabOrderCSS();

  const settingsView = document.createElement("div");
  settingsView.className = "card-grid-view";
  settingsView.style.display = "none";

  settingsView.innerHTML = `
    <div class="settings-header" style="margin-bottom: 30px;">
      <h2 style="color: #00bfff; margin: 0 0 8px 0; font-size: 1.5rem;">Settings</h2>
      <p style="color: #aaa; margin: 0; font-size: 0.95rem;">Customize your Ocot Client experience</p>
    </div>

    <div class="settings-content" style="display: flex; flex-direction: column; gap: 30px;">
      
      <!-- Themes Section -->
      <div class="settings-section themes-section">
        <h3 style="color: #fff; margin: 0 0 16px 0; font-size: 1.2rem; display: flex; align-items: center; gap: 8px;">
          🎨 Themes
        </h3>
        <p style="color: #aaa; margin: 0 0 16px 0; font-size: 0.9rem;">
          Customize the appearance of your Ocot Client
        </p>
        <div class="theme-options" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px;">
          ${generateThemeOptionsHTML()}
        </div>

        <!-- Custom Theme Color Picker -->
        <div id="custom-theme-panel" style="display: none; margin-top: 16px; background: #23272f; border-radius: 8px; padding: 16px; border: 1px solid #404040;">
          <h4 style="color: #fff; margin: 0 0 16px 0; font-size: 1.1rem;">Customize Colors</h4>
          <div style="display: grid; gap: 16px;">
            <div class="color-input-group" style="display: flex; align-items: center; gap: 12px;">
              <label style="color: #aaa; min-width: 120px;">Accent Color:</label>
              <input type="color" id="custom-accent-color" value="#00bfff" style="width: 50px; height: 30px; border: none; border-radius: 4px; cursor: pointer;">
              <input type="text" id="custom-accent-text" value="#00bfff" style="background: #292d36; color: #fff; border: 1px solid #404040; border-radius: 4px; padding: 4px 8px; font-family: monospace; width: 80px;">
            </div>
            <div class="color-input-group" style="display: flex; align-items: center; gap: 12px;">
              <label style="color: #aaa; min-width: 120px;">Background:</label>
              <input type="color" id="custom-bg-color" value="#292d36" style="width: 50px; height: 30px; border: none; border-radius: 4px; cursor: pointer;">
              <input type="text" id="custom-bg-text" value="#292d36" style="background: #292d36; color: #fff; border: 1px solid #404040; border-radius: 4px; padding: 4px 8px; font-family: monospace; width: 80px;">
            </div>
            <div class="color-input-group" style="display: flex; align-items: center; gap: 12px;">
              <label style="color: #aaa; min-width: 120px;">Secondary:</label>
              <input type="color" id="custom-secondary-color" value="#23272f" style="width: 50px; height: 30px; border: none; border-radius: 4px; cursor: pointer;">
              <input type="text" id="custom-secondary-text" value="#23272f" style="background: #292d36; color: #fff; border: 1px solid #404040; border-radius: 4px; padding: 4px 8px; font-family: monospace; width: 80px;">
            </div>
            <div style="display: flex; gap: 8px; margin-top: 8px;">
              <button id="apply-custom-theme" style="background: #00bfff; color: #fff; border: none; border-radius: 4px; padding: 8px 16px; cursor: pointer; font-weight: 600;">Apply Theme</button>
              <button id="reset-custom-theme" style="background: #666; color: #fff; border: none; border-radius: 4px; padding: 8px 16px; cursor: pointer;">Reset</button>
            </div>
          </div>
        </div>
      </div>

      <!-- General Settings Section -->
      <div class="settings-section general-section">
        <h3 style="color: #fff; margin: 0 0 16px 0; font-size: 1.2rem; display: flex; align-items: center; gap: 8px;">
          ⚙️ General Settings
        </h3>
        <p style="color: #aaa; margin: 0 0 16px 0; font-size: 0.9rem;">
          Configure general app behavior and appearance
        </p>
        <div class="general-options" style="display: grid; gap: 16px;">
          <div class="setting-item" style="background: #292d36; border-radius: 8px; padding: 16px;">
            <label style="color: #00bfff; font-weight: 600; margin-bottom: 12px; display: block;">
              Floating Button
            </label>
            <div style="display: grid; gap: 8px;">
              <label style="display: flex; align-items: center; gap: 8px; color: #fff; cursor: pointer;">
                <input type="checkbox" id="enable-floating-button" checked style="margin: 0;">
                <span>Show floating button when client is hidden</span>
              </label>
            </div>
            <div style="color: #aaa; font-size: 0.8rem; margin-top: 8px;">
              The floating button (🔧) appears when you hide the main client, allowing you to quickly show it again. You can also press "\\" to toggle the client.
            </div>
          </div>
          
          <div class="setting-item" style="background: #292d36; border-radius: 8px; padding: 16px;">
            <label style="color: #00bfff; font-weight: 600; margin-bottom: 12px; display: block;">
              Script Notifications
            </label>
            <div style="display: grid; gap: 8px;">
              <label style="display: flex; align-items: center; gap: 8px; color: #fff; cursor: pointer;">
                <input type="checkbox" id="enable-script-notifications" checked style="margin: 0;">
                <span>Show notifications when auto-hide/auto-remove triggers</span>
              </label>
            </div>
            <div style="color: #aaa; font-size: 0.8rem; margin-top: 8px;">
              When enabled, small notifications appear in the top-right corner when auto-hide or auto-remove scripts are triggered by tab switching or clicking away.
            </div>
          </div>
        </div>
      </div>

      <!-- Proxy Settings Section -->
      <div class="settings-section proxy-section">
        <h3 style="color: #fff; margin: 0 0 16px 0; font-size: 1.2rem; display: flex; align-items: center; gap: 8px;">
          🌐 Proxy Settings
        </h3>
        <p style="color: #aaa; margin: 0 0 16px 0; font-size: 0.9rem;">
          Configure your proxy server URL
        </p>
        <div class="proxy-options" style="display: grid; gap: 16px;">
          <div class="setting-item" style="background: #292d36; border-radius: 8px; padding: 16px;">
            <label style="color: #00bfff; font-weight: 600; margin-bottom: 12px; display: block;">
              Proxy Server
            </label>
            <select id="proxy-server-select" style="width: 100%; padding: 10px; background: #23272f; border: 1px solid #404040; border-radius: 6px; color: #fff; font-size: 0.9rem; margin-bottom: 12px;">
              <!-- Options will be dynamically populated from proxy data -->
            </select>
            <div id="custom-proxy-input" style="display: none;">
              <input type="text" id="custom-proxy-url" placeholder="Enter custom proxy URL (e.g., proxy.example.com)" 
                     style="width: 100%; padding: 10px; background: #23272f; border: 1px solid #404040; border-radius: 6px; color: #fff; font-size: 0.9rem;">
              <div style="color: #aaa; font-size: 0.8rem; margin-top: 4px;">
                Protocol (https:// or http://) will be added automatically if not specified
              </div>
            </div>
            <div style="color: #aaa; font-size: 0.8rem; margin-top: 8px;">
              Select the proxy server to use for web browsing. Changes take effect after reopening the proxy tab.
            </div>
          </div>
        </div>
        
        <div style="margin-top: 16px; display: flex; gap: 12px;">
          <button id="save-proxy-settings" class="games-tab" style="border-radius: 6px; background: #28a745;">
            💾 Save Proxy Settings
          </button>
          <button id="reset-proxy-settings" class="games-tab" style="border-radius: 6px; background: #6c757d;">
            🔄 Reset to Default
          </button>
        </div>
      </div>

      <!-- Pocket Browser Settings Section -->
      <div class="settings-section browser-section">
        <h3 style="color: #fff; margin: 0 0 16px 0; font-size: 1.2rem; display: flex; align-items: center; gap: 8px;">
          🔍 Pocket Browser Settings
        </h3>
        <p style="color: #aaa; margin: 0 0 16px 0; font-size: 0.9rem;">
          Configure your browsing experience
        </p>
        <div class="browser-options" style="display: grid; gap: 16px;">
          <div class="setting-item" style="background: #292d36; border-radius: 8px; padding: 16px;">
            <label style="color: #00bfff; font-weight: 600; margin-bottom: 6px; display: block;">
              Default Homepage
            </label>
            <input type="text" id="homepage-input" placeholder="https://google.com?igu=1" 
                   style="width: 100%; padding: 10px; background: #23272f; border: 1px solid #404040; border-radius: 6px; color: #fff; font-size: 0.9rem;">
            <div style="color: #aaa; font-size: 0.8rem; margin-top: 4px;">
              Set the default page when opening Pocket Browser
            </div>
          </div>
          
          <div class="setting-item" style="background: #292d36; border-radius: 8px; padding: 16px;">
            <label style="color: #00bfff; font-weight: 600; margin-bottom: 12px; display: block;">
              Browser Features
            </label>
            <div style="display: grid; gap: 8px;">
              <label style="display: flex; align-items: center; gap: 8px; color: #fff; cursor: pointer;">
                <input type="checkbox" id="enable-history" checked style="margin: 0;">
                <span>Enable browsing history</span>
              </label>
              <label style="display: flex; align-items: center; gap: 8px; color: #fff; cursor: pointer;">
                <input type="checkbox" id="enable-bookmarks" checked style="margin: 0;">
                <span>Enable bookmarks</span>
              </label>
            </div>
          </div>
          
          <div class="setting-item" style="background: #292d36; border-radius: 8px; padding: 16px;">
            <label style="color: #00bfff; font-weight: 600; margin-bottom: 6px; display: block;">
              User Agent
            </label>
            <select id="user-agent-select" style="width: 100%; padding: 10px; background: #23272f; border: 1px solid #404040; border-radius: 6px; color: #fff; font-size: 0.9rem;">
              <option value="default">Default</option>
              <option value="chrome">Chrome Desktop</option>
              <option value="firefox">Firefox Desktop</option>
              <option value="safari">Safari Desktop</option>
              <option value="mobile">Mobile Browser</option>
            </select>
            <div style="color: #aaa; font-size: 0.8rem; margin-top: 4px;">
              Change how websites see your browser
            </div>
          </div>
        </div>
        
        <div style="margin-top: 16px; display: flex; gap: 12px;">
          <button id="save-browser-settings" class="games-tab" style="border-radius: 6px; background: #28a745;">
            💾 Save Settings
          </button>
          <button id="reset-browser-settings" class="games-tab" style="border-radius: 6px; background: #6c757d;">
            🔄 Reset to Default
          </button>
        </div>
      </div>

      <!-- Tab Order Section -->
      <div class="settings-section tab-order-section">
        <h3 style="color: #fff; margin: 0 0 16px 0; font-size: 1.2rem; display: flex; align-items: center; gap: 8px;">
          📱 Tab Order
        </h3>
        <p style="color: #aaa; margin: 0 0 16px 0; font-size: 0.9rem;">
          Customize the order of sidebar navigation tabs
        </p>
        
        <div class="tab-order-container" style="background: #292d36; border-radius: 8px; padding: 20px;">
          <div style="margin-bottom: 16px;">
            <div style="color: #00bfff; font-weight: 600; margin-bottom: 8px;">
              Current Tab Order
            </div>
            <div style="color: #aaa; font-size: 0.8rem; margin-bottom: 12px;">
              Drag tabs to reorder them, or use the arrow buttons for keyboard navigation
            </div>
          </div>
          
          <div id="tab-order-list" class="tab-order-list" style="display: flex; flex-direction: column; gap: 4px; margin-bottom: 16px;">
            <!-- Tab items will be populated by JavaScript -->
          </div>
          
          <div class="tab-order-actions" style="display: flex; gap: 12px; flex-wrap: wrap;">
            <button id="reset-tab-order" class="games-tab" style="border-radius: 6px; background: #6c757d; font-size: 0.85rem;">
              🔄 Reset to Default
            </button>
            <div style="color: #aaa; font-size: 0.8rem; display: flex; align-items: center; margin-left: auto;">
              Changes are saved automatically
            </div>
          </div>
        </div>
      </div>

      <!-- Help Section -->
      <div class="settings-section help-section">
        <h3 style="color: #fff; margin: 0 0 16px 0; font-size: 1.2rem; display: flex; align-items: center; gap: 8px;">
          ❓ Help & Support
        </h3>
        <div class="help-content" style="background: #292d36; border-radius: 8px; padding: 20px;">
          <div style="color: #aaa; line-height: 1.6;">
            <h4 style="color: #00bfff; margin: 0 0 12px 0; font-size: 1.1rem;">Getting Started</h4>
            <p style="margin: 0 0 12px 0;">
              Welcome to Ocot Client! This powerful tool provides various utilities for web browsing and productivity.
            </p>
            
            <h4 style="color: #00bfff; margin: 16px 0 12px 0; font-size: 1.1rem;">Features Overview</h4>
            <ul style="margin: 0 0 12px 0; padding-left: 20px;">
              <li style="margin-bottom: 6px;"><strong>Proxy:</strong> Browse websites through proxy servers</li>
              <li style="margin-bottom: 6px;"><strong>Games:</strong> Access a collection of web games</li>
              <li style="margin-bottom: 6px;"><strong>Scripts:</strong> Run useful JavaScript utilities</li>
              <li style="margin-bottom: 6px;"><strong>Pocket Browser:</strong> Embedded browser with privacy features</li>
              <li style="margin-bottom: 6px;"><strong>Tools:</strong> Calculator, Notes, Console, and more</li>
            </ul>
            
            <h4 style="color: #00bfff; margin: 16px 0 12px 0; font-size: 1.1rem;">Keyboard Shortcuts</h4>
            <p style="margin: 0 0 12px 0;">
              • Press <kbd style="background: #23272f; padding: 2px 6px; border-radius: 4px; font-family: monospace;">\\</kbd> to show/hide the Ocot Client
            </p>
            <p style="margin: 0 0 12px 0;">
              • Press <kbd style="background: #23272f; padding: 2px 6px; border-radius: 4px; font-family: monospace;">Esc</kbd> to exit full screen in proxy tab.
            </p>
            
            <h4 style="color: #00bfff; margin: 16px 0 12px 0; font-size: 1.1rem;">Tips & Tricks</h4>
            <p style="margin: 0 0 6px 0;">
              • Customize themes in the Settings tab for a personalized experience
            </p>
            <p style="margin: 0 0 6px 0;">
              • Use the Cloaking feature to disguise your browser tab
            </p>
            <p style="margin: 0 0 6px 0;">
              • The Notes feature saves automatically to local storage
            </p>
            
            <div style="background: #23272f; border-radius: 6px; padding: 12px; margin-top: 16px; border-left: 4px solid #00bfff;">
              <strong style="color: #00bfff;">Note:</strong> This help section will be expanded with more detailed documentation and troubleshooting guides in future updates.
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  // Add event listeners after the element is created
  setTimeout(() => {
    setupSettingsEventListeners();
  }, 0);

  return settingsView;
}

// Theme management functions
function setupSettingsEventListeners() {
  // Theme selection
  const themeOptions = document.querySelectorAll(".theme-option");
  themeOptions.forEach((option) => {
    option.addEventListener("click", () => {
      const theme = option.getAttribute("data-theme");
      applyTheme(theme);

      // Update active theme selection
      themeOptions.forEach((opt) => (opt.style.borderColor = "#404040"));
      option.style.borderColor = "#00bfff";

      // Save theme preference
      localStorage.setItem("proxyClientTheme", theme);
    });
  });

  // Load saved theme on startup
  const savedTheme = localStorage.getItem("proxyClientTheme") || "default";
  applyTheme(savedTheme);

  // Highlight saved theme
  const savedThemeOption = document.querySelector(
    `[data-theme="${savedTheme}"]`
  );
  if (savedThemeOption) {
    savedThemeOption.style.borderColor = "#00bfff";
  }

  // Setup custom theme functionality
  setupCustomTheme();

  // Browser settings
  const saveButton = document.getElementById("save-browser-settings");
  const resetButton = document.getElementById("reset-browser-settings");

  if (saveButton) {
    saveButton.addEventListener("click", saveBrowserSettings);
  }

  if (resetButton) {
    resetButton.addEventListener("click", resetBrowserSettings);
  }

  // Proxy settings
  const proxyServerSelect = document.getElementById("proxy-server-select");
  const customProxyInput = document.getElementById("custom-proxy-input");
  const saveProxyButton = document.getElementById("save-proxy-settings");
  const resetProxyButton = document.getElementById("reset-proxy-settings");

  if (proxyServerSelect) {
    proxyServerSelect.addEventListener("change", () => {
      const isCustom = proxyServerSelect.value === "custom";
      if (customProxyInput) {
        customProxyInput.style.display = isCustom ? "block" : "none";
      }
    });
  }

  if (saveProxyButton) {
    saveProxyButton.addEventListener("click", saveProxySettings);
  }

  if (resetProxyButton) {
    resetProxyButton.addEventListener("click", resetProxySettings);
  }

  // Load and populate proxy servers
  loadAndPopulateProxies();

  // Load saved browser settings
  loadBrowserSettings();

  // Load saved proxy settings
  loadProxySettings();

  // Load saved general settings
  loadGeneralSettings();

  // Auto-save when browser settings change
  const browserInputs = [
    "homepage-input",
    "enable-history",
    "enable-bookmarks",
    "user-agent-select",
  ];

  // Auto-save when general settings change
  const generalInputs = [
    "enable-floating-button",
    "enable-script-notifications",
  ];

  browserInputs.forEach((id) => {
    const element = document.getElementById(id);
    if (element) {
      if (element.type === "checkbox") {
        element.addEventListener("change", saveBrowserSettings);
      } else {
        element.addEventListener("change", saveBrowserSettings);
        element.addEventListener("input", saveBrowserSettings);
      }
    }
  });

  generalInputs.forEach((id) => {
    const element = document.getElementById(id);
    if (element) {
      if (element.type === "checkbox") {
        element.addEventListener("change", saveGeneralSettings);
      } else {
        element.addEventListener("change", saveGeneralSettings);
        element.addEventListener("input", saveGeneralSettings);
      }
    }
  });

  // Setup tab order functionality
  setupTabOrderEventListeners();
}

function applyTheme(themeName) {
  const root = document.documentElement;

  // Handle custom theme separately
  if (themeName === "custom") {
    applyCustomTheme();
    return;
  }

  // Find theme in themesData
  const theme = themesData.find((t) => t.id === themeName);

  if (theme) {
    // Apply theme colors from the theme object
    root.style.setProperty("--bg-primary", theme.colors.bgPrimary);
    root.style.setProperty("--bg-secondary", theme.colors.bgSecondary);
    root.style.setProperty("--accent-color", theme.colors.accentColor);
    root.style.setProperty("--accent-hover", theme.colors.accentHover);
    root.style.setProperty("--accent-color-rgb", theme.colors.accentColorRgb);
  } else {
    // Fallback to default theme if theme not found
    const defaultTheme = themesData.find((t) => t.id === "default");
    if (defaultTheme) {
      root.style.setProperty("--bg-primary", defaultTheme.colors.bgPrimary);
      root.style.setProperty("--bg-secondary", defaultTheme.colors.bgSecondary);
      root.style.setProperty("--accent-color", defaultTheme.colors.accentColor);
      root.style.setProperty("--accent-hover", defaultTheme.colors.accentHover);
      root.style.setProperty("--accent-color-rgb", defaultTheme.colors.accentColorRgb);
    }
  }

  // Apply theme colors to existing elements
  updateThemeColors();
}

function updateThemeColors() {
  const root = document.documentElement;
  const bgPrimary = root.style.getPropertyValue("--bg-primary") || "#23272f";
  const bgSecondary =
    root.style.getPropertyValue("--bg-secondary") || "#292d36";
  const accentColor =
    root.style.getPropertyValue("--accent-color") || "#007acc";

  // Update main app elements
  const appFrame = document.querySelector(".proxy-app-frame");
  const sidebar = document.querySelector(".proxy-sidebar");
  const content = document.querySelector(".proxy-content");

  if (appFrame) {
    appFrame.style.background = bgPrimary;
  }

  if (content) {
    content.style.background = bgPrimary;
  }

  // Update all card-based views
  const cardViews = document.querySelectorAll(".card-grid-view");
  cardViews.forEach((view) => {
    view.style.background = bgPrimary;
  });

  // Update card items
  const cardItems = document.querySelectorAll(
    ".card-item, .game-item, .script-item"
  );
  cardItems.forEach((item) => {
    item.style.background = bgSecondary;
  });

  // Update active buttons
  const activeButtons = document.querySelectorAll(
    ".sidebar-btn.active, .games-tab.active"
  );
  activeButtons.forEach((btn) => {
    btn.style.background = accentColor;
  });

  // Update existing modal elements if any are open
  const modalContents = document.querySelectorAll(".ocot-modal-content");
  modalContents.forEach((modal) => {
    modal.style.background = bgPrimary;
    modal.style.borderColor =
      root.style.getPropertyValue("--border-color") || "#404040";
  });

  // Update modal text colors
  const modalTexts = document.querySelectorAll(
    ".ocot-modal-content div, .ocot-modal-content p, .ocot-modal-content h2, .ocot-modal-content h3, .ocot-modal-content h4, .ocot-modal-content h5"
  );
  modalTexts.forEach((text) => {
    if (text.style.color && text.style.color.includes("#")) {
      // Update specific color mappings
      if (
        text.style.color.includes("#d4d4d4") ||
        text.style.color.includes("#aaa")
      ) {
        text.style.color =
          root.style.getPropertyValue("--text-secondary") || "#d4d4d4";
      } else if (text.style.color.includes("#fff")) {
        text.style.color =
          root.style.getPropertyValue("--text-primary") || "#fff";
      } else if (text.style.color.includes("#00bfff")) {
        text.style.color = accentColor;
      }
    }
  });

  // Update modal buttons
  const modalButtons = document.querySelectorAll(".ocot-modal-content button");
  modalButtons.forEach((btn) => {
    if (
      btn.style.backgroundColor &&
      btn.style.backgroundColor.includes("#007bff")
    ) {
      btn.style.backgroundColor = accentColor;
    }
  });

  // Update modal input fields
  const modalInputs = document.querySelectorAll(".ocot-modal-content input");
  modalInputs.forEach((input) => {
    if (input.style.background && input.style.background.includes("#")) {
      input.style.background = bgSecondary;
      input.style.borderColor =
        root.style.getPropertyValue("--border-color") || "#404040";
      input.style.color =
        root.style.getPropertyValue("--text-secondary") || "#d4d4d4";
    }
  });
}

function setupCustomTheme() {
  // Handle custom theme selection
  const customThemeOption = document.querySelector(
    '.theme-option[data-theme="custom"]'
  );
  const customThemePanel = document.getElementById("custom-theme-panel");

  // Show/hide custom theme panel
  customThemeOption.addEventListener("click", (e) => {
    e.stopPropagation();
    customThemePanel.style.display =
      customThemePanel.style.display === "none" ? "block" : "none";
  });

  // Color picker synchronization
  const setupColorSync = (colorId, textId) => {
    const colorInput = document.getElementById(colorId);
    const textInput = document.getElementById(textId);

    colorInput.addEventListener("input", () => {
      textInput.value = colorInput.value;
      updateCustomPreview();
    });

    textInput.addEventListener("input", () => {
      if (isValidHex(textInput.value)) {
        colorInput.value = textInput.value;
        updateCustomPreview();
      }
    });
  };

  setupColorSync("custom-accent-color", "custom-accent-text");
  setupColorSync("custom-bg-color", "custom-bg-text");
  setupColorSync("custom-secondary-color", "custom-secondary-text");

  // Apply and reset buttons
  document
    .getElementById("apply-custom-theme")
    .addEventListener("click", () => {
      saveCustomTheme();
      applyCustomTheme();
    });

  document
    .getElementById("reset-custom-theme")
    .addEventListener("click", () => {
      resetCustomTheme();
    });

  // Load saved custom theme
  loadCustomTheme();
}

function updateCustomPreview() {
  const accentColor = document.getElementById("custom-accent-text").value;
  const bgColor = document.getElementById("custom-bg-text").value;
  const secondaryColor = document.getElementById("custom-secondary-text").value;

  document.getElementById("custom-preview-1").style.background = bgColor;
  document.getElementById("custom-preview-2").style.background = accentColor;
  document.getElementById("custom-preview-3").style.background = secondaryColor;
}

function saveCustomTheme() {
  const customTheme = {
    accent: document.getElementById("custom-accent-text").value,
    background: document.getElementById("custom-bg-text").value,
    secondary: document.getElementById("custom-secondary-text").value,
  };

  localStorage.setItem("customTheme", JSON.stringify(customTheme));
  console.log("Custom theme saved:", customTheme);
}

function loadCustomTheme() {
  const saved = localStorage.getItem("customTheme");
  if (saved) {
    try {
      const theme = JSON.parse(saved);
      document.getElementById("custom-accent-color").value = theme.accent;
      document.getElementById("custom-accent-text").value = theme.accent;
      document.getElementById("custom-bg-color").value = theme.background;
      document.getElementById("custom-bg-text").value = theme.background;
      document.getElementById("custom-secondary-color").value = theme.secondary;
      document.getElementById("custom-secondary-text").value = theme.secondary;
      updateCustomPreview();
    } catch (e) {
      console.warn("Failed to load custom theme:", e);
    }
  }
}

function applyCustomTheme() {
  const saved = localStorage.getItem("customTheme");
  if (!saved) return;

  try {
    const theme = JSON.parse(saved);
    const root = document.documentElement;

    // Calculate darker version for hover
    const accentHover = adjustBrightness(theme.accent, -20);
    const accentRgb = hexToRgb(theme.accent);

    root.style.setProperty("--bg-primary", theme.secondary);
    root.style.setProperty("--bg-secondary", theme.background);
    root.style.setProperty("--accent-color", theme.accent);
    root.style.setProperty("--accent-hover", accentHover);
    root.style.setProperty(
      "--accent-color-rgb",
      `${accentRgb.r}, ${accentRgb.g}, ${accentRgb.b}`
    );

    updateThemeColors();
  } catch (e) {
    console.warn("Failed to apply custom theme:", e);
  }
}

function resetCustomTheme() {
  document.getElementById("custom-accent-color").value = "#00bfff";
  document.getElementById("custom-accent-text").value = "#00bfff";
  document.getElementById("custom-bg-color").value = "#292d36";
  document.getElementById("custom-bg-text").value = "#292d36";
  document.getElementById("custom-secondary-color").value = "#23272f";
  document.getElementById("custom-secondary-text").value = "#23272f";
  updateCustomPreview();
}

function isValidHex(hex) {
  return /^#[0-9A-F]{6}$/i.test(hex);
}

function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16),
    }
    : null;
}

function adjustBrightness(hex, percent) {
  const rgb = hexToRgb(hex);
  if (!rgb) return hex;

  const adjust = (color) =>
    Math.max(0, Math.min(255, color + (color * percent) / 100));

  const r = Math.round(adjust(rgb.r)).toString(16).padStart(2, "0");
  const g = Math.round(adjust(rgb.g)).toString(16).padStart(2, "0");
  const b = Math.round(adjust(rgb.b)).toString(16).padStart(2, "0");

  return `#${r}${g}${b}`;
}

function saveBrowserSettings() {
  const settings = {
    homepage:
      document.getElementById("homepage-input")?.value ||
      "https://google.com?igu=1",
    enableHistory: document.getElementById("enable-history")?.checked ?? true,
    enableBookmarks:
      document.getElementById("enable-bookmarks")?.checked ?? true,
    userAgent: document.getElementById("user-agent-select")?.value || "default",
  };

  localStorage.setItem("pocketBrowserSettings", JSON.stringify(settings));

  console.log("Settings: Saved browser settings", settings);

  // Dispatch custom event for immediate updates
  window.dispatchEvent(
    new CustomEvent("pocketBrowserSettingsChanged", {
      detail: settings,
    })
  );

  console.log("Settings: Dispatched pocketBrowserSettingsChanged event");

  // Show confirmation
  const saveButton = document.getElementById("save-browser-settings");
  if (saveButton) {
    const originalText = saveButton.innerHTML;
    saveButton.innerHTML = "✅ Saved!";
    saveButton.style.background = "#28a745";

    setTimeout(() => {
      saveButton.innerHTML = originalText;
    }, 2000);
  }
}

function resetBrowserSettings() {
  const defaults = {
    homepage: "https://google.com?igu=1",
    enableHistory: true,
    enableBookmarks: true,
    userAgent: "default",
  };

  // Update UI
  const homepageInput = document.getElementById("homepage-input");
  const historyCheck = document.getElementById("enable-history");
  const bookmarksCheck = document.getElementById("enable-bookmarks");
  const userAgentSelect = document.getElementById("user-agent-select");

  if (homepageInput) homepageInput.value = defaults.homepage;
  if (historyCheck) historyCheck.checked = defaults.enableHistory;
  if (bookmarksCheck) bookmarksCheck.checked = defaults.enableBookmarks;
  if (userAgentSelect) userAgentSelect.value = defaults.userAgent;

  // Save defaults
  localStorage.setItem("pocketBrowserSettings", JSON.stringify(defaults));

  // Show confirmation
  const resetButton = document.getElementById("reset-browser-settings");
  if (resetButton) {
    const originalText = resetButton.innerHTML;
    resetButton.innerHTML = "✅ Reset Complete";

    setTimeout(() => {
      resetButton.innerHTML = originalText;
    }, 2000);
  }
}

function loadBrowserSettings() {
  const saved = localStorage.getItem("pocketBrowserSettings");
  if (!saved) return;

  try {
    const settings = JSON.parse(saved);

    const homepageInput = document.getElementById("homepage-input");
    const historyCheck = document.getElementById("enable-history");
    const bookmarksCheck = document.getElementById("enable-bookmarks");
    const userAgentSelect = document.getElementById("user-agent-select");

    if (homepageInput)
      homepageInput.value = settings.homepage || "https://google.com?igu=1";
    if (historyCheck) historyCheck.checked = settings.enableHistory !== false;
    if (bookmarksCheck)
      bookmarksCheck.checked = settings.enableBookmarks !== false;
    if (userAgentSelect)
      userAgentSelect.value = settings.userAgent || "default";
  } catch (e) {
    console.warn("Failed to load browser settings:", e);
  }
}

// General Settings Functions
function saveGeneralSettings() {
  const settings = {
    enableFloatingButton:
      document.getElementById("enable-floating-button")?.checked ?? true,
    enableScriptNotifications:
      document.getElementById("enable-script-notifications")?.checked ?? true,
  };

  localStorage.setItem("ocot-general-settings", JSON.stringify(settings));

  console.log("Settings: Saved general settings", settings);

  // Update floating button visibility immediately
  updateFloatingButtonVisibility(settings.enableFloatingButton);

  // Show confirmation (no button for general settings, so just log)
  console.log("General settings saved successfully");
}

function loadGeneralSettings() {
  const saved = localStorage.getItem("ocot-general-settings");
  if (!saved) return;

  try {
    const settings = JSON.parse(saved);

    const floatingButtonCheck = document.getElementById(
      "enable-floating-button"
    );
    const scriptNotificationsCheck = document.getElementById(
      "enable-script-notifications"
    );

    if (floatingButtonCheck) {
      floatingButtonCheck.checked = settings.enableFloatingButton !== false;
    }
    if (scriptNotificationsCheck) {
      scriptNotificationsCheck.checked =
        settings.enableScriptNotifications !== false;
    }
  } catch (e) {
    console.warn("Failed to load general settings:", e);
  }
}

function updateFloatingButtonVisibility(enabled) {
  console.log("updateFloatingButtonVisibility called with enabled:", enabled);

  // Access the main app instance and update floating button visibility
  if (window.proxyClientApp && window.proxyClientApp.floatingButton) {
    if (enabled) {
      console.log("Floating button setting enabled");
      // Show floating button when client is hidden (if client is currently hidden)
      if (
        window.proxyClientApp.frame &&
        window.proxyClientApp.frame.style.display === "none"
      ) {
        console.log("Client is hidden, showing floating button");
        window.proxyClientApp.floatingButton.style.display = "flex";
      } else {
        console.log("Client is visible, keeping floating button hidden");
      }
    } else {
      console.log("Floating button setting disabled, hiding button");
      // Always hide floating button when disabled
      window.proxyClientApp.floatingButton.style.display = "none";
    }
  } else {
    console.log("proxyClientApp or floatingButton not found");
  }
}

// Load and populate proxy servers from data layer
async function loadAndPopulateProxies() {
  const proxyServerSelect = document.getElementById("proxy-server-select");
  if (!proxyServerSelect) {
    console.warn("Proxy server select element not found");
    return;
  }

  // Load proxies using universal data loader (proxies exports as 'proxiesList')
  let proxies = await loadData<ProxyData>('proxies', 'proxiesList');
  if (proxies.length === 0) {
    proxies = proxiesList;
  }

  // Clear existing options except custom
  proxyServerSelect.innerHTML = "";

  // Populate proxy options
  proxies.forEach((proxy) => {
    const option = document.createElement("option");
    option.value = proxy.id;
    option.textContent = proxy.name;
    option.title = proxy.description;
    proxyServerSelect.appendChild(option);
  });

  // Add custom option at the end
  const customOption = document.createElement("option");
  customOption.value = "custom";
  customOption.textContent = "Custom URL";
  proxyServerSelect.appendChild(customOption);

  console.log(`Loaded ${proxies.length} proxy servers`);
}

async function saveProxySettings() {
  const proxyServerSelect = document.getElementById("proxy-server-select");
  const customProxyUrl = document.getElementById("custom-proxy-url");

  let proxyUrl = "";
  const selectedServer = proxyServerSelect?.value || "work-bartlett";

  if (selectedServer === "custom") {
    let customUrl = customProxyUrl?.value?.trim() || "";
    if (customUrl) {
      // Add protocol if not present
      if (
        !customUrl.startsWith("http://") &&
        !customUrl.startsWith("https://")
      ) {
        customUrl = "https://" + customUrl;
      }
      proxyUrl = customUrl;
    } else {
      proxyUrl = "https://work.benjaminbartlett.net/"; // fallback to default
    }
  } else {
    // Load proxy data using universal loader (proxies exports as 'proxiesList')
    let proxies = await loadData<ProxyData>('proxies', 'proxiesList');
    if (proxies.length === 0) {
      proxies = proxiesList;
    }

    // Find the selected proxy
    const selectedProxy = proxies.find((p) => p.id === selectedServer);
    if (selectedProxy) {
      proxyUrl = selectedProxy.url;
    } else {
      // Fallback to default
      proxyUrl = "https://work.benjaminbartlett.net/";
    }
  }

  const settings = {
    server: selectedServer,
    url: proxyUrl,
    customUrl: customProxyUrl?.value?.trim() || "",
  };

  localStorage.setItem("proxyClientProxySettings", JSON.stringify(settings));

  console.log("Settings: Saved proxy settings", settings);

  // Dispatch custom event for immediate proxy tab reload
  window.dispatchEvent(
    new CustomEvent("proxySettingsChanged", {
      detail: settings,
    })
  );

  console.log("Settings: Dispatched proxySettingsChanged event");

  // Show confirmation
  const saveProxyButton = document.getElementById("save-proxy-settings");
  if (saveProxyButton) {
    const originalText = saveProxyButton.innerHTML;
    saveProxyButton.innerHTML = "✅ Saved!";
    saveProxyButton.style.background = "#28a745";

    setTimeout(() => {
      saveProxyButton.innerHTML = originalText;
    }, 2000);
  }
}

function resetProxySettings() {
  const defaults = {
    server: "work-bartlett",
    url: "https://work.benjaminbartlett.net/",
    customUrl: "",
  };

  // Update UI
  const proxyServerSelect = document.getElementById("proxy-server-select");
  const customProxyUrl = document.getElementById("custom-proxy-url");
  const customProxyInput = document.getElementById("custom-proxy-input");

  if (proxyServerSelect) proxyServerSelect.value = defaults.server;
  if (customProxyUrl) customProxyUrl.value = defaults.customUrl;
  if (customProxyInput) customProxyInput.style.display = "none";

  // Save defaults
  localStorage.setItem("proxyClientProxySettings", JSON.stringify(defaults));

  console.log("Settings: Reset proxy settings to defaults", defaults);

  // Dispatch custom event for immediate proxy tab reload
  window.dispatchEvent(
    new CustomEvent("proxySettingsChanged", {
      detail: defaults,
    })
  );

  console.log("Settings: Dispatched proxySettingsChanged event for reset");

  // Show confirmation
  const resetProxyButton = document.getElementById("reset-proxy-settings");
  if (resetProxyButton) {
    const originalText = resetProxyButton.innerHTML;
    resetProxyButton.innerHTML = "✅ Reset Complete";

    setTimeout(() => {
      resetProxyButton.innerHTML = originalText;
    }, 2000);
  }
}

function loadProxySettings() {
  const saved = localStorage.getItem("proxyClientProxySettings");
  if (!saved) return;

  try {
    const settings = JSON.parse(saved);

    const proxyServerSelect = document.getElementById("proxy-server-select");
    const customProxyUrl = document.getElementById("custom-proxy-url");
    const customProxyInput = document.getElementById("custom-proxy-input");

    if (proxyServerSelect)
      proxyServerSelect.value = settings.server || "work-bartlett";
    if (customProxyUrl) customProxyUrl.value = settings.customUrl || "";

    // Show custom input if custom is selected
    if (customProxyInput && settings.server === "custom") {
      customProxyInput.style.display = "block";
    }
  } catch (e) {
    console.warn("Failed to load proxy settings:", e);
  }
}

// Export utility functions for use by proxy view
export function getProxySettings() {
  const saved = localStorage.getItem("proxyClientProxySettings");
  if (!saved) {
    return {
      server: "work-bartlett",
      url: "https://work.benjaminbartlett.net/",
      customUrl: "",
    };
  }

  try {
    return JSON.parse(saved);
  } catch (e) {
    return {
      server: "work-bartlett",
      url: "https://work.benjaminbartlett.net/",
      customUrl: "",
    };
  }
}

// Export utility functions for use by pocket browser
export function getPocketBrowserSettings() {
  const saved = localStorage.getItem("pocketBrowserSettings");

  const defaults = {
    homepage: "https://google.com?igu=1",
    enableHistory: true,
    enableBookmarks: true,
    userAgent: "default",
  };

  if (!saved) {
    return defaults;
  }

  try {
    const parsed = JSON.parse(saved);
    // Merge with defaults to ensure all properties exist
    return { ...defaults, ...parsed };
  } catch (e) {
    return defaults;
  }
}

// Export utility function to get general settings
export function getGeneralSettings() {
  const saved = localStorage.getItem("ocot-general-settings");

  const defaults = {
    enableFloatingButton: true,
    enableScriptNotifications: true,
  };

  if (!saved) {
    return defaults;
  }

  try {
    const parsed = JSON.parse(saved);
    // Merge with defaults to ensure all properties exist
    return { ...defaults, ...parsed };
  } catch (e) {
    return defaults;
  }
}

// Tab Order Management Functions
function injectTabOrderCSS() {
  if (document.getElementById("tab-order-style")) return;

  const style = document.createElement("style");
  style.id = "tab-order-style";
  style.textContent = `
    .tab-order-list {
      max-height: 400px;
      overflow-y: auto;
    }
    
    .tab-order-item {
      background: #23272f;
      border: 1px solid #404040;
      border-radius: 6px;
      padding: 12px;
      display: flex;
      align-items: center;
      gap: 12px;
      cursor: move;
      transition: all 0.2s ease;
      user-select: none;
    }
    
    .tab-order-item:hover {
      background: #2a2e37;
      border-color: #525252;
      transform: translateY(-1px);
    }
    
    .tab-order-item.dragging {
      opacity: 0.5;
      transform: rotate(2deg);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    }
    
    .tab-order-item.drag-over {
      border-color: #00bfff;
      box-shadow: 0 0 0 2px rgba(0, 191, 255, 0.3);
    }
    
    .tab-drag-handle {
      font-size: 1.2rem;
      color: #666;
      cursor: grab;
      line-height: 1;
    }
    
    .tab-drag-handle:active {
      cursor: grabbing;
    }
    
    .tab-info {
      flex: 1;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .tab-icon {
      font-size: 1.1rem;
      width: 20px;
      text-align: center;
    }
    
    .tab-label {
      color: #fff;
      font-weight: 500;
    }
    
    .tab-order-controls {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    
    .tab-order-btn {
      background: #404040;
      border: none;
      border-radius: 4px;
      color: #fff;
      font-size: 0.7rem;
      padding: 4px 6px;
      cursor: pointer;
      transition: background 0.2s;
      line-height: 1;
    }
    
    .tab-order-btn:hover {
      background: #00bfff;
    }
    
    .tab-order-btn:disabled {
      background: #2a2e37;
      color: #666;
      cursor: not-allowed;
    }
    
    /* Drag and drop visual feedback */
    .tab-order-list.drag-active {
      background: rgba(0, 191, 255, 0.05);
      border-radius: 6px;
    }
  `;
  document.head.appendChild(style);
}

function getTabOrder() {
  const defaultOrder = [
    "proxyButton",
    "gamesButton",
    "bookmarkletsButton",
    "scriptsButton",
    "notesButton",
    "calculatorButton",
    "consoleButton",
    "cloakingButton",
    "historyFloodButton",
    "corsProxyButton",
    "pocketBrowserButton",
    "settingsButton",
  ];

  try {
    const saved = localStorage.getItem("ocot-tab-order");
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length === defaultOrder.length) {
        const hasAllTabs = defaultOrder.every((tab) => parsed.includes(tab));
        if (hasAllTabs) {
          return parsed;
        }
      }
    }
  } catch (e) {
    console.warn("Failed to load tab order from localStorage:", e);
  }
  return defaultOrder;
}

function getTabMetadata() {
  return {
    proxyButton: { label: "Proxy", icon: "🌐" },
    gamesButton: { label: "Games List", icon: "🎮" },
    bookmarkletsButton: { label: "Bookmarklets", icon: "🔖" },
    scriptsButton: { label: "Scripts", icon: "📜" },
    notesButton: { label: "Notes", icon: "📝" },
    calculatorButton: { label: "Calculator", icon: "🧮" },
    consoleButton: { label: "Console", icon: "💻" },
    cloakingButton: { label: "Cloaking", icon: "🎭" },
    historyFloodButton: { label: "History Flood", icon: "🌊" },
    corsProxyButton: { label: "CORS Proxy", icon: "🔄" },
    pocketBrowserButton: { label: "Pocket Browser", icon: "🔍" },
    settingsButton: { label: "Settings", icon: "⚙️" },
  };
}

function saveTabOrder(tabOrder) {
  try {
    localStorage.setItem("ocot-tab-order", JSON.stringify(tabOrder));
    console.log("Tab order saved:", tabOrder);
    // Dispatch event to notify sidebar to refresh
    document.dispatchEvent(new CustomEvent("tabOrderChanged"));
  } catch (e) {
    console.error("Failed to save tab order to localStorage:", e);
  }
}

function resetTabOrder() {
  try {
    localStorage.removeItem("ocot-tab-order");
    console.log("Tab order reset to default");
    // Dispatch event to notify sidebar to refresh
    document.dispatchEvent(new CustomEvent("tabOrderChanged"));
    // Re-render the tab order list
    renderTabOrderList();
  } catch (e) {
    console.error("Failed to reset tab order:", e);
  }
}

function renderTabOrderList() {
  const tabOrderList = document.getElementById("tab-order-list");
  if (!tabOrderList) return;

  const tabOrder = getTabOrder();
  const tabMetadata = getTabMetadata();

  tabOrderList.innerHTML = tabOrder
    .map((tabKey, index) => {
      const tab = tabMetadata[tabKey];
      if (!tab) return "";

      return `
      <div class="tab-order-item" draggable="true" data-tab-key="${tabKey}" data-index="${index}">
        <div class="tab-drag-handle">⋮⋮</div>
        <div class="tab-info">
          <div class="tab-icon">${tab.icon}</div>
          <div class="tab-label">${tab.label}</div>
        </div>
        <div class="tab-order-controls">
          <button class="tab-order-btn" onclick="moveTabUp('${tabKey}')" ${index === 0 ? "disabled" : ""
        }>▲</button>
          <button class="tab-order-btn" onclick="moveTabDown('${tabKey}')" ${index === tabOrder.length - 1 ? "disabled" : ""
        }>▼</button>
        </div>
      </div>
    `;
    })
    .join("");

  // Add drag and drop event listeners
  setupDragAndDrop();
}

function setupDragAndDrop() {
  const tabOrderList = document.getElementById("tab-order-list");
  if (!tabOrderList) return;

  let draggedElement = null;

  tabOrderList.addEventListener("dragstart", (e) => {
    if (!e.target.classList.contains("tab-order-item")) return;

    draggedElement = e.target;
    e.target.classList.add("dragging");
    tabOrderList.classList.add("drag-active");

    // Set drag data
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/html", e.target.outerHTML);
  });

  tabOrderList.addEventListener("dragend", (e) => {
    if (!e.target.classList.contains("tab-order-item")) return;

    e.target.classList.remove("dragging");
    tabOrderList.classList.remove("drag-active");

    // Remove drag-over class from all items
    tabOrderList.querySelectorAll(".tab-order-item").forEach((item) => {
      item.classList.remove("drag-over");
    });

    draggedElement = null;
  });

  tabOrderList.addEventListener("dragover", (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";

    const afterElement = getDragAfterElement(tabOrderList, e.clientY);
    const dragging = tabOrderList.querySelector(".dragging");

    // Remove drag-over class from all items
    tabOrderList.querySelectorAll(".tab-order-item").forEach((item) => {
      item.classList.remove("drag-over");
    });

    if (afterElement == null) {
      // Add drag-over to last element
      const items = [
        ...tabOrderList.querySelectorAll(".tab-order-item:not(.dragging)"),
      ];
      if (items.length > 0) {
        items[items.length - 1].classList.add("drag-over");
      }
    } else {
      afterElement.classList.add("drag-over");
    }
  });

  tabOrderList.addEventListener("drop", (e) => {
    e.preventDefault();

    const afterElement = getDragAfterElement(tabOrderList, e.clientY);
    const dragging = tabOrderList.querySelector(".dragging");

    if (dragging && dragging !== afterElement) {
      if (afterElement == null) {
        tabOrderList.appendChild(dragging);
      } else {
        tabOrderList.insertBefore(dragging, afterElement);
      }

      // Update the saved order
      updateTabOrderFromDOM();
    }
  });
}

function getDragAfterElement(container, y) {
  const draggableElements = [
    ...container.querySelectorAll(".tab-order-item:not(.dragging)"),
  ];

  return draggableElements.reduce(
    (closest, child) => {
      const box = child.getBoundingClientRect();
      const offset = y - box.top - box.height / 2;

      if (offset < 0 && offset > closest.offset) {
        return { offset: offset, element: child };
      } else {
        return closest;
      }
    },
    { offset: Number.NEGATIVE_INFINITY }
  ).element;
}

function updateTabOrderFromDOM() {
  const tabOrderList = document.getElementById("tab-order-list");
  if (!tabOrderList) return;

  const newOrder = [...tabOrderList.querySelectorAll(".tab-order-item")].map(
    (item) => item.getAttribute("data-tab-key")
  );

  saveTabOrder(newOrder);

  // Re-render to update button states
  setTimeout(() => renderTabOrderList(), 100);
}

// Global functions for arrow buttons
window.moveTabUp = function (tabKey) {
  const tabOrder = getTabOrder();
  const currentIndex = tabOrder.indexOf(tabKey);

  if (currentIndex > 0) {
    // Swap with previous item
    [tabOrder[currentIndex - 1], tabOrder[currentIndex]] = [
      tabOrder[currentIndex],
      tabOrder[currentIndex - 1],
    ];
    saveTabOrder(tabOrder);
    renderTabOrderList();
  }
};

window.moveTabDown = function (tabKey) {
  const tabOrder = getTabOrder();
  const currentIndex = tabOrder.indexOf(tabKey);

  if (currentIndex < tabOrder.length - 1) {
    // Swap with next item
    [tabOrder[currentIndex], tabOrder[currentIndex + 1]] = [
      tabOrder[currentIndex + 1],
      tabOrder[currentIndex],
    ];
    saveTabOrder(tabOrder);
    renderTabOrderList();
  }
};

function setupTabOrderEventListeners() {
  // Reset button
  const resetButton = document.getElementById("reset-tab-order");
  if (resetButton) {
    resetButton.addEventListener("click", () => {
      resetTabOrder();
      // Show confirmation feedback
      const originalText = resetButton.innerHTML;
      resetButton.innerHTML = "✅ Reset Complete";
      resetButton.style.background = "#28a745";

      setTimeout(() => {
        resetButton.innerHTML = originalText;
        resetButton.style.background = "#6c757d";
      }, 2000);
    });
  }

  // Initial render
  renderTabOrderList();
}
