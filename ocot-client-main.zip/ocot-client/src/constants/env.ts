/**
 * Environment configuration for the Proxy Client
 * Controls data loading strategy based on environment
 */

export type Environment = 'dev' | 'prod';

/**
 * Current environment - change this to switch between dev/prod modes
 * - 'dev': Uses local JSON files and TypeScript fallbacks (no CDN)
 * - 'prod': Uses CDN-first loading with local/TypeScript fallbacks
 * 
 * TO SWITCH ENVIRONMENTS: Change 'prod' to 'dev' or vice versa below
 */
export const ENV: Environment = 'prod';

/**
 * Environment-specific configuration
 */
export const envConfig = {
    dev: {
        name: 'Development',
        useCDN: false,
        useLocalJSON: true,
        useTypeScriptFallback: true,
        debugLogging: true,
    },
    prod: {
        name: 'Production',
        useCDN: true,
        useLocalJSON: true, // Keep as fallback
        useTypeScriptFallback: true, // Keep as final fallback
        debugLogging: false,
    }
} as const;

/**
 * Get the current environment configuration
 */
export function getCurrentEnvConfig() {
    return envConfig[ENV];
}

/**
 * Check if we're in development mode
 */
export function isDev(): boolean {
    return ENV === 'dev';
}

/**
 * Check if we're in production mode
 */
export function isProd(): boolean {
    return ENV === 'prod';
}

/**
 * Get a human-readable environment name
 */
export function getEnvironmentName(): string {
    return envConfig[ENV].name;
}

/**
 * Log environment information to console
 */
export function logEnvironmentInfo(): void {
    const config = getCurrentEnvConfig();
    console.log(`🏗️  Proxy Client Environment: ${config.name}`);
    console.log(`   - CDN Loading: ${config.useCDN ? '✅' : '❌'}`);
    console.log(`   - Local JSON: ${config.useLocalJSON ? '✅' : '❌'}`);
    console.log(`   - TypeScript Fallback: ${config.useTypeScriptFallback ? '✅' : '❌'}`);
    console.log(`   - Debug Logging: ${config.debugLogging ? '✅' : '❌'}`);
}