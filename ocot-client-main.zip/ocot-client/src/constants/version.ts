// This file contains the application version
// This gets updated automatically during build process
export const APP_VERSION = "2.5.7";
