declare global {
  interface Window {
    proxyFrame: HTMLElement | null;
    proxyClientApp: ProxyClientApp | null;
    autoHideEnabled?: boolean;
    autoHideBlurHandler?: () => void;
    autoRemoveEnabled?: boolean;
    autoRemoveBlurHandler?: () => void;
    antiForceReloadEnabled?: boolean;
    antiForceReloadBeforeUnloadHandler?: (e: BeforeUnloadEvent) => string;
    pageEditorEnabled?: boolean;
    forceSelectEnabled?: boolean;
  }
}

// Data structures
export interface GameData {
  url: string;
  title: string;
  type: "blocked" | "unblocked" | "cors-optimized";
}

export interface ScriptData {
  id: string;
  title: string;
  description: string;
  category: "utility" | "privacy" | "gaming" | "protection";
  handler: string;
  stateful?: boolean;
}

// Handler interface
export interface Handler {
  id?: string;
  title?: string;
  description?: string;
  category?: "utility" | "privacy" | "gaming" | "protection";
  stateful?: boolean;
  isEnabled?: () => boolean;
  onEnable?: () => Promise<void>;
  onDisable?: () => Promise<void>;
  onActivate: () => Promise<void>;
}

// Settings interface
export interface GeneralSettings {
  enableScriptNotifications: boolean;
  defaultProxyUrl: string;
  autoSaveNotes: boolean;
  showFloatingButton: boolean;
  devMode: boolean;
}

// Modal types
export type ModalType = "info" | "success" | "warning" | "error" | "question" | "input";

export interface ModalElements {
  modal: HTMLElement;
  modalContent: HTMLElement & { _closeButton?: HTMLElement };
  container: HTMLElement;
}

// Console types
export interface ConsoleBackup {
  log: (...args: any[]) => void;
  error: (...args: any[]) => void;
  warn: (...args: any[]) => void;
  info: (...args: any[]) => void;
}

// ProxyClientApp class definition
export interface ProxyClientApp {
  frame: HTMLElement | null;
  views: Record<string, HTMLElement>;
  sidebar: any;
  sidebarButtons: Record<string, HTMLElement>;
  isMaximized: boolean;
  normalFrameStyle: string | null;
  floatingButton: HTMLElement | null;
  isDragging: boolean;
  topBarDragHandlers: any;
  isFrameDragging: boolean;
  dragOffset: { x: number; y: number };
  launch(): void;
  cleanup?(): void;
  hideProxyClient?(): void;
  showProxyClient?(): void;
  toggleProxyClient?(): void;
}

export {};