import { showModal, showConfirmModal } from "../utils/modalHelpers.js";
import { getGeneralSettings } from "../views/settings.js";
import type { Handler } from "../types/global.d.ts";

const autoremoveHandler: Handler = {
  isEnabled(): boolean {
    return window.autoRemoveEnabled || false;
  },

  async onEnable(): Promise<void> {
    // Show confirmation dialog since this is destructive
    const confirmed = await showConfirmModal(
      "This will automatically <strong>REMOVE</strong> the entire Ocot Client when you:<br>• Switch to another tab<br>• Click outside the application<br><br><strong>WARNING:</strong> Unlike auto-hide, this will completely remove the app and you'll need to reload/re-inject it to use it again.<br><br>Are you sure you want to enable auto-remove?",
      "Enable Auto-Remove Script?",
      "Enable Auto-Remove",
      "Cancel"
    );

    if (!confirmed) {
      return;
    }

    // Enable auto-remove
    window.autoRemoveBlurHandler = () => {
      // Use setTimeout to allow DOM to update before checking activeElement
      setTimeout(() => {
        // Check if the blur was caused by focusing on an internal iframe
        const activeElement = document.activeElement;

        // Helper function to check if element is an internal iframe
        const isInternalIframe = (element: Element | null): boolean => {
          if (!element || element.tagName !== "IFRAME") {
            return false;
          }

          // Check if it's one of our internal iframes
          const internalIframeIds = [
            "ocot-proxy-iframe",
            "ocot-pocket-browser-iframe",
          ];
          return internalIframeIds.includes(element.id);
        };

        // Don't remove if focus moved to an internal iframe
        if (isInternalIframe(activeElement)) {
          return;
        }

        // Remove the proxy client when window loses focus (tab switch)
        if (window.proxyFrame && window.proxyFrame.style.display !== "none") {
          try {
            // Completely remove the proxy client
            if (window.proxyFrame.parentNode) {
              window.proxyFrame.parentNode.removeChild(window.proxyFrame);
            }

            // Remove floating button if it exists
            const floatingButton = document.querySelector(
              '[title*="Show Ocot Client"], [title*="Hide Ocot Client"]'
            );
            if (floatingButton && floatingButton.parentNode) {
              floatingButton.parentNode.removeChild(floatingButton);
            }

            // Clean up global variables
            if (window.proxyClientApp) {
              // Call cleanup method if available
              if (typeof window.proxyClientApp.cleanup === "function") {
                window.proxyClientApp.cleanup();
              }
              window.proxyClientApp = null;
            }

            window.proxyFrame = null;
            window.autoRemoveEnabled = false;

            // Clean up event listeners
            if (window.autoRemoveBlurHandler) {
              window.removeEventListener("blur", window.autoRemoveBlurHandler);
            }

            // Show notification before complete removal (if enabled in settings)
            const generalSettings = getGeneralSettings();
            if (generalSettings.enableScriptNotifications) {
              const notification = document.createElement("div");
              notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: #ff6b6b;
                color: white;
                padding: 12px 20px;
                border-radius: 8px;
                font-family: Arial, sans-serif;
                font-size: 14px;
                z-index: 999999;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                animation: slideIn 0.3s ease-out;
              `;
              notification.innerHTML = "🗑️ Ocot Client Auto-Removed";

              // Add animation
              const style = document.createElement("style");
              style.textContent = `
                @keyframes slideIn {
                  from { transform: translateX(100%); opacity: 0; }
                  to { transform: translateX(0); opacity: 1; }
                }
              `;
              document.head.appendChild(style);
              document.body.appendChild(notification);

              // Remove notification after 3 seconds
              setTimeout(() => {
                if (notification.parentNode) {
                  notification.parentNode.removeChild(notification);
                }
                if (style.parentNode) {
                  style.parentNode.removeChild(style);
                }
              }, 3000);
            }
          } catch (error) {
            console.warn("Auto-remove cleanup error:", error);
          }
        }
      }, 0);
    };

    // Add event listeners
    window.addEventListener("blur", window.autoRemoveBlurHandler);
    window.autoRemoveEnabled = true;

    await showModal(
      "The Ocot Client is now set to automatically <strong>REMOVE ITSELF</strong> when you:<br>• Switch to another tab<br>• Click outside the application<br><br><strong>WARNING:</strong> Unlike auto-hide, this will completely remove the app. You'll need to reload the page or re-inject the client to use it again.<br><br>Use this script again to disable auto-remove.",
      "Auto-remove Enabled",
      "warning"
    );
  },

  async onDisable(): Promise<void> {
    // Disable auto-remove
    if (window.autoRemoveBlurHandler) {
      window.removeEventListener("blur", window.autoRemoveBlurHandler);
    }
    window.autoRemoveEnabled = false;

    await showModal(
      "The Ocot Client will no longer automatically remove itself when you switch tabs or click away.<br><br>You can manually hide it using the Hide App button or the backslash (\\) key.",
      "Auto-remove Disabled",
      "success"
    );
  },

  async onActivate(): Promise<void> {
    if (autoremoveHandler.isEnabled?.()) {
      await autoremoveHandler.onDisable?.();
    } else {
      await autoremoveHandler.onEnable?.();
    }
  },
};

export default autoremoveHandler;
