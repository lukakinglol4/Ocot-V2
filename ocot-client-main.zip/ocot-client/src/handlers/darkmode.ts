import { showModal } from "../utils/modalHelpers.js";

interface Handler {
    id: string;
    title: string;
    description: string;
    category: string;
    stateful: boolean;
    isEnabled(): boolean;
    onEnable(): Promise<void>;
    onDisable(): Promise<void>;
    onActivate(): Promise<void>;
}

const DARK_MODE_STORAGE_KEY = 'ocot-dark-mode-enabled';

// Handler implementation
const DarkModeHandler = {
    id: "darkmode",
    title: "Dark Mode",
    description: "Apply dark mode styling to any webpage",
    category: "utility",
    stateful: true,

    isEnabled(): boolean {
        return (window as any).ocotDarkModeEnabled || false;
    },

    async onEnable(): Promise<void> {
        try {
            // Create and inject dark mode CSS
            const darkModeStyle = this.createDarkModeCSS();
            darkModeStyle.id = 'ocot-dark-mode-style';
            document.head.appendChild(darkModeStyle);

            // Mark as enabled globally
            (window as any).ocotDarkModeEnabled = true;
            localStorage.setItem(DARK_MODE_STORAGE_KEY, 'true');

            showModal(
                "Dark mode has been applied to this page. Colors, backgrounds, and text have been inverted for better readability in low-light environments.",
                "Dark Mode Enabled",
                "success"
            );

        } catch (error) {
            console.error('Dark Mode Enable Error:', error);
            showModal(
                "Failed to enable dark mode. This might be due to website restrictions or conflicting styles.",
                "Dark Mode Error",
                "error"
            );
        }
    },

    async onDisable(): Promise<void> {
        try {
            // Remove dark mode CSS
            const existingStyle = document.getElementById('ocot-dark-mode-style');
            if (existingStyle) {
                existingStyle.remove();
            }

            // Mark as disabled globally
            (window as any).ocotDarkModeEnabled = false;
            localStorage.removeItem(DARK_MODE_STORAGE_KEY);

            showModal(
                "Dark mode has been disabled. The page has been restored to its original appearance.",
                "Dark Mode Disabled",
                "success"
            );

        } catch (error) {
            console.error('Dark Mode Disable Error:', error);
            showModal(
                "Failed to disable dark mode completely. Some styles might persist until page refresh.",
                "Dark Mode Disable Error",
                "warning"
            );
        }
    },

    async onActivate(): Promise<void> {
        if (this.isEnabled()) {
            await this.onDisable();
        } else {
            await this.onEnable();
        }
    },

    createDarkModeCSS(): HTMLStyleElement {
        const style = document.createElement('style');
        style.textContent = `
      /* Ocot Dark Mode Override Styles */
      
      /* High priority universal dark mode */
      html, body {
        background-color: #1a1a1a !important;
        color: #e0e0e0 !important;
        filter: none !important;
      }

      /* Text elements */
      p, span, div, h1, h2, h3, h4, h5, h6, a, li, td, th, label, button, input, textarea, select {
        color: #e0e0e0 !important;
      }

      /* Background elements */
      div, section, article, aside, nav, header, footer, main, form {
        background-color: #2d2d2d !important;
        border-color: #444 !important;
      }

      /* Specific element overrides */
      body * {
        background-color: #2d2d2d !important;
        color: #e0e0e0 !important;
        border-color: #444 !important;
      }

      /* Input elements */
      input, textarea, select, button {
        background-color: #3a3a3a !important;
        color: #e0e0e0 !important;
        border: 1px solid #555 !important;
      }

      input:focus, textarea:focus, select:focus {
        background-color: #4a4a4a !important;
        border-color: #666 !important;
        outline: 1px solid #777 !important;
      }

      /* Links */
      a, a:visited {
        color: #66b3ff !important;
      }

      a:hover {
        color: #99ccff !important;
      }

      /* Images and media - preserve but add dark overlay */
      img {
        opacity: 0.9 !important;
        filter: brightness(0.8) contrast(1.1) !important;
      }

      video {
        filter: brightness(0.9) !important;
      }

      /* Code blocks */
      pre, code {
        background-color: #1e1e1e !important;
        color: #f0f0f0 !important;
        border: 1px solid #444 !important;
      }

      /* Tables */
      table {
        background-color: #2d2d2d !important;
        border-color: #444 !important;
      }

      th {
        background-color: #3a3a3a !important;
        color: #f0f0f0 !important;
      }

      tr:nth-child(even) {
        background-color: #353535 !important;
      }

      tr:nth-child(odd) {
        background-color: #2d2d2d !important;
      }

      /* Common UI elements */
      .navbar, .nav, .menu, .header, .footer, .sidebar {
        background-color: #1a1a1a !important;
        color: #e0e0e0 !important;
      }

      /* Cards and containers */
      .card, .panel, .box, .container, .wrapper {
        background-color: #2d2d2d !important;
        border-color: #444 !important;
        color: #e0e0e0 !important;
      }

      /* Buttons */
      button, .button, .btn {
        background-color: #4a4a4a !important;
        color: #e0e0e0 !important;
        border: 1px solid #666 !important;
      }

      button:hover, .button:hover, .btn:hover {
        background-color: #5a5a5a !important;
      }

      /* Modals and overlays */
      .modal, .overlay, .popup {
        background-color: #2d2d2d !important;
        color: #e0e0e0 !important;
        border: 1px solid #444 !important;
      }

      /* Scrollbars */
      ::-webkit-scrollbar {
        background-color: #2d2d2d !important;
      }

      ::-webkit-scrollbar-thumb {
        background-color: #555 !important;
        border: 1px solid #666 !important;
      }

      ::-webkit-scrollbar-thumb:hover {
        background-color: #666 !important;
      }

      /* Preserve proxy client styling */
      #proxy-client-app,
      #proxy-client-app *,
      .proxy-sidebar,
      .proxy-sidebar *,
      [id*="proxy-client"],
      [class*="proxy-client"] {
        background-color: unset !important;
        color: unset !important;
        border-color: unset !important;
        filter: none !important;
      }

      /* Don't affect existing dark themes */
      [data-theme="dark"] *,
      [data-bs-theme="dark"] *,
      .dark *,
      .dark-mode *,
      .theme-dark * {
        filter: none !important;
      }

      /* Special handling for white backgrounds that should be dark */
      *[style*="background-color: white"],
      *[style*="background-color: #fff"],
      *[style*="background-color: #ffffff"],
      *[style*="background: white"],
      *[style*="background: #fff"],
      *[style*="background: #ffffff"] {
        background-color: #2d2d2d !important;
      }

      /* Special handling for black text that should be light */
      *[style*="color: black"],
      *[style*="color: #000"],
      *[style*="color: #000000"] {
        color: #e0e0e0 !important;
      }
    `;

        return style;
    }
};

export default DarkModeHandler as Handler;