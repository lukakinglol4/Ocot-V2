import { showModal } from "../utils/modalHelpers.js";
import type { Handler } from "../types/global.d.ts";

export default {
  async onActivate(): Promise<void> {
    try {
      (function () {
        let script = document.createElement("script");
        script.src =
          "https://cdn.jsdelivr.net/gh/randomstuff69/blooketcheatsplus@master/GUI/Gui.js";
        document.body.appendChild(script);
      })();

      await showModal(
        "Blooket Cheats GUI is being loaded. Check the page for the cheats interface.",
        "Blooket Cheats Loading",
        "success"
      );
    } catch (error: any) {
      await showModal(
        `Error loading Blooket Cheats: ${error?.message || 'Unknown error'}`,
        "Blooket Cheats Error",
        "error"
      );
    }
  },
} as Handler;
