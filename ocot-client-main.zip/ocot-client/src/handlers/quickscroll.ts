import { showModal } from "../utils/modalHelpers.js";
import { getGeneralSettings } from "../views/settings.js";
import type { Handler } from "../types/global.d.ts";

export default {
  async onActivate(): Promise<void> {
    try {
      // Function to scroll to bottom with smooth animation
      function quickScroll(): number {
        // Get the total scroll height
        const scrollHeight = Math.max(
          document.body.scrollHeight,
          document.documentElement.scrollHeight,
          document.body.offsetHeight,
          document.documentElement.offsetHeight,
          document.body.clientHeight,
          document.documentElement.clientHeight
        );

        // Scroll to the bottom
        window.scrollTo({
          top: scrollHeight,
          behavior: "smooth",
        });

        return scrollHeight;
      }

      // Execute the scroll
      const scrollHeight = quickScroll();

      // Show notification in top-right corner (similar to auto-hide/auto-remove notifications)
      const generalSettings = getGeneralSettings();
      if (generalSettings.enableScriptNotifications) {
        const notification = document.createElement("div");
        notification.style.cssText = `
          position: fixed;
          top: 20px;
          right: 20px;
          background: #007acc;
          color: white;
          padding: 12px 20px;
          border-radius: 8px;
          font-family: Arial, sans-serif;
          font-size: 14px;
          z-index: 999999;
          box-shadow: 0 4px 12px rgba(0,0,0,0.3);
          animation: slideIn 0.3s ease-out;
        `;
        notification.innerHTML = "📜 Scrolled to the bottom of the page";

        // Add animation style if not already present
        if (!document.getElementById("quick-scroll-notification-style")) {
          const style = document.createElement("style");
          style.id = "quick-scroll-notification-style";
          style.textContent = `
            @keyframes slideIn {
              from { transform: translateX(100%); opacity: 0; }
              to { transform: translateX(0); opacity: 1; }
            }
          `;
          document.head.appendChild(style);
        }

        document.body.appendChild(notification);

        // Remove notification after 3 seconds
        setTimeout(() => {
          if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
          }
        }, 3000);
      }

      // Also show a modal confirmation for non-notification users
      if (!generalSettings.enableScriptNotifications) {
        await showModal(
          `Successfully scrolled to the bottom of the page.<br><br>Total page height: ${Math.round(
            scrollHeight
          )}px`,
          "Quick Scroll Complete",
          "success"
        );
      }
    } catch (error: any) {
      await showModal(
        `Error during quick scroll: ${error?.message || 'Unknown error'}<br><br>This may occur on pages with dynamic content or scroll restrictions.`,
        "Quick Scroll Failed",
        "error"
      );
    }
  },
} as Handler;
