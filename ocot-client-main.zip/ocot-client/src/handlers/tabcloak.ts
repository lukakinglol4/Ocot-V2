import { showInputModal } from "../utils/modalHelpers.js";
import type { Handler } from "../types/global.d.ts";

export default {
  async onActivate(): Promise<void> {
    const url = await showInputModal(
      "Enter the URL you want to cloak in a new tab:",
      "https://example.com",
      "Tab Cloak - Enter URL",
      "url"
    ) as string | null;

    if (!url) return; // User cancelled

    const win = window.open();
    if (!win) return; // Popup blocked

    const iframe = win.document.createElement("iframe");
    iframe.style.cssText =
      "position:fixed;width:100vw;height:100vh;top:0px;left:0px;right:0px;bottom:0px;z-index:2147483647;background-color:white;border:none;";
    if (url.includes("https://") || url.includes("http://")) {
      iframe.src = url;
    } else {
      iframe.src = "https://" + url;
    }
    win.document.body.appendChild(iframe);
  },
} as Handler;
