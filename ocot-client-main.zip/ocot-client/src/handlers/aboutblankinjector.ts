import {
  showInputModal,
  showModal,
  createBaseModal,
  removeModal,
} from "../utils/modalHelpers.js";
import type { Handler } from "../types/global.d.ts";

import { getLatestVersionInfo } from "../utils/helpers.js";

export default {
  async onActivate(): Promise<void> {
    // Show injection method selection using themed modal
    const showInjectionMethodModal = (): Promise<string | null> => {
      return new Promise((resolve) => {
        const { modal, modalContent } = createBaseModal(
          "About:blank Injector",
          "info"
        );

        // Create message content
        const messageDiv = document.createElement("div");
        messageDiv.style.cssText = `
          color: var(--text-secondary, #d4d4d4);
          line-height: 1.5;
          margin-bottom: 20px;
          font-size: 0.95rem;
        `;
        messageDiv.innerHTML =
          "Select an injection method to add scripts to a new about:blank page:";
        modalContent.appendChild(messageDiv);

        // Create options container
        const optionsContainer = document.createElement("div");
        optionsContainer.style.cssText = `
          display: grid;
          gap: 16px;
          margin-bottom: 20px;
        `;

        // Create option buttons with theme support
        const createOptionButton = (id: string, icon: string, title: string, description: string): HTMLButtonElement => {
          const button = document.createElement("button");
          button.id = id;
          button.style.cssText = `
            background: var(--bg-secondary, #292d36);
            border: 1px solid var(--border-color, #404040);
            border-radius: 8px;
            padding: 16px;
            color: var(--text-primary, #fff);
            cursor: pointer;
            text-align: left;
            transition: all 0.2s;
            width: 100%;
          `;

          button.innerHTML = `
            <div style="font-weight: 600; color: var(--accent-color, #00bfff); margin-bottom: 4px;">${icon} ${title}</div>
            <div style="color: var(--text-secondary, #aaa); font-size: 0.9rem;">${description}</div>
          `;

          // Add hover effects
          button.addEventListener("mouseenter", () => {
            button.style.background = "var(--bg-primary, #2d323e)";
            button.style.borderColor = "var(--accent-color, #007acc)";
            button.style.transform = "translateY(-2px)";
          });

          button.addEventListener("mouseleave", () => {
            button.style.background = "var(--bg-secondary, #292d36)";
            button.style.borderColor = "var(--border-color, #404040)";
            button.style.transform = "translateY(0)";
          });

          return button;
        };

        // Create option buttons
        const urlOption = createOptionButton(
          "url-option",
          "🔗",
          "URL Injection",
          "Load a JavaScript file from a URL"
        );
        const jsOption = createOptionButton(
          "js-option",
          "📝",
          "JavaScript Code",
          "Input custom JavaScript code to execute"
        );
        const ocotOption = createOptionButton(
          "ocot-option",
          "🔧",
          "Inject Ocot Client",
          "Load the latest Ocot Client from CDN"
        );

        optionsContainer.appendChild(urlOption);
        optionsContainer.appendChild(jsOption);
        optionsContainer.appendChild(ocotOption);
        modalContent.appendChild(optionsContainer);

        // Create cancel button
        const buttonContainer = document.createElement("div");
        buttonContainer.style.cssText = `
          display: flex;
          justify-content: flex-end;
          gap: 12px;
        `;

        const cancelButton = document.createElement("button");
        cancelButton.textContent = "Cancel";
        cancelButton.style.cssText = `
          padding: 10px 20px;
          background: #6c757d;
          border: none;
          border-radius: 6px;
          color: var(--text-primary, white);
          cursor: pointer;
          font-size: 0.9rem;
          font-weight: 500;
          transition: background-color 0.2s;
        `;

        cancelButton.addEventListener("mouseenter", () => {
          cancelButton.style.backgroundColor = "#545b62";
        });

        cancelButton.addEventListener("mouseleave", () => {
          cancelButton.style.backgroundColor = "#6c757d";
        });

        buttonContainer.appendChild(cancelButton);
        modalContent.appendChild(buttonContainer);

        // Event handlers
        const closeModal = (method: string | null = null) => {
          removeModal(modal);
          resolve(method);
        };

        urlOption.addEventListener("click", () => closeModal("url"));
        jsOption.addEventListener("click", () => closeModal("js"));
        ocotOption.addEventListener("click", () => closeModal("ocot"));
        cancelButton.addEventListener("click", () => closeModal(null));

        if ((modalContent as any)._closeButton) {
          (modalContent as any)._closeButton.addEventListener("click", () =>
            closeModal(null)
          );
        }

        // Close on Escape key
        const handleKeyDown = (e: KeyboardEvent) => {
          if (e.key === "Escape") {
            document.removeEventListener("keydown", handleKeyDown);
            closeModal(null);
          }
        };
        document.addEventListener("keydown", handleKeyDown);

        // Close on overlay click
        modal.addEventListener("click", (e: MouseEvent) => {
          if (e.target === modal) {
            closeModal(null);
          }
        });
      });
    };

    // Function to show code editor modal with theme support
    const showCodeEditorModal = (executeCallback: (jsCode: string, isUrl: boolean) => void): void => {
      const { modal, modalContent } = createBaseModal(
        "JavaScript Code Editor",
        "input"
      );

      // Create description
      const descriptionDiv = document.createElement("div");
      descriptionDiv.style.cssText = `
        color: var(--text-secondary, #d4d4d4);
        line-height: 1.5;
        margin-bottom: 16px;
        font-size: 0.95rem;
      `;
      descriptionDiv.textContent =
        "Write your JavaScript code below. It will be executed in a new about:blank page.";
      modalContent.appendChild(descriptionDiv);

      // Create textarea container
      const textareaContainer = document.createElement("div");
      textareaContainer.style.marginBottom = "20px";

      const codeTextarea = document.createElement("textarea");
      codeTextarea.placeholder = `// Write your JavaScript code here...
console.log('Hello from about:blank!');
alert('Code executed successfully!');

// Examples:
// - DOM manipulation
// - API calls  
// - Custom functions
// - Variable declarations`;
      codeTextarea.style.cssText = `
        width: 100%;
        height: 300px;
        padding: 16px;
        background: var(--bg-primary, #1e1e1e);
        border: 1px solid var(--border-color, #404040);
        border-radius: 6px;
        color: var(--text-primary, #d4d4d4);
        font-size: 14px;
        font-family: 'Consolas', 'Courier New', 'Monaco', monospace;
        resize: vertical;
        outline: none;
        line-height: 1.5;
        tab-size: 2;
        box-sizing: border-box;
      `;

      // Handle textarea styling for better code editing
      codeTextarea.addEventListener("focus", () => {
        codeTextarea.style.borderColor = "var(--accent-color, #007acc)";
        codeTextarea.style.boxShadow = "0 0 0 2px rgba(0, 122, 204, 0.3)";
      });

      codeTextarea.addEventListener("blur", () => {
        codeTextarea.style.borderColor = "var(--border-color, #404040)";
        codeTextarea.style.boxShadow = "none";
      });

      // Handle Tab key for proper indentation
      codeTextarea.addEventListener("keydown", (e: KeyboardEvent) => {
        if (e.key === "Tab") {
          e.preventDefault();
          const start = codeTextarea.selectionStart;
          const end = codeTextarea.selectionEnd;

          // Insert tab character
          codeTextarea.value =
            codeTextarea.value.substring(0, start) +
            "  " +
            codeTextarea.value.substring(end);
          codeTextarea.selectionStart = codeTextarea.selectionEnd = start + 2;
        }
      });

      // Handle Ctrl+Enter to execute
      codeTextarea.addEventListener("keydown", (e: KeyboardEvent) => {
        if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
          e.preventDefault();
          executeBtn.click();
        }
      });

      textareaContainer.appendChild(codeTextarea);
      modalContent.appendChild(textareaContainer);

      // Create button container
      const buttonContainer = document.createElement("div");
      buttonContainer.style.cssText = `
        display: flex;
        justify-content: flex-end;
        gap: 12px;
      `;

      // Create cancel button
      const cancelButton = document.createElement("button");
      cancelButton.textContent = "Cancel";
      cancelButton.style.cssText = `
        padding: 12px 24px;
        background: #6c757d;
        border: none;
        border-radius: 6px;
        color: var(--text-primary, white);
        cursor: pointer;
        font-size: 1rem;
        font-weight: 500;
        transition: background-color 0.2s;
      `;

      cancelButton.addEventListener("mouseenter", () => {
        cancelButton.style.backgroundColor = "#545b62";
      });

      cancelButton.addEventListener("mouseleave", () => {
        cancelButton.style.backgroundColor = "#6c757d";
      });

      // Create execute button
      const executeBtn = document.createElement("button");
      executeBtn.textContent = "Execute";
      executeBtn.style.cssText = `
        padding: 12px 24px;
        background: var(--accent-color, #007acc);
        border: none;
        border-radius: 6px;
        color: var(--text-primary, white);
        cursor: pointer;
        font-size: 1rem;
        font-weight: 500;
        transition: background-color 0.2s;
      `;

      executeBtn.addEventListener("mouseenter", () => {
        executeBtn.style.backgroundColor = "var(--accent-color-hover, #005a9e)";
      });

      executeBtn.addEventListener("mouseleave", () => {
        executeBtn.style.backgroundColor = "var(--accent-color, #007acc)";
      });

      buttonContainer.appendChild(cancelButton);
      buttonContainer.appendChild(executeBtn);
      modalContent.appendChild(buttonContainer);

      // Focus on the textarea after modal is shown
      setTimeout(() => codeTextarea.focus(), 100);

      // Event handlers
      const closeModal = () => {
        removeModal(modal);
      };

      cancelButton.addEventListener("click", closeModal);

      if ((modalContent as any)._closeButton) {
        (modalContent as any)._closeButton.addEventListener("click", closeModal);
      }

      executeBtn.addEventListener("click", () => {
        const jsCode = codeTextarea.value.trim();
        if (!jsCode) {
          showModal(
            "Please enter some JavaScript code to execute.",
            "Missing Code",
            "warning"
          );
          return;
        }

        // Execute the code using the callback
        executeCallback(jsCode, false);
        closeModal();
      });

      // Close on Escape key
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === "Escape") {
          document.removeEventListener("keydown", handleKeyDown);
          closeModal();
        }
      };
      document.addEventListener("keydown", handleKeyDown);

      // Close on overlay click
      modal.addEventListener("click", (e: MouseEvent) => {
        if (e.target === modal) {
          closeModal();
        }
      });
    };

    // Helper function to create about:blank window and inject script with robust error handling
    const createAboutBlankWithScript = (scriptContent: string, isUrl: boolean = false): void => {
      const newWindow = window.open("about:blank", "_blank");
      if (!newWindow) {
        showModal(
          "Failed to open new window. Please check your browser's popup settings.",
          "Popup Blocked",
          "error"
        );
        return;
      }

      // Immediately set up the window styling and structure (synchronous to prevent race conditions)
      const initializeWindow = (): void => {
        try {
          // Force document to be in a known state
          newWindow.document.open();
          newWindow.document.write(
            "<!DOCTYPE html><html><head></head><body></body></html>"
          );
          newWindow.document.close();

          // Add comprehensive styling to the page immediately
          const style = newWindow.document.createElement("style");
          style.textContent = `
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              background: #1a1a1a;
              color: #fff;
              margin: 0;
              padding: 20px;
              line-height: 1.6;
            }
            .status-container {
              background: #292d36;
              border-radius: 8px;
              padding: 16px;
              margin-bottom: 20px;
              border-left: 4px solid #00bfff;
            }
            .status-title {
              font-weight: 600;
              color: #00bfff;
              margin-bottom: 8px;
            }
            .status-message {
              color: #aaa;
              font-size: 0.9rem;
            }
            .success { border-left-color: #28a745; }
            .success .status-title { color: #28a745; }
            .error { border-left-color: #dc3545; }
            .error .status-title { color: #dc3545; }
            .warning { border-left-color: #ffc107; }
            .warning .status-title { color: #ffc107; }
            .code-block {
              background: #1e2126;
              border-radius: 4px;
              padding: 12px;
              margin: 8px 0;
              font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
              font-size: 0.85rem;
              border: 1px solid #404040;
              overflow-x: auto;
            }
            .timestamp {
              color: #666;
              font-size: 0.8rem;
            }
          `;
          newWindow.document.head.appendChild(style);

          // Create status container immediately and ensure it's persistent
          const statusContainer = newWindow.document.createElement("div");
          statusContainer.innerHTML = `
            <div class="status-container" id="injection-status">
              <div class="status-title">🔄 Script Injection Status</div>
              <div class="status-message">Initializing script injection...</div>
            </div>
          `;
          newWindow.document.body.appendChild(statusContainer);

          const updateStatus = (title: string, message: string, type: string = "info"): void => {
            const status =
              newWindow.document.getElementById("injection-status");
            if (status) {
              status.className = `status-container ${type}`;
              status.innerHTML = `
                <div class="status-title">${title}</div>
                <div class="status-message">${message}</div>
                <div class="timestamp">Last updated: ${new Date().toLocaleTimeString()}</div>
              `;
            }
          };

          // Script injection with comprehensive error handling
          const injectScript = (): void => {
            try {
              const script = newWindow.document.createElement("script");

              if (isUrl) {
                // Handle external script URL
                updateStatus(
                  "🔗 Loading External Script",
                  `Fetching: ${scriptContent}`
                );

                script.src = scriptContent;

                // Set up timeout for script loading
                const timeoutId = setTimeout(() => {
                  updateStatus(
                    "⏰ Script Load Timeout",
                    `Script failed to load within 10 seconds. This may be due to network issues or CORS restrictions.<br><br>
                    <strong>Troubleshooting:</strong><br>
                    • Check if the URL is accessible<br>
                    • Verify CORS headers allow cross-origin requests<br>
                    • Try a different script URL<br><br>
                    <div class="code-block">URL: ${scriptContent}</div>`,
                    "warning"
                  );
                }, 10000);

                // Success handler
                script.onload = () => {
                  clearTimeout(timeoutId);
                  updateStatus(
                    "✅ Script Loaded Successfully",
                    `External script has been loaded and executed successfully.<br><br>
                    <div class="code-block">URL: ${scriptContent}</div>
                    <br>Check the browser console for any script output.`,
                    "success"
                  );
                };

                // Error handler
                script.onerror = (event: Event | string) => {
                  clearTimeout(timeoutId);
                  updateStatus(
                    "❌ Script Load Failed",
                    `Failed to load external script. This is likely due to:<br><br>
                    <strong>Common causes:</strong><br>
                    • CORS (Cross-Origin Resource Sharing) restrictions<br>
                    • Network connectivity issues<br>
                    • Invalid or inaccessible URL<br>
                    • Server-side blocking of cross-origin requests<br><br>
                    <div class="code-block">URL: ${scriptContent}</div>
                    <br><strong>Suggestion:</strong> Try copying the script content and using 'Direct JavaScript Code' option instead.`,
                    "error"
                  );
                };
              } else {
                // Handle inline JavaScript code
                updateStatus(
                  "📝 Executing Inline Script",
                  "Processing JavaScript code..."
                );

                try {
                  // Validate and execute inline script
                  script.textContent = scriptContent;

                  // Add error handling wrapper for inline scripts
                  const wrappedScript =
                    newWindow.document.createElement("script");
                  wrappedScript.textContent = `
                    try {
                      ${scriptContent}
                      console.log('✅ Inline script executed successfully');
                    } catch (error) {
                      console.error('❌ Script execution error:', error);
                      const statusEl = document.getElementById('injection-status');
                      if (statusEl) {
                        statusEl.className = 'status-container error';
                        statusEl.innerHTML = \`
                          <div class="status-title">❌ Script Execution Error</div>
                          <div class="status-message">
                            JavaScript execution failed:<br><br>
                            <div class="code-block">\${error.name}: \${error.message}</div>
                            <br>Please check your JavaScript syntax and try again.
                          </div>
                          <div class="timestamp">Last updated: \${new Date().toLocaleTimeString()}</div>
                        \`;
                      }
                    }
                  `;

                  newWindow.document.head.appendChild(wrappedScript);

                  updateStatus(
                    "✅ Script Executed Successfully",
                    `Inline JavaScript code has been executed.<br><br>
                    <div class="code-block">${scriptContent.length > 200
                      ? scriptContent.substring(0, 200) + "..."
                      : scriptContent
                    }</div>
                    <br>Check the browser console for any script output.`,
                    "success"
                  );
                } catch (error: any) {
                  updateStatus(
                    "❌ Script Preparation Failed",
                    `Failed to prepare script for execution:<br><br>
                    <div class="code-block">${error?.name || 'Error'}: ${error?.message || 'Unknown error'}</div>
                    <br>Please check your JavaScript syntax.`,
                    "error"
                  );
                }
              }

              // Append script to head for URL-based scripts
              if (isUrl) {
                newWindow.document.head.appendChild(script);
              }
            } catch (error: any) {
              updateStatus(
                "❌ Injection Failed",
                `Critical error during script injection:<br><br>
                <div class="code-block">${error?.name || 'Error'}: ${error?.message || 'Unknown error'}</div>
                <br>This may indicate a browser security restriction or internal error.`,
                "error"
              );
            }
          };

          // Start script injection with longer delay to ensure window is fully initialized
          setTimeout(injectScript, 200); // Increased delay to prevent race conditions
        } catch (error: any) {
          // Fallback error handling if window initialization fails
          newWindow.document.body.innerHTML = `
            <div style="font-family: Arial, sans-serif; padding: 20px; background: #1a1a1a; color: #fff;">
              <h2 style="color: #dc3545;">❌ Initialization Failed</h2>
              <p>Failed to initialize the injection environment:</p>
              <pre style="background: #2d2d2d; padding: 10px; border-radius: 4px;">${error?.message || 'Unknown error'}</pre>
            </div>
          `;
        }
      };

      // Initialize window immediately and robustly
      const ensureWindowReady = (): void => {
        if (newWindow.document && newWindow.document.body !== null) {
          initializeWindow();
        } else {
          // Window not ready yet, try again soon
          setTimeout(ensureWindowReady, 10);
        }
      };

      // Start initialization process
      setTimeout(ensureWindowReady, 25);
    };

    // Get injection method choice
    const method = await showInjectionMethodModal();
    if (!method) return;

    // Handle different injection methods
    if (method === "url") {
      const url = await showInputModal(
        "Enter the JavaScript URL to inject:",
        "https://example.com/script.js",
        "URL Injection",
        "url"
      );
      if (url) {
        createAboutBlankWithScript(url, true);
      }
    } else if (method === "js") {
      // Show the code editor modal
      showCodeEditorModal(createAboutBlankWithScript);
    } else if (method === "ocot") {
      // Enhanced Ocot Client injection with fallback URLs and retry logic
      const injectOcotWithFallback = async (): Promise<void> => {
        // Get the latest version info
        const versionInfo = await getLatestVersionInfo();
        const latestVersion = versionInfo?.cleanLatestVersion || versionInfo?.cleanCurrentVersion || "2.4.7";

        // Multiple CDN sources for better reliability using actual latest version
        const ocotUrls = [
          `https://cdn.jsdelivr.net/gh/asc2563/ocot-client@${latestVersion}/dist/bundle.js`,
          "https://cdn.jsdelivr.net/gh/asc2563/ocot-client@latest/dist/bundle.js",
          "https://raw.githubusercontent.com/asc2563/ocot-client/main/dist/bundle.js",
        ];

        const newWindow = window.open("about:blank", "_blank");
        if (!newWindow) {
          showModal(
            "Failed to open new window. Please check your browser's popup settings.",
            "Popup Blocked",
            "error"
          );
          return;
        }

        // Initialize the window first with enhanced protection
        const initializeWindow = (): void => {
          try {
            // Force document to be in a known state
            newWindow.document.open();
            newWindow.document.write(
              "<!DOCTYPE html><html><head></head><body></body></html>"
            );
            newWindow.document.close();

            // Add comprehensive styling to the page immediately
            const style = newWindow.document.createElement("style");
            style.textContent = `
              body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: #1a1a1a;
                color: #fff;
                margin: 0;
                padding: 20px;
                line-height: 1.6;
              }
              .status-container {
                background: #292d36;
                border-radius: 8px;
                padding: 16px;
                margin-bottom: 20px;
                border-left: 4px solid #00bfff;
              }
              .status-title {
                font-weight: 600;
                color: #00bfff;
                margin-bottom: 8px;
              }
              .status-message {
                color: #aaa;
                font-size: 0.9rem;
              }
              .success { border-left-color: #28a745; }
              .success .status-title { color: #28a745; }
              .error { border-left-color: #dc3545; }
              .error .status-title { color: #dc3545; }
              .warning { border-left-color: #ffc107; }
              .warning .status-title { color: #ffc107; }
              .code-block {
                background: #1e2126;
                border-radius: 4px;
                padding: 12px;
                margin: 8px 0;
                font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
                font-size: 0.85rem;
                border: 1px solid #404040;
                overflow-x: auto;
              }
              .timestamp {
                color: #666;
                font-size: 0.8rem;
              }
            `;
            newWindow.document.head.appendChild(style);

            // Create status container immediately and ensure it's persistent
            const statusContainer = newWindow.document.createElement("div");
            statusContainer.innerHTML = `
              <div class="status-container" id="injection-status">
                <div class="status-title">🔄 Loading Ocot Client</div>
                <div class="status-message">Initializing Ocot Client injection with enhanced reliability...</div>
              </div>
            `;
            newWindow.document.body.appendChild(statusContainer);

            const updateStatus = (title: string, message: string, type: string = "info"): void => {
              const status =
                newWindow.document.getElementById("injection-status");
              if (status) {
                status.className = `status-container ${type}`;
                status.innerHTML = `
                  <div class="status-title">${title}</div>
                  <div class="status-message">${message}</div>
                  <div class="timestamp">Last updated: ${new Date().toLocaleTimeString()}</div>
                `;
              }
            };

            // Enhanced script loading with retries and fallbacks
            const loadScriptWithRetry = async (
              urls: string[],
              currentIndex: number = 0,
              attempt: number = 1
            ): Promise<void> => {
              if (currentIndex >= urls.length) {
                updateStatus(
                  "❌ All Sources Failed",
                  "Failed to load Ocot Client from all available CDN sources. This may be due to network issues or temporary CDN unavailability.",
                  "error"
                );
                return;
              }

              const currentUrl = urls[currentIndex];
              updateStatus(
                "🔗 Loading from CDN",
                `Attempting to load from source ${currentIndex + 1}/${urls.length
                } (Attempt ${attempt})<br><br><div class="code-block">${currentUrl}</div>`
              );

              return new Promise<void>((resolve, reject) => {
                const script = newWindow.document.createElement("script");
                script.src = currentUrl;

                // Set up timeout (shorter for faster fallback)
                const timeoutId = setTimeout(() => {
                  script.onload = null;
                  script.onerror = null;

                  if (attempt < 2) {
                    // Retry same URL once
                    updateStatus(
                      "⏳ Retrying...",
                      `Timeout occurred, retrying same source (Attempt ${attempt + 1
                      }/2)...`
                    );
                    setTimeout(() => {
                      loadScriptWithRetry(urls, currentIndex, attempt + 1);
                    }, 1000);
                  } else {
                    // Try next URL
                    updateStatus(
                      "⚠️ Source Timeout",
                      `Source ${currentIndex + 1
                      } timed out after 2 attempts, trying next source...`,
                      "warning"
                    );
                    setTimeout(() => {
                      loadScriptWithRetry(urls, currentIndex + 1, 1);
                    }, 500);
                  }
                  reject(new Error("Timeout"));
                }, 7000);

                // Success handler
                script.onload = () => {
                  clearTimeout(timeoutId);
                  updateStatus(
                    "✅ Ocot Client Loaded Successfully",
                    `Ocot Client has been successfully loaded and is now available on this page!<br><br>
                    <div class="code-block">Source: ${currentUrl}</div>
                    <br>You can now use all Ocot Client features. Look for the Ocot interface or check the console for available commands.`,
                    "success"
                  );
                  resolve();
                };

                // Error handler
                script.onerror = (event: Event | string) => {
                  clearTimeout(timeoutId);

                  if (attempt < 2) {
                    // Retry same URL once
                    updateStatus(
                      "🔄 Retrying...",
                      `Load error occurred, retrying same source (Attempt ${attempt + 1
                      }/2)...`
                    );
                    setTimeout(() => {
                      loadScriptWithRetry(urls, currentIndex, attempt + 1);
                    }, 1000);
                  } else {
                    // Try next URL
                    updateStatus(
                      "⚠️ Source Failed",
                      `Source ${currentIndex + 1
                      } failed after 2 attempts, trying next source...`,
                      "warning"
                    );
                    setTimeout(() => {
                      loadScriptWithRetry(urls, currentIndex + 1, 1);
                    }, 500);
                  }
                  reject(new Error("Load error"));
                };

                // Append script to head to start loading
                newWindow.document.head.appendChild(script);
              }).catch(() => {
                // Error already handled in timeout/error handlers
              });
            };

            // Start the enhanced loading process
            loadScriptWithRetry(ocotUrls);
          } catch (error: any) {
            // Fallback error handling if window initialization fails
            newWindow.document.body.innerHTML = `
              <div style="font-family: Arial, sans-serif; padding: 20px; background: #1a1a1a; color: #fff;">
                <h2 style="color: #dc3545;">❌ Initialization Failed</h2>
                <p>Failed to initialize the Ocot Client injection environment:</p>
                <pre style="background: #2d2d2d; padding: 10px; border-radius: 4px;">${error.message}</pre>
              </div>
            `;
          }
        };

        // Initialize window immediately and robustly
        const ensureWindowReady = (): void => {
          if (newWindow.document && newWindow.document.body !== null) {
            initializeWindow();
          } else {
            // Window not ready yet, try again soon
            setTimeout(ensureWindowReady, 10);
          }
        };

        // Start initialization process
        setTimeout(ensureWindowReady, 25);
      };

      // Execute the enhanced injection
      injectOcotWithFallback();
    }
  },
} as Handler;
