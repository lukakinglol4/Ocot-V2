import { showModal } from "../utils/modalHelpers.js";
import type { Handler } from "../types/global.d.ts";

const antiforcereloadHandler: Handler = {
  isEnabled(): boolean {
    return window.antiForceReloadEnabled || false;
  },

  async onEnable(): Promise<void> {
    window.antiForceReloadBeforeUnloadHandler = (e: BeforeUnloadEvent): string => {
      return "no";
    };
    window.onbeforeunload = window.antiForceReloadBeforeUnloadHandler;
    window.antiForceReloadEnabled = true;

    await showModal(
      "Page reload protection is now ACTIVE. The browser will warn before allowing page refreshes or navigation away from this page.<br><br>Use this script again to disable protection.",
      "Anti Force Reload Enabled",
      "success"
    );
  },

  async onDisable(): Promise<void> {
    window.onbeforeunload = null;
    window.antiForceReloadBeforeUnloadHandler = undefined;
    window.antiForceReloadEnabled = false;

    await showModal(
      "Page reload protection is now OFF. The page can be refreshed normally.",
      "Anti Force Reload Disabled",
      "success"
    );
  },

  async onActivate(): Promise<void> {
    if (antiforcereloadHandler.isEnabled?.()) {
      await antiforcereloadHandler.onDisable?.();
    } else {
      await antiforcereloadHandler.onEnable?.();
    }
  },
};

export default antiforcereloadHandler;
