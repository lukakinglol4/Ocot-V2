import {
  showModal,
  showInputModal,
  showConfirmModal,
  createBaseModal,
  removeModal,
} from "../utils/modalHelpers.js";
import type { Handler } from "../types/global.d.ts";

const storagemanagerHandler: Handler = {
  async onActivate(): Promise<void> {
    // Function to get storage data
    const getStorageData = () => {
      const localStorageData: any[] = [];
      const sessionStorageData: any[] = [];

      // Get localStorage data
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key) {
          const value = localStorage.getItem(key);
          if (value) {
            localStorageData.push({ key, value, size: new Blob([value]).size });
          }
        }
      }

      // Get sessionStorage data
      for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i);
        if (key) {
          const value = sessionStorage.getItem(key);
          if (value) {
            sessionStorageData.push({
              key,
              value,
              size: new Blob([value]).size,
            });
          }
        }
      }

      return { localStorageData, sessionStorageData };
    };

    // Function to format file size
    const formatSize = (bytes: number): string => {
      if (bytes === 0) return "0 B";
      const k = 1024;
      const sizes = ["B", "KB", "MB", "GB"];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
    };

    // Create main storage modal
    const modal = document.createElement("div");
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.7);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 100001;
    `;

    const { localStorageData, sessionStorageData } = getStorageData();
    const totalLocalSize = localStorageData.reduce(
      (sum, item) => sum + item.size,
      0
    );
    const totalSessionSize = sessionStorageData.reduce(
      (sum, item) => sum + item.size,
      0
    );

    modal.innerHTML = `
      <div style="background: var(--bg-primary, #23272f); padding: 24px; border-radius: 10px; width: 90%; max-width: 800px; max-height: 80vh; box-shadow: 0 4px 20px rgba(0,0,0,0.3); overflow-y: auto; border: 1px solid var(--border-color, #404040);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
          <h2 style="color: var(--accent-color, #00bfff); margin: 0; font-size: 1.5rem;">🗄️ Storage Manager</h2>
          <button id="close-modal" style="background: none; border: none; color: var(--text-secondary, #aaa); font-size: 24px; cursor: pointer; padding: 0; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center;">&times;</button>
        </div>
        
        <!-- Storage Overview -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px;">
          <div style="background: var(--bg-secondary, #292d36); border-radius: 8px; padding: 16px; border: 1px solid var(--border-color, #404040);">
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
              <span style="font-size: 1.2rem;">💾</span>
              <h3 style="color: var(--accent-color, #00bfff); margin: 0; font-size: 1.1rem;">Local Storage</h3>
            </div>
            <p style="color: var(--text-secondary, #aaa); margin: 4px 0; font-size: 0.9rem;">Items: ${localStorageData.length
      }</p>
            <p style="color: var(--text-secondary, #aaa); margin: 4px 0; font-size: 0.9rem;">Total Size: ${formatSize(
        totalLocalSize
      )}</p>
          </div>
          
          <div style="background: var(--bg-secondary, #292d36); border-radius: 8px; padding: 16px; border: 1px solid var(--border-color, #404040);">
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
              <span style="font-size: 1.2rem;">⏰</span>
              <h3 style="color: var(--accent-color, #00bfff); margin: 0; font-size: 1.1rem;">Session Storage</h3>
            </div>
            <p style="color: var(--text-secondary, #aaa); margin: 4px 0; font-size: 0.9rem;">Items: ${sessionStorageData.length
      }</p>
            <p style="color: var(--text-secondary, #aaa); margin: 4px 0; font-size: 0.9rem;">Total Size: ${formatSize(
        totalSessionSize
      )}</p>
          </div>
        </div>

        <!-- Action Buttons -->
        <div style="display: grid; gap: 12px; margin-bottom: 24px;">
          <button id="clear-selected-btn" style="background: var(--accent-color, #007acc); border: none; border-radius: 8px; padding: 16px; color: var(--text-primary, white); cursor: pointer; font-size: 1rem; font-weight: 600; transition: all 0.2s;">
            🎯 Clear Selected Data
          </button>
          
          <button id="clear-all-btn" style="background: #dc3545; border: none; border-radius: 8px; padding: 16px; color: var(--text-primary, white); cursor: pointer; font-size: 1rem; font-weight: 600; transition: all 0.2s;">
            🗑️ Clear All Data
          </button>
        </div>

        <!-- Storage Details -->
        <div style="border-top: 1px solid var(--border-color, #404040); padding-top: 20px;">
          <h4 style="color: var(--accent-color, #00bfff); margin-bottom: 16px;">📋 Storage Details</h4>
          
          ${localStorageData.length > 0
        ? `
            <div style="margin-bottom: 20px;">
              <h5 style="color: var(--text-primary, #fff); margin-bottom: 12px;">💾 Local Storage (${localStorageData.length
        } items)</h5>
              <div style="max-height: 200px; overflow-y: auto; background: var(--bg-secondary, #1e2126); border-radius: 6px; padding: 12px; border: 1px solid var(--border-color, #404040);">
                ${localStorageData
          .map(
            (item) => `
                  <div style="padding: 8px 0; border-bottom: 1px solid var(--border-color, #404040);">
                    <div style="color: var(--accent-color, #00bfff); font-weight: 600; font-size: 0.9rem; margin-bottom: 2px;">${item.key
              }</div>
                    <div style="color: var(--text-secondary, #aaa); font-size: 0.8rem; font-family: monospace; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${item.value.length > 100
                ? item.value.substring(0, 100) + "..."
                : item.value
              }</div>
                    <div style="color: var(--text-secondary, #666); font-size: 0.7rem;">${formatSize(
                item.size
              )}</div>
                  </div>
                `
          )
          .join("")}
              </div>
            </div>
          `
        : '<p style="color: var(--text-secondary, #666); font-style: italic;">Local Storage is empty</p>'
      }

          ${sessionStorageData.length > 0
        ? `
            <div style="margin-bottom: 20px;">
              <h5 style="color: var(--text-primary, #fff); margin-bottom: 12px;">⏰ Session Storage (${sessionStorageData.length
        } items)</h5>
              <div style="max-height: 200px; overflow-y: auto; background: var(--bg-secondary, #1e2126); border-radius: 6px; padding: 12px; border: 1px solid var(--border-color, #404040);">
                ${sessionStorageData
          .map(
            (item) => `
                  <div style="padding: 8px 0; border-bottom: 1px solid var(--border-color, #404040);">
                    <div style="color: var(--accent-color, #00bfff); font-weight: 600; font-size: 0.9rem; margin-bottom: 2px;">${item.key
              }</div>
                    <div style="color: var(--text-secondary, #aaa); font-size: 0.8rem; font-family: monospace; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${item.value.length > 100
                ? item.value.substring(0, 100) + "..."
                : item.value
              }</div>
                    <div style="color: var(--text-secondary, #666); font-size: 0.7rem;">${formatSize(
                item.size
              )}</div>
                  </div>
                `
          )
          .join("")}
              </div>
            </div>
          `
        : '<p style="color: var(--text-secondary, #666); font-style: italic;">Session Storage is empty</p>'
      }
        </div>
      </div>
    `;

    // Add hover effects for buttons
    const buttons = modal.querySelectorAll('button[id$="-btn"]');
    buttons.forEach((button) => {
      const btnElement = button as HTMLButtonElement;
      btnElement.addEventListener("mouseenter", () => {
        btnElement.style.transform = "translateY(-2px)";
        btnElement.style.opacity = "0.9";
      });
      btnElement.addEventListener("mouseleave", () => {
        btnElement.style.transform = "translateY(0)";
        btnElement.style.opacity = "1";
      });
    });

    document.body.appendChild(modal);

    // Function to show selected data clearing modal
    const showSelectiveModal = () => {
      const selectiveModal = document.createElement("div");
      selectiveModal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 100002;
      `;

      selectiveModal.innerHTML = `
        <div style="background: var(--bg-primary, #23272f); padding: 24px; border-radius: 10px; width: 90%; max-width: 700px; max-height: 80vh; box-shadow: 0 4px 20px rgba(0,0,0,0.3); overflow-y: auto; border: 1px solid var(--border-color, #404040);">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2 style="color: var(--accent-color, #00bfff); margin: 0; font-size: 1.5rem;">🎯 Select Data to Clear</h2>
            <button id="close-selective-modal" style="background: none; border: none; color: var(--text-secondary, #aaa); font-size: 24px; cursor: pointer; padding: 0; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center;">&times;</button>
          </div>
          
          <p style="color: var(--text-secondary, #aaa); margin-bottom: 20px; line-height: 1.4;">
            Select the storage items you want to delete:
          </p>
          
          <div id="storage-items-container">
            ${localStorageData.length > 0
          ? `
              <div style="margin-bottom: 20px;">
                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
                  <input type="checkbox" id="select-all-local" style="margin: 0;">
                  <label for="select-all-local" style="color: var(--accent-color, #00bfff); font-weight: 600; cursor: pointer;">💾 Local Storage (Select All)</label>
                </div>
                <div style="background: var(--bg-secondary, #1e2126); border-radius: 6px; padding: 12px; margin-left: 20px; border: 1px solid var(--border-color, #404040);">
                  ${localStorageData
            .map(
              (item, index) => `
                    <div style="display: flex; align-items: center; gap: 8px; padding: 6px 0; border-bottom: 1px solid var(--border-color, #404040);">
                      <input type="checkbox" id="local-${index}" data-storage="local" data-key="${item.key
                }" style="margin: 0;">
                      <label for="local-${index}" style="flex: 1; cursor: pointer; color: var(--text-primary, #fff);">
                        <div style="font-weight: 600; font-size: 0.9rem;">${item.key
                }</div>
                        <div style="color: var(--text-secondary, #666); font-size: 0.7rem;">${formatSize(
                  item.size
                )}</div>
                      </label>
                    </div>
                  `
            )
            .join("")}
                </div>
              </div>
            `
          : ""
        }
            
            ${sessionStorageData.length > 0
          ? `
              <div style="margin-bottom: 20px;">
                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
                  <input type="checkbox" id="select-all-session" style="margin: 0;">
                  <label for="select-all-session" style="color: var(--accent-color, #00bfff); font-weight: 600; cursor: pointer;">⏰ Session Storage (Select All)</label>
                </div>
                <div style="background: var(--bg-secondary, #1e2126); border-radius: 6px; padding: 12px; margin-left: 20px; border: 1px solid var(--border-color, #404040);">
                  ${sessionStorageData
            .map(
              (item, index) => `
                    <div style="display: flex; align-items: center; gap: 8px; padding: 6px 0; border-bottom: 1px solid var(--border-color, #404040);">
                      <input type="checkbox" id="session-${index}" data-storage="session" data-key="${item.key
                }" style="margin: 0;">
                      <label for="session-${index}" style="flex: 1; cursor: pointer; color: var(--text-primary, #fff);">
                        <div style="font-weight: 600; font-size: 0.9rem;">${item.key
                }</div>
                        <div style="color: var(--text-secondary, #666); font-size: 0.7rem;">${formatSize(
                  item.size
                )}</div>
                      </label>
                    </div>
                  `
            )
            .join("")}
                </div>
              </div>
            `
          : ""
        }
          </div>
          
          <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 20px;">
            <button id="cancel-selective-btn" style="padding: 12px 24px; background: #6c757d; border: none; border-radius: 6px; color: var(--text-primary, white); cursor: pointer; font-size: 1rem;">Cancel</button>
            <button id="delete-selected-btn" style="padding: 12px 24px; background: #dc3545; border: none; border-radius: 6px; color: var(--text-primary, white); cursor: pointer; font-size: 1rem;">Delete Selected</button>
          </div>
        </div>
      `;

      document.body.appendChild(selectiveModal);

      // Handle select all checkboxes
      const selectAllLocal = selectiveModal.querySelector("#select-all-local");
      const selectAllSession = selectiveModal.querySelector(
        "#select-all-session"
      );

      if (selectAllLocal) {
        selectAllLocal.addEventListener("change", (e) => {
          const target = e.target as HTMLInputElement;
          const localCheckboxes = selectiveModal.querySelectorAll(
            'input[data-storage="local"]'
          );
          localCheckboxes.forEach(
            (checkbox) => ((checkbox as HTMLInputElement).checked = target.checked)
          );
        });
      }

      if (selectAllSession) {
        selectAllSession.addEventListener("change", (e) => {
          const target = e.target as HTMLInputElement;
          const sessionCheckboxes = selectiveModal.querySelectorAll(
            'input[data-storage="session"]'
          );
          sessionCheckboxes.forEach(
            (checkbox) => ((checkbox as HTMLInputElement).checked = target.checked)
          );
        });
      }

      // Event listeners
      const closeBtnSelectiveModal = selectiveModal.querySelector("#close-selective-modal");
      if (closeBtnSelectiveModal) {
        closeBtnSelectiveModal.addEventListener("click", () => {
          document.body.removeChild(selectiveModal);
        });
      }

      const cancelBtn = selectiveModal.querySelector("#cancel-selective-btn");
      if (cancelBtn) {
        cancelBtn.addEventListener("click", () => {
          document.body.removeChild(selectiveModal);
        });
      }

      const deleteBtn = selectiveModal.querySelector("#delete-selected-btn");
      if (deleteBtn) {
        deleteBtn.addEventListener("click", () => {
          const selectedItems = selectiveModal.querySelectorAll(
            "input[data-storage][data-key]:checked"
          );

          if (selectedItems.length === 0) {
            showModal(
              "Please select at least one item to delete.",
              "No Items Selected",
              "warning"
            );
            return;
          }

          let deletedCount = 0;
          selectedItems.forEach((item) => {
            const storageType = item.getAttribute("data-storage");
            const key = item.getAttribute("data-key");

            try {
              if (storageType === "local" && key) {
                localStorage.removeItem(key);
                deletedCount++;
              } else if (storageType === "session" && key) {
                sessionStorage.removeItem(key);
                deletedCount++;
              }
            } catch (error: any) {
              console.warn(
                `Failed to delete ${storageType} item "${key}":`,
                error
              );
            }
          });

          document.body.removeChild(selectiveModal);
          document.body.removeChild(modal);

          showModal(
            `Successfully deleted ${deletedCount} selected storage items.${deletedCount < selectedItems.length
              ? `<br><br>⚠️ ${selectedItems.length - deletedCount
              } items could not be deleted due to errors.`
              : ""
            }`,
            "Selected Data Cleared",
            "success"
          );
        });
      }

      // Close modal when clicking outside
      selectiveModal.addEventListener("click", (e) => {
        if (e.target === selectiveModal) {
          document.body.removeChild(selectiveModal);
        }
      });
    };

    // Event listeners for main modal
    const closeBtn = modal.querySelector("#close-modal");
    if (closeBtn) {
      closeBtn.addEventListener("click", () => {
        document.body.removeChild(modal);
      });
    }

    const clearSelectedBtn = modal.querySelector("#clear-selected-btn");
    if (clearSelectedBtn) {
      clearSelectedBtn.addEventListener("click", () => {
        if (localStorageData.length === 0 && sessionStorageData.length === 0) {
          showModal(
            "There is no storage data to select from.",
            "No Data Available",
            "info"
          );
          return;
        }
        showSelectiveModal();
      });
    }

    const clearAllBtn = modal.querySelector("#clear-all-btn");
    if (clearAllBtn) {
      clearAllBtn.addEventListener("click", async () => {
        const totalItems = localStorageData.length + sessionStorageData.length;

        if (totalItems === 0) {
          await showModal(
            "There is no storage data to clear.",
            "No Data to Clear",
            "info"
          );
          return;
        }

        const confirmed = await showConfirmModal(
          `This will permanently delete all storage data:<br><br>• ${localStorageData.length
          } localStorage items<br>• ${sessionStorageData.length
          } sessionStorage items<br><br><strong>Total: ${totalItems} items (${formatSize(
            totalLocalSize + totalSessionSize
          )})</strong><br><br>This action cannot be undone. Are you sure?`,
          "Clear All Storage Data?",
          "Delete All",
          "Cancel"
        );

        if (confirmed) {
          try {
            localStorage.clear();
            sessionStorage.clear();

            document.body.removeChild(modal);

            await showModal(
              `Successfully cleared all storage data:<br>• ${totalItems} items deleted<br>• ${formatSize(
                totalLocalSize + totalSessionSize
              )} freed`,
              "All Data Cleared",
              "success"
            );
          } catch (error: any) {
            await showModal(
              `Error clearing storage data: ${error?.message || 'Unknown error'}<br><br>Some data may not have been deleted due to browser restrictions.`,
              "Clearing Failed",
              "error"
            );
          }
        }
      });
    }

    // Close modal when clicking outside
    modal.addEventListener("click", (e: MouseEvent) => {
      if (e.target === modal) {
        document.body.removeChild(modal);
      }
    });
  }
};

export default storagemanagerHandler;
