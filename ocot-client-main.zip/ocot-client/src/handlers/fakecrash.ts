import type { Handler } from "../types/global.d.ts";

export default {
  async onActivate(): Promise<void> {
    if (window.proxyFrame) {
      window.proxyFrame.style.display = "none";
    }
    setTimeout(() => {
      alert(
        "Uncaught TypeError: Failed to execute 'run' on 'ClientCore': Cannot read properties of undefined (reading 'execute')\n    at ClientCore.run (main.js:1:1234)\n    at <anonymous>:1:1"
      );
      window.close();
      setTimeout(() => {
        if (!window.closed) {
          window.location.href = "about:blank";
          setTimeout(() => {
            window.close();
            if (!window.closed) {
              console.log(
                "Unable to close the tab automatically. Please close it manually."
              );
            }
          }, 100);
        }
      }, 100);
    }, 50);
  },
} as Handler;
