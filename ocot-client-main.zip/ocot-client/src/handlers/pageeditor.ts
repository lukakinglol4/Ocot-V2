import { showModal } from "../utils/modalHelpers.js";
import type { Handler } from "../types/global.d.ts";

const pageeditorHandler: Handler = {
  isEnabled(): boolean {
    return (
      document.body.contentEditable === "true" || document.designMode === "on"
    );
  },

  async onEnable(): Promise<void> {
    document.body.contentEditable = "true";
    document.designMode = "on";
    await showModal(
      "Page is now editable. You can click anywhere and start editing text. Use this script again to disable editing or refresh the page to reset.",
      "Page Editor Enabled",
      "success"
    );
  },

  async onDisable(): Promise<void> {
    document.body.contentEditable = "false";
    document.designMode = "off";
    await showModal(
      "Page editing is now disabled. The page is back to normal mode.",
      "Page Editor Disabled",
      "info"
    );
  },

  async onActivate(): Promise<void> {
    if (pageeditorHandler.isEnabled?.()) {
      await pageeditorHandler.onDisable?.();
    } else {
      await pageeditorHandler.onEnable?.();
    }
  },
};

export default pageeditorHandler;
