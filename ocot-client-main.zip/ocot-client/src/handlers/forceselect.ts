import type { Handler } from "../types/global.d.ts";
import { showModal } from "../utils/modalHelpers.js";
import { getGeneralSettings } from "../views/settings.js";

export default {
  async onActivate(): Promise<void> {
    try {
      // Function to enable text selection on all elements
      function forceSelect(): number {
        let allElements = document.body.querySelectorAll("*");
        let processedCount = 0;

        allElements.forEach(function (element: Element) {
          const htmlElement = element as HTMLElement;
          // Fix the variable name typo and enable selection
          htmlElement.style.setProperty("user-select", "auto", "important");
          htmlElement.style.setProperty("-webkit-user-select", "auto", "important");
          htmlElement.style.setProperty("-moz-user-select", "auto", "important");
          htmlElement.style.setProperty("-ms-user-select", "auto", "important");

          // Also remove any drag prevention
          htmlElement.style.setProperty("-webkit-user-drag", "auto", "important");
          htmlElement.draggable = true;

          processedCount++;
        });

        return processedCount;
      }

      // Execute the force select function
      const elementsProcessed = forceSelect();

      // Show success notification
      await showModal(
        `Successfully enabled text selection on ${elementsProcessed} elements.<br><br>You should now be able to select and copy text on this page, even if it was previously disabled by the website.`,
        "Force Select Applied",
        "success"
      );
    } catch (error: any) {
      await showModal(
        `Error applying force select: ${error?.message || 'Unknown error'}<br><br>This may occur on some special pages or if there are browser security restrictions.`,
        "Force Select Failed",
        "error"
      );
    }
  },
} as Handler;
