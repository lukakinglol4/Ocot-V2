import { showModal } from "../utils/modalHelpers.js";
import { getGeneralSettings } from "../views/settings.js";
import type { Handler } from "../types/global.d.ts";

const autohideHandler: Handler = {
  isEnabled(): boolean {
    return window.autoHideEnabled || false;
  },

  async onEnable(): Promise<void> {
    // Enable auto-hide
    window.autoHideBlurHandler = () => {
      // Use setTimeout to allow DOM to update before checking activeElement
      setTimeout(() => {
        // Check if the blur was caused by focusing on an internal iframe
        const activeElement = document.activeElement;

        // Helper function to check if element is an internal iframe
        const isInternalIframe = (element: Element | null): boolean => {
          if (!element || element.tagName !== "IFRAME") {
            return false;
          }

          // Check if it's one of our internal iframes
          const internalIframeIds = [
            "ocot-proxy-iframe",
            "ocot-pocket-browser-iframe",
          ];
          return internalIframeIds.includes(element.id);
        };

        // Don't hide if focus moved to an internal iframe
        if (isInternalIframe(activeElement)) {
          return;
        }

        // Hide the proxy client when window loses focus (tab switch)
        if (window.proxyFrame && window.proxyFrame.style.display !== "none") {
          // Use the app's built-in hide method if available
          if (
            window.proxyClientApp &&
            typeof window.proxyClientApp.hideProxyClient === "function"
          ) {
            window.proxyClientApp.hideProxyClient();
          } else {
            // Fallback method
            window.proxyFrame.style.display = "none";
            const floatingButton = document.querySelector(
              '[title*="Show Ocot Client"]'
            );
            if (floatingButton) {
              (floatingButton as HTMLElement).style.display = "flex";
            }
          }

          // Show notification that auto-hide was triggered (if enabled in settings)
          const generalSettings = getGeneralSettings();
          if (generalSettings.enableScriptNotifications) {
            const notification = document.createElement("div");
            notification.style.cssText = `
              position: fixed;
              top: 20px;
              right: 20px;
              background: #28a745;
              color: white;
              padding: 12px 20px;
              border-radius: 8px;
              font-family: Arial, sans-serif;
              font-size: 14px;
              z-index: 999999;
              box-shadow: 0 4px 12px rgba(0,0,0,0.3);
              animation: slideIn 0.3s ease-out;
            `;
            notification.innerHTML = "🔒 Ocot Client Auto-Hidden";

            // Add animation for right side
            const style = document.createElement("style");
            style.id = "auto-hide-notification-style";
            style.textContent = `
              @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
              }
            `;

            // Only add style if it doesn't exist
            if (!document.getElementById("auto-hide-notification-style")) {
              document.head.appendChild(style);
            }

            document.body.appendChild(notification);

            // Remove notification after 3 seconds
            setTimeout(() => {
              if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
              }
            }, 3000);
          }
        }
      }, 0);
    };

    // Add event listeners
    window.addEventListener("blur", window.autoHideBlurHandler);
    window.autoHideEnabled = true;

    await showModal(
      "The Ocot Client is now set to automatically hide when you:<br>• Switch to another tab<br>• Click outside the application<br><br><strong>NOTE:</strong> It will NOT hide immediately when you close this modal - only when you switch tabs or click away from the app.<br><br>Use this script again to disable auto-hide.",
      "Auto-hide Enabled",
      "success"
    );
  },

  async onDisable(): Promise<void> {
    // Disable auto-hide
    if (window.autoHideBlurHandler) {
      window.removeEventListener("blur", window.autoHideBlurHandler);
    }
    window.autoHideEnabled = false;

    await showModal(
      "The Ocot Client will no longer automatically hide when you switch tabs or click away.<br><br>You can manually hide it using the Hide App button or the backslash (\\) key.",
      "Auto-hide Disabled",
      "success"
    );
  },

  async onActivate(): Promise<void> {
    if (autohideHandler.isEnabled?.()) {
      await autohideHandler.onDisable?.();
    } else {
      await autohideHandler.onEnable?.();
    }
  },
};

export default autohideHandler;
