import { showModal } from "../utils/modalHelpers.js";
import type { Handler } from "../types/global.d.ts";

export default {
  async onActivate(): Promise<void> {
    const mathToolsUrl =
      "https://cdn.jsdelivr.net/gh/Penguinify/math-bookmarklet/dist/bundle.js";

    // Show loading feedback and store the promise
    const loadingModalPromise = showModal(
      "Fetching advanced math calculator from CDN. Please wait...",
      "Loading Math Tools",
      "info"
    );

    try {
      // Fetch the script from CDN
      const response = await fetch(mathToolsUrl);

      // Check if fetch was successful
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      // Get script content
      const scriptContent = await response.text();

      // Validate that we got actual script content
      if (!scriptContent || scriptContent.trim().length === 0) {
        throw new Error("Empty script content received");
      }

      // Create and inject script element
      const script = document.createElement("script");
      script.textContent = scriptContent;

      // Add error handling for script execution
      script.onerror = (event: Event | string) => {
        showModal(
          "❌ Math Tools Execution Error\n\nThe math tools script failed to execute properly. This may be due to:\n• JavaScript syntax errors in the fetched script\n• Compatibility issues with the current page\n• Security restrictions",
          "Execution Error",
          "error"
        );
      };

      // Inject the script
      document.head.appendChild(script);

      // Close any existing modals by finding and removing them
      const existingModals = document.querySelectorAll(".ocot-modal-overlay");
      existingModals.forEach((modal: Element) => {
        const modalElement = modal as HTMLElement;
        if (modalElement.parentNode) {
          modalElement.style.opacity = "0";
          setTimeout(() => {
            if (modalElement.parentNode) {
              modalElement.parentNode.removeChild(modalElement);
            }
          }, 200);
        }
      });

      // Small delay to ensure loading modal is closed before showing success
      setTimeout(async () => {
        // Success feedback
        await showModal(
          "🧮 Advanced math calculator and tools are now available on this page.<br><br>Look for new math-related UI elements or check the browser console for instructions on how to use the tools.",
          "Math Tools Loaded Successfully",
          "success"
        );
      }, 250);
    } catch (error: any) {
      // Close any existing modals (including the loading modal)
      const existingModals = document.querySelectorAll(".ocot-modal-overlay");
      existingModals.forEach((modal: Element) => {
        const modalElement = modal as HTMLElement;
        if (modalElement.parentNode) {
          modalElement.style.opacity = "0";
          setTimeout(() => {
            if (modalElement.parentNode) {
              modalElement.parentNode.removeChild(modalElement);
            }
          }, 200);
        }
      });

      // Provide detailed error feedback
      let errorMessage = "";

      if (error?.name === "TypeError" && error.message?.includes("fetch")) {
        errorMessage =
          "Network Error: Unable to connect to the CDN.<br><br><strong>Possible causes:</strong><br>• No internet connection<br>• CDN server is down<br>• Network firewall blocking the request";
      } else if (error?.message?.includes("HTTP")) {
        errorMessage = `Server Error: ${error.message}<br><br>The CDN returned an error response. This may be due to:<br>• Temporary server issues<br>• Script URL has changed or is no longer available<br>• Access restrictions`;
      } else if (error?.message?.includes("CORS")) {
        errorMessage =
          "CORS Error: Cross-origin request blocked.<br><br>This may be due to:<br>• Browser security policies<br>• CDN CORS configuration<br>• Network proxy restrictions";
      } else {
        errorMessage = `Unexpected Error: ${error?.message || 'Unknown error'}<br><br>Please try again later or check the browser console for more details.`;
      }

      // Small delay to ensure loading modal is closed before showing error
      setTimeout(async () => {
        await showModal(errorMessage, "Failed to Load Math Tools", "error");
      }, 250);

      console.error("Math Tools loading error:", error);
    }
  },
} as Handler;
