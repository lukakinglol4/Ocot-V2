import { showModal, createBaseModal, removeModal } from "../utils/modalHelpers.js";

interface Handler {
    id: string;
    title: string;
    description: string;
    category: string;
    onActivate(): Promise<void>;
    showCurrencyModal(): void;
    setCurrency(currencyType: string, amount: number): void;
    getBookmarkletCode?(): string;
}

// Handler implementation
const BlooketCurrencyHandler = {
    id: "setblooketcurrency",
    title: "Set Blooket Currency",
    description: "Modify your Blooket game currency (crypto, cash, gold, cafeCash)",
    category: "gaming",

    async onActivate(): Promise<void> {
        try {
            // Check if we're on a Blooket page
            if (!window.location.hostname.includes('blooket.com')) {
                showModal(
                    "This tool only works on Blooket.com game pages. Please navigate to a Blooket game first.",
                    "Wrong Website",
                    "warning"
                );
                return;
            }

            // Check if we're in a game
            const gameElement = document.querySelector("body div[id] > div > div");
            if (!gameElement) {
                showModal(
                    "Please make sure you're in an active Blooket game before using this tool.",
                    "Game Not Detected",
                    "warning"
                );
                return;
            }

            // Show currency selection modal
            this.showCurrencyModal();

        } catch (error) {
            console.error('Blooket Currency Setter Error:', error);
            showModal(
                "An error occurred while trying to access the Blooket game. Make sure you're in an active game session.",
                "Error",
                "error"
            );
        }
    },

    showCurrencyModal(): void {
        const { modal, modalContent } = createBaseModal(
            "Set Blooket Game Currency",
            "input"
        );

        // Create description
        const descriptionDiv = document.createElement("div");
        descriptionDiv.style.cssText = `
      color: var(--text-secondary, #d4d4d4);
      line-height: 1.5;
      margin-bottom: 20px;
      font-size: 0.95rem;
    `;
        descriptionDiv.innerHTML = `
      <div style="margin-bottom: 12px;">Select the currency type and enter the amount you want to set:</div>
      <div style="background: var(--bg-primary, #1e1e1e); padding: 12px; border-radius: 6px; border-left: 3px solid var(--accent-color, #00bfff);">
        <strong>Currency Types:</strong><br>
        • <strong>Crypto:</strong> For racing and tower defense games<br>
        • <strong>Cash:</strong> For general game modes<br>
        • <strong>Gold:</strong> For adventure and RPG modes<br>
        • <strong>Cafe Cash:</strong> For cafe-themed games
      </div>
    `;
        modalContent.appendChild(descriptionDiv);

        // Create form container
        const formContainer = document.createElement("div");
        formContainer.style.cssText = `
      display: grid;
      gap: 16px;
      margin-bottom: 20px;
    `;

        // Currency selector
        const selectorContainer = document.createElement("div");
        const selectorLabel = document.createElement("label");
        selectorLabel.textContent = "Currency Type:";
        selectorLabel.style.cssText = `
      display: block;
      color: var(--text-primary, #fff);
      font-weight: 600;
      margin-bottom: 8px;
    `;

        const currencySelect = document.createElement("select");
        currencySelect.style.cssText = `
      width: 100%;
      padding: 12px;
      background: var(--bg-primary, #1e1e1e);
      border: 1px solid var(--border-color, #404040);
      border-radius: 6px;
      color: var(--text-primary, #fff);
      font-size: 1rem;
      outline: none;
    `;

        const currencies = [
            { value: "crypto", label: "Crypto (Racing/Tower Defense)" },
            { value: "cash", label: "Cash (General Games)" },
            { value: "gold", label: "Gold (Adventure/RPG)" },
            { value: "cafeCash", label: "Cafe Cash (Cafe Games)" }
        ];

        currencies.forEach(currency => {
            const option = document.createElement("option");
            option.value = currency.value;
            option.textContent = currency.label;
            currencySelect.appendChild(option);
        });

        // Amount input
        const inputContainer = document.createElement("div");
        const inputLabel = document.createElement("label");
        inputLabel.textContent = "Amount:";
        inputLabel.style.cssText = `
      display: block;
      color: var(--text-primary, #fff);
      font-weight: 600;
      margin-bottom: 8px;
    `;

        const amountInput = document.createElement("input");
        amountInput.type = "number";
        amountInput.placeholder = "Enter amount (e.g., 10000)";
        amountInput.min = "0";
        amountInput.max = "999999999";
        amountInput.style.cssText = `
      width: 100%;
      padding: 12px;
      background: var(--bg-primary, #1e1e1e);
      border: 1px solid var(--border-color, #404040);
      border-radius: 6px;
      color: var(--text-primary, #fff);
      font-size: 1rem;
      outline: none;
      box-sizing: border-box;
    `;

        // Add focus styling
        currencySelect.addEventListener("focus", () => {
            currencySelect.style.borderColor = "var(--accent-color, #00bfff)";
            currencySelect.style.boxShadow = "0 0 0 2px rgba(0, 191, 255, 0.3)";
        });

        currencySelect.addEventListener("blur", () => {
            currencySelect.style.borderColor = "var(--border-color, #404040)";
            currencySelect.style.boxShadow = "none";
        });

        amountInput.addEventListener("focus", () => {
            amountInput.style.borderColor = "var(--accent-color, #00bfff)";
            amountInput.style.boxShadow = "0 0 0 2px rgba(0, 191, 255, 0.3)";
        });

        amountInput.addEventListener("blur", () => {
            amountInput.style.borderColor = "var(--border-color, #404040)";
            amountInput.style.boxShadow = "none";
        });

        // Assemble form
        selectorContainer.appendChild(selectorLabel);
        selectorContainer.appendChild(currencySelect);
        inputContainer.appendChild(inputLabel);
        inputContainer.appendChild(amountInput);
        formContainer.appendChild(selectorContainer);
        formContainer.appendChild(inputContainer);
        modalContent.appendChild(formContainer);

        // Create "Set to Max" button
        const setToMaxButton = document.createElement("button");
        setToMaxButton.textContent = "Set to Max";
        setToMaxButton.style.cssText = `
      width: 100%;
      padding: 12px;
      background: #4CAF50;
      border: none;
      border-radius: 6px;
      color: white;
      cursor: pointer;
      font-size: 1rem;
      font-weight: 500;
      margin-bottom: 20px;
      transition: background-color 0.2s;
    `;

        setToMaxButton.addEventListener("mouseenter", () => {
            setToMaxButton.style.backgroundColor = "#45a049";
        });
        setToMaxButton.addEventListener("mouseleave", () => {
            setToMaxButton.style.backgroundColor = "#4CAF50";
        });

        setToMaxButton.addEventListener("click", () => {
            // Set to maximum safe value that won't break the game
            amountInput.value = "999999999";
        });

        modalContent.appendChild(setToMaxButton);

        // Create button container
        const buttonContainer = document.createElement("div");
        buttonContainer.style.cssText = `
      display: flex;
      justify-content: flex-end;
      gap: 12px;
    `;

        // Cancel button
        const cancelButton = document.createElement("button");
        cancelButton.textContent = "Cancel";
        cancelButton.style.cssText = `
      padding: 12px 24px;
      background: #6c757d;
      border: none;
      border-radius: 6px;
      color: white;
      cursor: pointer;
      font-size: 1rem;
      font-weight: 500;
      transition: background-color 0.2s;
    `;

        // Apply button
        const applyButton = document.createElement("button");
        applyButton.textContent = "Apply Currency";
        applyButton.style.cssText = `
      padding: 12px 24px;
      background: var(--accent-color, #00bfff);
      border: none;
      border-radius: 6px;
      color: white;
      cursor: pointer;
      font-size: 1rem;
      font-weight: 500;
      transition: background-color 0.2s;
    `;

        // Button hover effects
        cancelButton.addEventListener("mouseenter", () => {
            cancelButton.style.backgroundColor = "#545b62";
        });
        cancelButton.addEventListener("mouseleave", () => {
            cancelButton.style.backgroundColor = "#6c757d";
        });

        applyButton.addEventListener("mouseenter", () => {
            applyButton.style.backgroundColor = "var(--accent-color-hover, #0099cc)";
        });
        applyButton.addEventListener("mouseleave", () => {
            applyButton.style.backgroundColor = "var(--accent-color, #00bfff)";
        });

        buttonContainer.appendChild(cancelButton);
        buttonContainer.appendChild(applyButton);
        modalContent.appendChild(buttonContainer);

        // Focus on amount input
        setTimeout(() => amountInput.focus(), 100);

        // Event handlers
        const closeModal = () => {
            removeModal(modal);
        };

        cancelButton.addEventListener("click", closeModal);

        const applyCurrency = () => {
            const amount = parseInt(amountInput.value);
            const currency = currencySelect.value;

            if (isNaN(amount) || amount < 0) {
                showModal(
                    "Please enter a valid positive number for the amount.",
                    "Invalid Amount",
                    "warning"
                );
                return;
            }

            if (amount > 999999999) {
                showModal(
                    "Amount cannot exceed 999,999,999 to prevent game issues.",
                    "Amount Too Large",
                    "warning"
                );
                return;
            }

            this.setCurrency(currency, amount);
            closeModal();
        };

        applyButton.addEventListener("click", applyCurrency);

        // Enter key support
        amountInput.addEventListener("keydown", (e: KeyboardEvent) => {
            if (e.key === "Enter") {
                applyCurrency();
            }
        });

        // Close on escape
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === "Escape") {
                document.removeEventListener("keydown", handleKeyDown);
                closeModal();
            }
        };
        document.addEventListener("keydown", handleKeyDown);

        // Close on overlay click
        modal.addEventListener("click", (e: MouseEvent) => {
            if (e.target === modal) {
                closeModal();
            }
        });

        if ((modalContent as any)._closeButton) {
            (modalContent as any)._closeButton.addEventListener("click", closeModal);
        }
    },

    setCurrency(currencyType: string, amount: number): void {
        try {
            // Get the game state object
            const gameElement = document.querySelector("body div[id] > div > div") as any;
            if (!gameElement) {
                showModal(
                    "Could not find the game interface. Make sure you're in an active Blooket game.",
                    "Game Not Found",
                    "error"
                );
                return;
            }

            const gameElementProps = Object.values(gameElement)[1] as any;
            const stateNode = gameElementProps?.children?.[0]?._owner?.stateNode;
            if (!stateNode) {
                showModal(
                    "Could not access the game state. This might be due to a Blooket update or you're not in a compatible game mode.",
                    "State Access Failed",
                    "error"
                );
                return;
            }

            // Apply the currency change
            let success = false;
            let currencyName = "";

            switch (currencyType) {
                case "crypto":
                    currencyName = "Crypto";
                    stateNode.setState({ crypto: amount, crypto2: amount });
                    if (stateNode.props?.liveGameController?.setVal) {
                        stateNode.props.liveGameController.setVal({
                            path: "c/" + stateNode.props.client.name + "/cr",
                            val: amount
                        });
                    }
                    success = true;
                    break;

                case "cash":
                    currencyName = "Cash";
                    stateNode.setState({ cash: amount });
                    success = true;
                    break;

                case "gold":
                    currencyName = "Gold";
                    stateNode.setState({ gold: amount, gold2: amount });
                    if (stateNode.props?.liveGameController?.setVal) {
                        stateNode.props.liveGameController.setVal({
                            path: "c/" + stateNode.props.client.name,
                            val: {
                                b: stateNode.props.client.blook,
                                g: amount
                            }
                        });
                    }
                    success = true;
                    break;

                case "cafeCash":
                    currencyName = "Cafe Cash";
                    stateNode.setState({ cafeCash: amount });
                    if (stateNode.props?.liveGameController?.setVal) {
                        stateNode.props.liveGameController.setVal({
                            path: "c/" + stateNode.props.client.name,
                            val: {
                                b: stateNode.props.client.blook,
                                ca: amount
                            }
                        });
                    }
                    success = true;
                    break;

                default:
                    showModal(
                        "Unknown currency type selected. Please try again.",
                        "Invalid Currency",
                        "error"
                    );
                    return;
            }

            if (success) {
                showModal(
                    `Successfully set ${currencyName} to ${amount.toLocaleString()}! The change should be visible in your game interface.`,
                    "Currency Updated",
                    "success"
                );
            }

        } catch (error) {
            console.error('Currency setting error:', error);
            showModal(
                "Failed to modify the currency. This could be due to a Blooket update or incompatible game mode. Error details are logged in the console.",
                "Currency Update Failed",
                "error"
            );
        }
    },

    getBookmarkletCode(): string {
        return "javascript:(function(){const e=document.createElement(\"div\");e.style.position=\"fixed\",e.style.top=\"20px\",e.style.right=\"20px\",e.style.zIndex=\"9999\",e.style.backgroundColor=\"#f9f9f9\",e.style.border=\"2px%20solid%20#333\",e.style.borderRadius=\"8px\",e.style.padding=\"15px\",e.style.boxShadow=\"0%204px%2012px%20rgba(0,0,0,0.2)\",e.style.fontFamily=\"Arial,sans-serif\",e.style.cursor=\"move\",e.setAttribute(\"id\",\"currencyModal\");const%20t=document.createElement(\"div\");t.textContent=\"Set%20Game%20Currency\",t.style.fontWeight=\"bold\",t.style.marginBottom=\"10px\",e.appendChild(t);const%20n=document.createElement(\"select\");[\"crypto\",\"cash\",\"gold\",\"cafeCash\"].forEach(e=>{const%20t=document.createElement(\"option\");t.value=e,t.textContent=e,n.appendChild(t)}),n.style.marginBottom=\"10px\",n.style.width=\"100%\",n.style.padding=\"8px\",n.style.borderRadius=\"4px\",e.appendChild(n);const%20o=document.createElement(\"input\");o.type=\"number\",o.placeholder=\"Enter%20amount\",o.style.width=\"100%\",o.style.padding=\"8px\",o.style.border=\"1px%20solid%20#ccc\",o.style.borderRadius=\"4px\",o.style.boxSizing=\"border-box\",e.appendChild(o);const%20r=document.createElement(\"button\");r.textContent=\"Set%20to%20Max\",r.style.marginTop=\"10px\",r.style.width=\"100%\",r.style.padding=\"8px\",r.style.borderRadius=\"4px\",r.style.backgroundColor=\"#4CAF50\",r.style.color=\"white\",r.style.border=\"none\",r.style.cursor=\"pointer\",r.onclick=function(){o.value=\"99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999\"},e.appendChild(r),document.body.appendChild(e),o.addEventListener(\"keydown\",function(e){if(\"Enter\"===e.key){const%20t=Number(o.value),r=n.value,a=Object.values(document.querySelector(\"body%20div[id]%20>%20div%20>%20div\"))[1].children[0]._owner.stateNode;\"crypto\"===r?(a.setState({crypto:t,crypto2:t}),a.props.liveGameController.setVal({path:\"c/\"+a.props.client.name+\"/cr\",val:t})):\"cash\"===r?a.setState({cash:t}):\"gold\"===r?(a.setState({gold:t,gold2:t}),a.props.liveGameController.setVal({path:\"c/\"+a.props.client.name,val:{b:a.props.client.blook,g:t}})):\"cafeCash\"===r&&(a.setState({cafeCash:t}),a.props.liveGameController.setVal({path:\"c/\"+a.props.client.name,val:{b:a.props.client.blook,ca:t}}))}});let%20a=!1,d=0,l=0;e.addEventListener(\"mousedown\",function(e){a=!0,d=e.clientX-e.target.offsetLeft,l=e.clientY-e.target.offsetTop}),document.addEventListener(\"mousemove\",function(t){a&&(e.style.left=t.clientX-d+\"px\",e.style.top=t.clientY-l+\"px\",e.style.right=\"auto\")}),document.addEventListener(\"mouseup\",function(){a=!1})})();";
    }
};

export default BlooketCurrencyHandler as Handler;