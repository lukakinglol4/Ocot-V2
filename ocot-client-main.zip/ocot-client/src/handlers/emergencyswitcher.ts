import { showInputModal } from "../utils/modalHelpers.js";
import type { Handler } from "../types/global.d.ts";

export default {
  async onActivate(): Promise<void> {
    // Create and configure the emergency tab switcher element
    const elem = document.createElement("div");
    const body = document.body;

    body.appendChild(elem);

    // Apply styles using Object.assign for cleaner code
    Object.assign(elem.style, {
      position: "fixed",
      top: "0px",
      right: "0px",
      margin: "10px",
      paddingTop: "10px",
      width: "200px",
      height: "40px",
      zIndex: "10000",
      opacity: "0.9",
      color: "white",
      backgroundColor: "black",
      border: "1px solid white",
      textAlign: "center",
      cursor: "pointer",
      display: "block",
    });

    elem.id = "elem";
    elem.textContent = "Z";

    // Get the safety URL from user
    const safetyUrl = await showInputModal(
      "What tab do you want to open when a teacher comes by?<br><br>Click Z or click the floating element to quickly switch to that tab.<br><br><strong>Warning:</strong> You may need to click out of the element for the keyboard shortcut to work.",
      "https://classroom.google.com",
      "Emergency Tab Switcher Setup",
      "url"
    );

    if (!safetyUrl) {
      // Remove the element if user cancelled
      if (elem.parentNode) {
        elem.parentNode.removeChild(elem);
      }
      return;
    }

    // Function to navigate to safety URL
    const navigateToSafety = (): void => {
      if (safetyUrl) {
        window.location.href = safetyUrl;
      }
    };

    // Add keyboard event listener
    window.addEventListener("keydown", (event: KeyboardEvent) => {
      if (event.key.toLowerCase() === "z") {
        navigateToSafety();
      }
    });

    // Add click event listener
    elem.addEventListener("click", navigateToSafety);
  },
} as Handler;
